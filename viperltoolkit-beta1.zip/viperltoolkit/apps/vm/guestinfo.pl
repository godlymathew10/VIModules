#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;
use XML::LibXML;
use XML::Parser;

sub display;
sub customize;
sub validate;
sub validate_format;
sub validate_schema;
sub check_missing_value;

my %opts = (
   'vmname' => {
      type => "=s",
      help => "The name of the virtual machine",
      required => 1,
   },
   'operation' => {
      type => "=s",
      help => "Operation to be performed on the Guest: display, customize",
      required => 1,
   },
   'filename' => {
      type => "=s",
      help => "The xml configuration filename",
      required => 0,
   },
   'schema' => {
      type => "=s",
      help => "The location of the schema file",
      required => 0,
      default => "../schema/guestinfo_customize.xsd",
   },
);

# add user option
Opts::add_options(%opts);

# read options
Opts::parse();

# validate options
Opts::validate(\&validate);

my $op = Opts::get_option('operation');
my $vmname = Opts::get_option('vmname');

my %toolsStatus = (
   'toolsOk' => 'VMware Tools is running and the version is current.',
   'toolsNotRunning' => 'VMware Tools is not running',
   'toolsNotInstalled'  =>
   'VMware Tools has never been installed or has not run in the virtual machine',
   'toolsOld' => 'VMware Tools is running, but the version is not current',
);

# connect to the server
Util::connect();
if ($op eq "display") {
   display();
}
if ($op eq "customize") {
   customize();
}
Util::disconnect();

sub display() {

   my $vmname = Opts::get_option('vmname');
   my $vm_view =
      Vim::find_entity_view(view_type => 'VirtualMachine',
                            filter => {"config.name" => '^' . $vmname . '$'});
   if($vm_view) {
      if ($vm_view->runtime->powerState->val eq 'poweredOff'){
         Util::trace(0, "For $op VM $vmname should be powered on");
      }
      else {
         Util::trace(0, $vm_view->name ." guestFamily: "
                      . $vm_view->guest->guestFamily . "\n");
         Util::trace(0, $vm_view->name . " guestFullName: "
                      . $vm_view->guest->guestFullName. "\n");
         Util::trace(0, $vm_view->name . " guestId: "
                      . $vm_view->guest->guestId . "\n");
         Util::trace(0, $vm_view->name . " guestState: "
                      . $vm_view->guest->guestState . "\n");
         Util::trace(0, $vm_view->name . " hostName: "
                      . $vm_view->guest->hostName . "\n");
         Util::trace(0, $vm_view->name . " ipAddress: "
                      . $vm_view->guest->ipAddress . "\n");
         Util::trace(0, $vm_view->name . " toolsStatus: "
                      . $toolsStatus{$vm_view->guest->toolsStatus->val} . "\n");
         Util::trace(0, $vm_view->name . " toolsVersion: "
                      . $vm_view->guest->toolsVersion . "\n");
         Util::trace(0, $vm_view->name . " Screen - Height: "
                      . $vm_view->guest->screen->height . "\n");
         Util::trace(0, $vm_view->name . " Screen - Width: "
                      . $vm_view->guest->screen->width . "\n");
         Util::trace(0, $vm_view->name . " Disk: Capacity "
                      . $vm_view->guest->disk->[0]->capacity . "\n");
         Util::trace(0, $vm_view->name . " Disk: Path "
                      . $vm_view->guest->disk->[0]->diskPath . "\n");
         Util::trace(0, $vm_view->name . " Disk: freespace "
                      . $vm_view->guest->disk->[0]->freeSpace . "\n");
         Util::trace(0, "net connected "
                      . $vm_view->guest->net->[0]->connected . "\n");
         Util::trace(0, $vm_view->name . " net - deviceConfigId "
                      . $vm_view->guest->net->[0]->deviceConfigId . "\n");
         Util::trace(0, $vm_view->name . " net - macAddress "
                      . $vm_view->guest->net->[0]->macAddress . "\n");
         Util::trace(0, $vm_view->name . " net - network "
                      . $vm_view->guest->net->[0]->network . "\n");
         Util::trace(0, $vm_view->name . " net - ipAddress "
                      . $vm_view->guest->net->[0]->ipAddress->[0] . "\n");
      }
   }
   else {
      Util::trace(0, "\nVM $vmname not found.\n");
   }
}

sub customize() {
   my $vmname = Opts::get_option('vmname');
   my $vm_view = Vim::find_entity_view(view_type => 'VirtualMachine',
                                       filter => {"config.name" => $vmname});
   if ($vm_view) {
      if ($vm_view->runtime->powerState->val eq 'poweredOn'){
         Util::trace(0, "For $op VM $vmname should be powered off");
      }
      else {
         my $customization_spec = get_customization_spec();
         eval {
            $vm_view->CustomizeVM(spec => $customization_spec);
            Util::trace(0, "Customization Successful");
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
            }
         }
      }
   }
   else {
      Util::trace(0, "\n VM $vmname not found.\n");
   }
}

sub get_customization_spec() {

   my $parser = XML::LibXML->new();
   my $tree = $parser->parse_file(Opts::get_option('filename'));
   my $root = $tree->getDocumentElement;
   my @cspec = $root->findnodes('customizationspec');

   my $autologon = 1;
   my $computername = "compname";
   my $timezone = 190;
   my $username;
   my $userpassword;
   my $domain;
   my $fullname;
   my $orgname;
  
   foreach (@cspec) {
      if ($_->findvalue('autologon')) {
         $autologon = $_->findvalue('autologon');
      }
      if ($_->findvalue('computername')) {
         $computername = $_->findvalue('computername');
      }
      if ($_->findvalue('timezone')) {
         $timezone = $_->findvalue('timezone');
      }
      if ($_->findvalue('domain')) {
         $domain = $_->findvalue('domain');
      }
      if ($_->findvalue('domain_user_name')) {
         $username = $_->findvalue('domain_user_name');
      }
      if ($_->findvalue('domain_user_password')) {
         $userpassword = $_->findvalue('domain_user_password');
      }
      if ($_->findvalue('fullname')) {
         $fullname = $_->findvalue('fullname');
      }
      if ($_->findvalue('orgname')) {
         $orgname = $_->findvalue('orgname');
      }
   }
  
   my $customization_global_settings = CustomizationGlobalIPSettings->new();
   my $customization_identity_settings = CustomizationIdentitySettings->new();

   my $password =
      CustomizationPassword->new(plainText=>"true", value=> $userpassword );

   my $cust_identification =
      CustomizationIdentification->new(domainAdmin => $username,
                                       domainAdminPassword => $password,
                                       joinDomain => $domain);

   my $cust_gui_unattended =
      CustomizationGuiUnattended->new(autoLogon => $autologon,
                                      autoLogonCount => 0,
                                      timeZone => $timezone);

   my $cust_name = CustomizationFixedName->new (name => $computername);
   my $cust_user_data =
      CustomizationUserData->new(computerName => $cust_name,
                                 fullName => $fullname,
                                 orgName => $orgname,
                                 productId => "XJM6Q-BQ8HW-T6DFB-Y934T-YD4YT");

   my $cust_sysprep =
      CustomizationSysprep->new(guiUnattended => $cust_gui_unattended,
                                identification => $cust_identification,
                                userData => $cust_user_data);

   my $customization_fixed_ip = CustomizationDhcpIpGenerator->new();

   my $cust_ip_settings =
      CustomizationIPSettings->new(ip => $customization_fixed_ip);

   my $cust_adapter_mapping =
      CustomizationAdapterMapping->new(adapter => $cust_ip_settings);

   my @cust_adapter_mapping_list = [$cust_adapter_mapping];

   my $customization_spec =
      CustomizationSpec->new (identity=>$cust_sysprep,
                              globalIPSettings=>$customization_global_settings,
                              nicSettingMap=>@cust_adapter_mapping_list);
   return $customization_spec;
}

sub validate {
   my $operation = Opts::get_option('operation');
   my $valid = 1;
   if (defined (Opts::get_option('operation'))){
      if (($operation ne 'display') && ($operation ne 'customize')) {
         Util::trace(0, "Invalid operation '$operation': "
                      . "must be display or customize\n");
         $valid = 0;
      }
      if ($operation eq 'customize'){
         if(!defined(Opts::get_option('filename'))) {
            Util::trace(0, "\nPlease specify the filename");
            $valid = 0;
         }

         if (!defined(Opts::get_option('schema'))) {
            Util::trace(0, "\nPlease specify the schema file");
            $valid = 0;
         }
         if ((defined(Opts::get_option('schema')))
               && (defined(Opts::get_option('filename')))) {
            validate_format();
            validate_schema();
            check_missing_value();
         }
      }
      return $valid;
   }
}

# check if the XML is well formed or not
# ======================================
sub validate_format {
   my $filename = Opts::get_option('filename');
   my $parser = XML::Parser->new( ErrorContext => 2 );
   eval {
      $parser->parsefile( $filename );
   };
   if( $@ ) {
      die("\nERROR in '$filename':\n$@\n");
   }
}

# validate XML against the schema
# =================================
sub validate_schema {
   my $filename = Opts::get_option('filename');
   my $schema_filename = Opts::get_option('schema');
   my $xmlschema = XML::LibXML::Schema-> new( location => $schema_filename );
   my $parser=XML::LibXML-> new;
   my $doc=$parser-> parse_file( $filename );
   eval {
      $xmlschema-> validate( $doc );
   };
   if ($@) {
      die("\nError in '$filename':\n" . $@);
   }
}

# check missing values of mandatory fields
# ========================================
sub check_missing_value {
   my $filename = Opts::get_option('filename');
   my $parser = XML::LibXML->new();
   my $tree = $parser->parse_file($filename);
   my $root = $tree->getDocumentElement;
   my @cust_spec = $root->findnodes('customizationspec');
   my $total = @cust_spec;
   if (!$cust_spec[0]->findvalue('autologon')) {
      die("\nERROR in '$filename':\n autologon value missing ");
   }
   if (!$cust_spec[0]->findvalue('computername')) {
      die("\nERROR in '$filename':\n computername value missing ");
   }
   if (!$cust_spec[0]->findvalue('timezone')) {
      die("\nERROR in '$filename':\n timezone value missing ");
   }
   if (!$cust_spec[0]->findvalue('domain')) {
      die("\nERROR in '$filename':\n domain value missing ");
   }
   if (!$cust_spec[0]->findvalue('domain_user_name')) {
      die("\nERROR in '$filename':\n domain_user_name value missing ");
   }
   if (!$cust_spec[0]->findvalue('domain_user_password')) {
      die("\nERROR in '$filename':\n domain_user_password value missing ");
   }
   if (!$cust_spec[0]->findvalue('fullname')) {
      die("\nERROR in '$filename':\n fullname value missing ");
   }
   if (!$cust_spec[0]->findvalue('orgname')) {
      die("\nERROR in '$filename':\n orgname value missing ");
   }
}

__END__

=head1 NAME

guestinfo.pl - Lists attributes of guest and customizing some of these.

=head1 SYNOPSIS

 guestinfo.pl --url <web service URL> --username <server login name>
         --password <server login password> --vmname <virtual machine name>
         --operation <display|customize> --filename <customization xml file>
         --schema <xsd schema file name>

=head1 DESCRIPTION

This VI Perl command-line utility provides an interface for
displaying the attributes of guest and customizing some of these
attributes.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<operation>

Required. Operation to be performed. Must be one of the following:
I<display> (displays the attributes of guest)
I<customize> (reads the customization specification from an xml file
and customizes those attributes).

=item B<vmname>

Required. The name of the virtual machine. It will be used to select the
virtual machine of which the guest properties will be displayed or customized.

=back

=head2 DISPLAY OPTIONS

=over

=item B<operation>

Required. Operation to be performed.
I<display> (displays the attributes of guest)

=item B<vmname>

Required. The name of the virtual machine. It will be used to select the
 virtual machine of which the guest properties will be displayed.

=back

=head2 CUSTOMIZE OPTIONS

=over

=item B<operation>

Required. Operation to be performed.
I<customize> (reads the customization specification from an xml file
and customizes those attributes)

=item B<vmname>

Required. The name of the virtual machine. It will be used to select the
 virtual machine of which the guest properties will be customized.

=item B<filename>

Required. The name of the customization specification xml file. This file specifies
the properties to be modified and the new values to be set.

=item B<schema>

Required. The name of the xsd file for validating.

=back


=head1 EXAMPLES

Displays the attributes of guest under virtual machine specified:

   guestinfo.pl --url https://192.168.111.52:443/sdk/webService
            --username administrator --password mypassword
            --vmname VirtualABC --operation display

Customize the attributes of guest, customizing the attributes
as specified in the xml specification file.

   guestinfo.pl --url https://192.168.111.52:443/sdk/webService
            --username administrator --password mypassword
            --vmname VirtualABC --operation customize
            --filename specification.xml
            --schema schema.xsd

Sample specification xml file

   <?xml version="1.0"?>
      <specification>
         <customizationspec>
            <autologon>1</autologon>
            <computername>VM9</computername>
            <timezone>033</timezone>
            <domain>InterraIT.info</domain>
            <domain_user_name>DildipK</domain_user_name>
            <domain_user_password>discussion8</domain_user_password>
            <fullname>admin</fullname>
            <orgname>InterraIT</orgname>
         </customizationspec>
      </specification>

=head1 SUPPORTED PLATFORMS

All operations work with VMware VirtualCenter 2.0.1.

Display operation works with VMware ESX server 3.0.1 or later.
Customize operation is not supported on ESX.

