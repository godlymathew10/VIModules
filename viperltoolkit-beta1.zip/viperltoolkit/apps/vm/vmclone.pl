#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;
use XML::LibXML;
use XML::Parser;

sub validate_format;
sub validate_schema;
sub check_missing_value;

my %opts = (
   vmhost => {
      type => "=s",
      help => "The name of the host",
      required => 0,
   },
   vmname => {
      type => "=s",
      help => "The name of the vm",
      required => 0,
   },
   operation => {
      alias => "op",
      type => "=s",
      help => "Operation to be performed on the vm: clone",
      required => 1,
   },
   vmname_destination => {
      type => "=s",
      help => "The name of the target vm for a clone",
      required => 0,
   },
   url => {
      type => "=i",
      help => "URL to the Virtual Center",
      required => 1,
      default => 1,
   },
   filename => {
      type => "=s",
      help => "The name of the configuration specification file",
      required => 0,
      default => 0,
   },
   customize_guest => {
      type => "=s",
      help => "customize guest (OS) network settings, enter yes or no ",
      required => 0,
      default => 0,
   },
   customize_vm => {
      type => "=s",
      help => "customize vm settings , enter yes or no",
      required => 0,
      default => 0,
   },
   schema => {
      type => "=s",
      help => "The name of the schema file",
      required => 0,
      default => "../schema/vmclone_guestcustomize.xsd",
   },
   datastore => {
      type => "=s",
      help => "datastore name",
      required => 0,
   },



);

Opts::add_options(%opts);
Opts::parse();
Opts::validate(\&validate);

Util::connect();

# Perform <clone> operation to clone a virtual machine
my $op = Opts::get_option('operation');
if ($op eq 'clone') {
   clone_vm();
}

Util::disconnect();


# Clone vm operation
# Gets destination host, compute resource views, and
# datastore info for creating the configuration
# specification to help create a clone of an existing
# virtual machine.
# ====================================================
sub clone_vm {
   my $op = Opts::get_option('operation');
   my $vm_name = Opts::get_option('vmname');
   my $vm_view = Vim::find_entity_view(view_type => 'VirtualMachine',
                                       filter => {'name' =>'^' .$vm_name .'$' });

   if ($vm_view) {
      my $host_view = get_host_view(Opts::get_option('vmhost_destination'));
      if ($host_view) {
         my $comp_res_view = Vim::get_view(mo_ref => $host_view->parent);

         my $ds_name = Opts::get_option('datastore');
         my %ds_info = get_datastore(host_view => $host_view,
                                     datastore => $ds_name);

         my $relocate_spec =
          VirtualMachineRelocateSpec->new(datastore => $ds_info{mor},
                                          host => $host_view,
                                          pool => $comp_res_view->resourcePool);
         my $clone_name = Opts::get_option('vmname_destination');
         my $clone_spec ;
         my $config_spec;
         my $customization_spec;
       
         if ((Opts::get_option('customize_vm') eq "yes")
             && (Opts::get_option('customize_guest') ne "yes")) {
            $config_spec = get_config_spec();
            $clone_spec =
             VirtualMachineCloneSpec->new( powerOn => 0,template => 0,
                                           location => $relocate_spec,
                                           config => $config_spec,
                                         );
         }
         elsif ((Opts::get_option('customize_guest') eq "yes")
             && (Opts::get_option('customize_vm') ne "yes")) {
            $customization_spec = get_customization_spec();
            $clone_spec = VirtualMachineCloneSpec->new(
                                                   powerOn => 0,
                                                   template => 0,
                                                   location => $relocate_spec,
                                                   customization => $customization_spec,
                                                   );
         }
         elsif ((Opts::get_option('customize_guest') eq "yes")
             && (Opts::get_option('customize_vm') eq "yes")){
            $customization_spec = get_customization_spec();
            $config_spec = get_config_spec();
            $clone_spec = VirtualMachineCloneSpec->new(
                                                   powerOn => 0,
                                                   template => 0,
                                                   location => $relocate_spec,
                                                   customization => $customization_spec,
                                                   config => $config_spec,
                                                   );
         }
         else {
            $clone_spec = VirtualMachineCloneSpec->new(
                                                   powerOn => 0,
                                                   template => 0,
                                                   location => $relocate_spec,
                                                   );
         }
           Util::trace (0, "Making clone of " . $vm_name . "\n");
         eval {
            $vm_view->CloneVM(folder => $vm_view->parent,
                              name => Opts::get_option('vmname_destination'),
                              spec => $clone_spec);
         };
         
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               if (ref($@->detail) eq 'FileFault') {
                  Util::trace(0, "\nFailed to access the virtual machine files\n");
               }
               if (ref($@->detail) eq 'InvalidState') {
                  Util::trace(0,"The operation is not allowed in the current state.\n");
               }
               if (ref($@->detail) eq 'NotSupported') {
                  Util::trace(0," Operation is not supported by the current agent \n");
               }
               if (ref($@->detail) eq 'VmConfigFault') {
                  Util::trace(0,
                  "Virtual machine is not compatible with the destination host.\n");
               }
               else {
                 Util::trace (0, "Fault" . $@->fault_string . ""   );
               }
            }
         }
       Util::trace (0,"Clone of" . $vm_name ." " . $clone_name ." created");
      }
   }
}

#Gets the config_spec for customizing the memory, number of cpu's , disksize etc
# and returns the spec
sub get_config_spec() {

   my $parser = XML::LibXML->new();
   my $tree = $parser->parse_file(Opts::get_option('filename'));
   my $root = $tree->getDocumentElement;
   my @cspec = $root->findnodes('configspec');
   my $vmname ;
   my $vmhost  ;
   my $datacenter;
   my $guestid;
   my $datastore;
   my $disksize;
   my $memory;
   my $num_cpus;
   my $nic_network;
   my $nic_poweron;

   foreach (@cspec) {
      $vmname = $_->findvalue('vmname');
      $vmhost = $_->findvalue('vmhost');
      $datacenter = $_->findvalue('datacenter');
      $guestid = $_->findvalue('guestid');
      $datastore = $_->findvalue('datastore');
      $disksize = $_->findvalue('disksize');
      $memory = $_->findvalue('memory');
      $num_cpus = $_->findvalue('num_cpus');
      $nic_network = $_->findvalue('nic_network');
      $nic_poweron = $_->findvalue('nic_poweron');
   }
   
   my $vm_config_spec = VirtualMachineConfigSpec->new(
                                                  name => $vmname,
                                                  memoryMB => $memory,
                                                  numCPUs => $num_cpus,
                                                  guestId => $guestid );
   return $vm_config_spec;
}

#Gets the customization spec for customizing the network settings of the
# virtual machine to be cloned.
sub get_customization_spec() {

   my $parser = XML::LibXML->new();
   my $tree = $parser->parse_file(Opts::get_option('filename'));
   my $root = $tree->getDocumentElement;
   my @cspec = $root->findnodes('customizationspec');
   my $autologon = 1;
   my $computername = "compname";
   my $timezone = 190;
   my $username = "virenderj";
   my $userpassword = "Fakeer13";
   my $domain = "InterraIT.info";
   my $orgname ;
   my $fullname;
  
   foreach (@cspec) {
      if ($_->findvalue('autologon')) {
         $autologon = $_->findvalue('autologon');
      }
      if ($_->findvalue('computername')) {
         $computername = $_->findvalue('computername');
      }
      if ($_->findvalue('timezone')) {
         $timezone = $_->findvalue('timezone');
      }
      if ($_->findvalue('domain_user_name')) {
         $username = $_->findvalue('domain_user_name');
      }
      if ($_->findvalue('domain_user_password')) {
         $userpassword = $_->findvalue('domain_user_password');
      }
      if ($_->findvalue('domain')) {
         $domain = $_->findvalue('domain');
      }
      if ($_->findvalue('fullname')) {
         $fullname = $_->findvalue('fullname');
      }
      if ($_->findvalue('orgname')) {
         $orgname = $_->findvalue('orgname');
      }
   }

   my $customization_global_settings = CustomizationGlobalIPSettings->new();
   my $customization_identity_settings = CustomizationIdentitySettings->new();

   my $password = CustomizationPassword->new(plainText=>"true",
                                             value=>$userpassword);

   my $cust_identification =
      CustomizationIdentification->new(domainAdmin => $username,
                                       domainAdminPassword => $password,
                                       joinDomain => $domain
                                      );

   my $cust_gui_unattended = CustomizationGuiUnattended->new(autoLogon => $autologon,
                                                             autoLogonCount => 0,
                                                             timeZone => $timezone);

   my $cust_name = CustomizationFixedName->new (name => $computername);
   my $cust_user_data =
      CustomizationUserData->new(computerName => $cust_name,
                                 fullName => $fullname,
                                 orgName => $orgname,
                                 productId => "XJM6Q-BQ8HW-T6DFB-Y934T-YD4YT");

   my $cust_sysprep = CustomizationSysprep->new(guiUnattended => $cust_gui_unattended,
                                                identification => $cust_identification,
                                                userData => $cust_user_data);

   my $customization_fixed_ip = CustomizationDhcpIpGenerator->new();
   my $cust_ip_settings = CustomizationIPSettings->new(ip => $customization_fixed_ip);
   my $cust_adapter_mapping =
    CustomizationAdapterMapping->new(adapter => $cust_ip_settings);
   my @cust_adapter_mapping_list = [$cust_adapter_mapping];

   my $customization_spec =
    CustomizationSpec->new (identity=>$cust_sysprep,
                            globalIPSettings=>$customization_global_settings,
                            nicSettingMap=>@cust_adapter_mapping_list );
   return $customization_spec;
}


sub get_host_view {
   my $host_name = shift;
   my $host_view = Vim::find_entity_view(view_type => 'HostSystem',
                                         filter => {'name' => $host_name});
   if (!$host_view) {
      Util::trace(0, "Host '$host_name' not found\n");
   }
   return $host_view;
}

# Gets the datastore view from the datastore provided by the user,
# if no datastore is provided it looks for the default datastore
sub get_datastore {
   my %args = @_;
   my $host_view = $args{host_view};
   my $config_datastore = $args{datastore};
   my $disksize = $args{disksize};
   my $name = undef;
   my $mor = undef;

   my $ds_mor_array = $host_view->datastore;
   my $datastores = Vim::get_views(mo_ref_array => $ds_mor_array);
   my $found_datastore = 0;

   # User specified datatstore name

   if($args{datastore}) {
      foreach (@$datastores) {
         $name = $_->summary->name;
     # if datastore available to host
         if($name eq $config_datastore) {
            $found_datastore = 1;
            $mor = $_->{mo_ref};
            last;
         }
      }
   }
   else {       # No datatstore name specified
      foreach (@$datastores) {
         my $disksize = 0;
         my $ds_disksize = ($_->summary->freeSpace)/1024;
         if($ds_disksize > $disksize && $_->summary->accessible) {
            $found_datastore = 1;
            $name = $_->summary->name;
            $mor = $_->{mo_ref};
            $disksize = $ds_disksize;
         } else {
            # the free space available is less than the specified disksize
            return (mor => 0, name => 'disksize_error');
         }
      }
   }

   # No datastore found
   if (!$found_datastore) {
      my $host_name = $host_view->name;
      my $ds_name;
      if ($args{datastore}) {
         $ds_name = $args{datastore};
      }
      return (mor => 0, name => 'datastore_error');
   }
   return (name => $name, mor => $mor);
}

# It checks if the XML is well formed or not
sub validate_format {
   my $filename = Opts::get_option('filename');
   my $parser = XML::Parser->new( ErrorContext => 2 );
   eval {
      $parser->parsefile( $filename );
   };

   # report any error that stopped parsing
   if( $@ ) {
      die "\nERROR in '$filename':\n$@\n";
   }
}

# validate XML against the schema
sub validate_schema {
   my $filename = Opts::get_option('filename');
   my $schema_filename = Opts::get_option('schema');
   my $xmlschema = XML::LibXML::Schema-> new( location => $schema_filename );
   my $parser=XML::LibXML-> new;
   my $doc=$parser-> parse_file( $filename );
   eval {
      $xmlschema-> validate( $doc );
   };
   if ($@) {
      die "\nError in '$filename':\n" . $@;
   }
}

# check missing values of mandatory fields
sub check_missing_value {
   my $filename = Opts::get_option('filename');
   my $parser = XML::LibXML->new();
   my $tree = $parser->parse_file($filename);
   my $root = $tree->getDocumentElement;
   my @cust_spec = $root->findnodes('customizationspec');
   my $total = @cust_spec;
   if (!$cust_spec[0]->findvalue('autologon')) {
         die "\nERROR in '$filename':\n autologon value missing ";
   }
   if (!$cust_spec[0]->findvalue('computername')) {
      die "\nERROR in '$filename':\n computername value missing ";
   }
   if (!$cust_spec[0]->findvalue('timezone')) {
      die "\nERROR in '$filename':\n timezone value missing ";
   }
   if (!$cust_spec[0]->findvalue('domain')) {
      die "\nERROR in '$filename':\n domain value missing ";
   }
   if (!$cust_spec[0]->findvalue('domain_user_name')) {
      die "\nERROR in '$filename':\n domain_user_name value missing ";
   }
   if (!$cust_spec[0]->findvalue('domain_user_password')) {
      die "\nERROR in '$filename':\n domain_user_password value missing ";
   }
   if (!$cust_spec[0]->findvalue('fullname')) {
      die "\nERROR in '$filename':\n fullname value missing ";
   }
   if (!$cust_spec[0]->findvalue('orgname')) {
      die "\nERROR in '$filename':\n orgname value missing ";
   }

   my @config_spec = $root->findnodes('configspec');
   if (!$config_spec[0]->findvalue('vmname')) {
         die "\nERROR in '$filename':\n vmname value missing ";
   }
   if (!$config_spec[0]->findvalue('vmhost')) {
      die "\nERROR in '$filename':\n vmhost value missing ";
   }
   if (!$config_spec[0]->findvalue('datacenter')) {
      die "\nERROR in '$filename':\n datacenter value missing ";
   }
   if (!$config_spec[0]->findvalue('guestid')) {
      die "\nERROR in '$filename':\n guestid value missing ";
   }
   if (!$config_spec[0]->findvalue('datastore')) {
      die "\nERROR in '$filename':\n datastore value missing ";
   }
   if (!$config_spec[0]->findvalue('disksize')) {
      die "\nERROR in '$filename':\n disksize value missing ";
   }
   if (!$config_spec[0]->findvalue('memory')) {
      die "\nERROR in '$filename':\n memory value missing ";
   }
   if (!$config_spec[0]->findvalue('num_cpus')) {
      die "\nERROR in '$filename':\n num_cpus value missing ";
   }
   if (!$config_spec[0]->findvalue('nic_network')) {
      die "\nERROR in '$filename':\n nic_network value missing ";
   }
   if (!$config_spec[0]->findvalue('nic_poweron')) {
      die "\nERROR in '$filename':\n nic_poweron value missing ";
   }
}

sub validate{
   my $valid= 1;
   my $ops = Opts::get_option('operation');
   if (Opts::option_is_set('customize_guest')|| Opts::option_is_set('customize_vm')){
     if ((!Opts::option_is_set('schema'))&&(Opts::option_is_set('filename')) ) {
        $valid = 0;
         die "Must specify schema name with the file name for customizing the clone \n";
      }
     if ((Opts::option_is_set('schema'))&&(!Opts::option_is_set('filename')) ) {
         $valid = 0;
         die "Must specify filename with the schema name for customizing the clone \n";
      }
      if ((!Opts::option_is_set('schema'))&&(!Opts::option_is_set('filename')) ) {
         $valid = 0;
         die "Must specify schema name and the file name for customizing the clone \n";
      }
      else {
         validate_format();
         validate_schema();
         check_missing_value();
      }
   }
   return $valid;
}

__END__



=head1 NAME

vmclone.pl - clone, customize virtual machine and the guest.

=head1 SYNOPSIS

perl vmclone.pl --username <server login name> --password <server login password>
                 --operation clone --vmhost <Name of the ESX server>
                 --vmname <Name of the virtual machine>
                 --vmname_destination <Name of the clone>
                 --url <web service URL> --customize_guest [yes/no]
                 --customize_vm [yes/no] --filename <input XML file>
                 --schema <schema file>

=head1 DESCRIPTION

This VI Perl command-line utility provides an interface for creating
clone of the VM's. One can customize the VM or the guest while creating
the clone of the virtual machine.

=head1 OPTIONS

=head2 General Options

=over

=item B<operation>

Required. Operation to be performed.
I<clone> (clones and customizes a VM using a customization spec from a XML file)

=item B<url>

URL to the virtual center. E.g https://192.168.111.52/sdk/vimService

=back


=head2 Clone Options

=over

=item B<vmhost>

Required. Name of the host containing the ESX server

=item B<vmname>

Required .Name of the virtual machine whose clone is to be created

=item B<vmname_destination>

Required. Name of the clone VM which will be created

=item B<datacenter>

Optional. Datacenter Name, if it is not given script will search for default datacenter

=back


=head2 Customize Clone Guest Options

=over

=item B<vmhost>

Required . Name of the host containing the ESX server


=item B<vmname>

Required. Name of the virtual machine whose clone is to be created

=item B<vmname_destination>

Required. Name of the clone which will be created

=item B<customize_guest>

Required. Customize guest is used to customize the network settings of the guest operating system
Options are Yes/No

=item B<filename>

Required. It is the name of the file in which values of parameters to be customized is written
e.g. --filename  clone_vm.xml.

=item B<schema>

Required. It is the name of the schema which validates the filename


=item B<datacenter>

Optional. Datacenter Name, if it is not given script will search for default datacenter

=back



=head2 Customize Clone VM Options

=over

=item B<vmhost>

Required. Name of the host containing the ESX server

=item B<vmname>

Required. Name of the virtual machine whose clone is to be created

=item B<vmname_destination>

Required. Name of the clone which will be created

=item B<customize_vm>

Required. customize_vm is used to customize the virtual machine settings like disksize, memory
If yes is written it will be customized

=item B<filename>

Required. It is the name of the file in which values of parameters to be customized is written
e.g. --filename  clone_vm.xml.

=item B<schema>

Required. It is the name of the schema which validates the filename

=item B<datacenter>

Optional. Datacenter Name, if it is not given script will search for default datacenter

=back

=head1 EXAMPLES

Making a clone without any customization::

 perl vmclone.pl --username username --password mypassword --operation clone
 --vmhost 192.168.111.2 --vmname DVM1 --vmname_destination DVM99
 --url https://192.168.111.52/sdk/vimService

If datastore is given:

 perl vmclone.pl --username username --password mypassword --operation clone
 --vmhost 192.168.111.2 --vmname DVM1 --vmname_destination DVM99
 --url https://192.168.111.52/sdk/vimService --datastore storage1


Making a clone and customizing the VM

 perl vmclone.pl --username myusername --password mypassword --operation clone
 --vmhost 192.168.111.2 --vmname DVM1 --vmname_destination Clone_VM
 --url https://192.168.111.52/sdk/vimService --customize_vm yes
 --filename clone_vm.xml --schema clone_schema.xsd

All the parameters which are to customized are writtend in the xml file in
this format:

 <?xml version="1.0"?>
  <specification>
   <configspec>
     <vmname>T0I</vmname>
     <vmhost>192.168.111.2</vmhost>
     <datacenter>Dracula</datacenter>
     <guestid>winXPProGuest</guestid>
     <datastore>storage1</datastore>
     <disksize>5096</disksize>
     <memory>256</memory>
     <num_cpus>2</num_cpus>
     <nic_network>VM Network</nic_network>
     <nic_poweron>1</nic_poweron>
   </configspec>
 </specification>

Making a clone and customizing the guestOS::

 perl vmclone.pl --username myuser --password mypassword --operation clone
 --vmhost 192.168.111.2 --vmname DVM1 --vmname_destination DVM99
 --url https://192.168.111.52/sdk/vimService --customize_guest yes
 --filename clone_vm.xml --schema clone_schema.xsd


All the parameters which are to customized are writtend in the xml file in
this format:

 <?xml version="1.0"?>
  <specification>
   <customizationspec>
     <autologon>1</autologon>
     <computername>VM9</computername>
     <timezone>033</timezone>
     <domain_user_name>username</domain_user_name>
     <domain_user_password>password</domain_user_password>
     <domain>InterraIT.info</domain>
     <fullname>admin</fullname>
     <orgname>Interrait</orgname>
   </customizationspec>
 </specification>

Making a clone and customizing both guestos and VM

 perl vmclone.pl --username myuser --password mypassword --operation clone
 --vmhost 192.168.111.2 --vmname DVM1 --vmname_destination DVM99
 --url https://192.168.111.52/sdk/vimService --customize_guest yes --customize_vm yes
 --filename clone_vm.xml --schema clone_schema.xsd


=head1 SUPPORTED PLATFORMS

All operations supported on Virtual Center 2.0.1



