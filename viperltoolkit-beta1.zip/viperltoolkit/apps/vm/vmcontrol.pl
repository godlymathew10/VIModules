#!E:/Perli/bin/perl.exe -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;
sub create_hash;


my %opts = (
   'operation' => {
      type => "=s",
      help => "The power operation to perform on the VM: " .
              "poweron, poweroff, suspend, reset, reboot, shutdown, standby",
      required => 1,
   }, 
   'vmname' => {
      type => "=s",
      help => "The name of the virtual machine",
      required => 0, 
   },
   'username'=> {
      type => "=s",
      help => "Username of the host machine",
      required => 1, 
	},
   'password'=> {
      type => "=s",
      help => "Password of the host machine",
      required => 1, 
	},
   'guestos' => {
      type => "=s",
      help => "The guest OS running on virtual machine",
      required => 0, 
	},
   'ipaddress' => {
      type => "=s",
      help => "The IP of virtual machine",
      required => 0,
	},
   'datacenter' => {
       type     => "=s",
       variable => "datacenter",
       help     => "Source datacenter", 
       required => 0,
	},
   'pool'  =>{
      type     => "=s",
      variable => "pool",
      help     => "Source resource pool",
	  required => 0,
	},
   'host' => {
      type      => "=s",
      variable  => "host",
      help      => "Source host" ,
      required => 0,
	},
   'folder' => {
      type      => "=s",
      variable  => "folder",
      help      => "Source folder" ,
      required => 0,
	},
   'url' => {
      type      => "=s",
      help      => "url to the Virtual Center", 
	  required => 1,
	},
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate(\&validate);



Util::connect();

my $vm_name = Opts::get_option ('vmname');
my $datacenter = Opts::get_option ('datacenter');
my $folder = Opts::get_option ('folder');
my $pool = Opts::get_option ('pool');
my $host = Opts::get_option ('host');
my $resource = Opts::get_option ('resource');
my $shares = Opts::get_option ('shares');
my $reservation = Opts::get_option ('reservation');
my $limit = Opts::get_option ('limit');
my $name = Opts::get_option ('name');
my $ipaddress = Opts::get_option('ipaddress');
my $powerstatus = Opts::get_option('powerstatus');
my $guestos = Opts::get_option('guestos');
my $vm_views =0;


my %filterHash = create_hash($ipaddress , $guestos );


$vm_views = get_vms ('VirtualMachine', $vm_name,
                      $datacenter, $folder, $pool, $host, %filterHash);


if (!@$vm_views) {
   Util::trace(0, "\nVirtual Machine not found\n");
   exit(1);
}

# get Operation specified
my $op = Opts::get_option('operation');

# calling operation specific functions
if( $op eq "poweron" ){
   poweron_vm();
}
elsif( $op eq "reset" ){
   reset_vm();
}
elsif( $op eq "standby" ){
   standby_vm();
}
elsif( $op eq "poweroff" ){
   poweroff_vm();
}
elsif( $op eq "reboot" ){
   reboot_vm();
}
elsif( $op eq "shutdown" ){
   shutdown_vm();
}
elsif( $op eq "suspend" ){
   suspend_vm();
}
else
{
  no_operation();
}

Util::disconnect();



sub poweron_vm {
   foreach (@$vm_views) {
      if($_->runtime->powerState->val ne 'poweredOff'
                     && $_->runtime->powerState->val ne 'suspended' ) {
         Util::trace(0, "The current state of the Virtual Machine " . $_->name . 
          " is ". $_->runtime->powerState->val." ".
           "The poweron operation is not supported in this state\n" );
         next ;
      }
      Util::trace(0, " Powering on " . $_->name . "\n");
      eval {
         $_->PowerOnVM(); 
      };
      if ($@) { 
         if (ref($@) eq 'SoapFault') {  
         if (ref($@->detail) eq 'InvalidState') {
               Util::trace(0,"VM is already powered on");
            }
         if (ref($@->detail) eq 'NotSupported') {
               Util::trace(0,"virtual machine is marked as a template ");
            }
            else {
               Util::trace(0,"Fault" . $@->fault_string . ""   );
           }
         }
      }
      else { 
         Util::trace(0, "Poweron successfully completed\n");
      }
  }
}


sub reset_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn') {
         Util::trace (0, "The current state of the VM " . $_->name .  
          " is ". $_->runtime->powerState->val." ".
          "The reset operation is not supported in this state\n");
         next ;
      }
      Util::trace(0, "Resetting the VM " . $_->name . "\n");
	  #InvalidState
      eval {
        $_->ResetVM();
      };
      if ($@) {
         if (ref($@) eq 'SoapFault') {
            if (ref($@->detail) eq 'InvalidState') {
               Util::trace(0,"Host is in maintenance mode");
            }
            if (ref($@->detail) eq 'NotSupported') {
               Util::trace(0,"virtual machine is marked as a template ");
            }
            else {
               Util::trace(0,"Fault: " . ref($@->detail));
            }
         }
      }
      else {  
         Util::trace(0, "Reset successfully completed\n");
      }
   }
}

sub standby_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn' ) {
         Util::trace (0, "The current state of the VM " . $_->name . 
          " is ". $_->runtime->powerState->val." ".
          "The standby operation is not supported in this state\n");
         next ;
      }
      Util::trace (0, "Standby VM " . $_->name . "\n");
      eval {
         $_->StandbyGuest(); 
      };
      if ($@) {
         Util::trace(0,"VM"  .$_->name. "can't be set on standby mode \n"
             . $@->fault_string . "" );
      }
      else { 
         Util::trace(0, "Standby successfully completed\n");
      }
  }
}

sub poweroff_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn') {
         Util::trace(0, "The current state of the VM " . $_->name . 
          " is ". $_->runtime->powerState->val." ".
          " The poweroff operation is not supported in this state\n");
         next ;
      }
      Util::trace (0, "Powering off " . $_->name . "\n");
      eval {
      $_->PowerOffVM();
      };
      if ($@) { 
         Util::trace(0, "VM"  .$_->name. "can't be powered off \n"
                      . $@->fault_string . "" );
      }
      else {  
      Util::trace (0, "Poweroff successfully completed\n");
      }

  }
}


sub suspend_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn') {
         Util::trace(0, "The current state of the VM " . $_->name .
			 " is ".  $_->runtime->powerState->val." ". 
			 "The suspend operation is not supported in this state\n");
         next ;
      }
      Util::trace (0, "Suspending VM " . $_->name . "\n");
      eval {
        $_->SuspendVM();
      };
      if ($@) {
          if (ref($@) eq 'SoapFault') {  
			if (ref($@->detail) eq 'NotSupported') {
              Util::trace(0,"virtual machine is marked as a template ");
            }
            else {
               Util::trace(0,"Fault: " . ref($@->detail));
            }
         }
       }
      else { 
         Util::trace (0, "Suspend successfully completed\n");
      }
   }
}


sub shutdown_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn') {
         Util::trace (0,  "The current state of the VM " . $_->name .
			 " is ". $_->runtime->powerState->val." ".
			 " The shutdown operation is not supported in this state\n");
         next ;
      }
      Util::trace (0,  "Shutting down VM " . $_->name . "\n");
      eval {
          $_->ShutdownGuest();
      };
      if ($@) { 
         Util::trace(0, "VM"  .$_->name. "can't be shutdown \n"
                      . $@->fault_string . "" );
      }
      else { 
         Util::trace (0, "Shutdown successfully completed\n"); 
      }
  }
}


sub reboot_vm {
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val ne 'poweredOn') {
         Util::trace(0,  "The current state of the VM " . $_->name .
			 " is ". $_->runtime->powerState->val." ".
			 " The reboot operation is not supported in this state\n");
         next ; 
      }
      Util::trace (0, "Rebooting VM " . $_->name . "\n");
      eval { 
         $_->RebootGuest();
      };
      if ($@) { 
        Util::trace(0,"VM"  .$_->name. "can't reboot \n"
                     . $@->fault_string . ""   );
      }
      else { 
         Util::trace ( 0, "Reboot successfully completed\n");
      }
  }
}

sub no_operation {
    die "\nInvalid argument --operation: '$op' \n
    Supported operations are poweron, poweroff, suspend,
                                      reset, reboot, shutdown and standby  ";
}

#This subroutine is reuired to get the vm's according to the filter criteria
#e.g if its --datacenter , then all the vm's in a particular datacenter are retrieved
sub get_vms {
   my ($entity, $name, $datacenter, $folder, $pool, $host, %filter_hash) = @_;
   my $begin;
   my $entityViews;
   my %filter = %filter_hash;
   my $vms;

   if (defined $datacenter) {
      $begin =
         Vim::find_entity_view (view_type => 'Datacenter',
                                filter => {name => "^$datacenter\$"});

      unless ($begin) {
         Util::trace(0, "Datacenter $datacenter not found.\n");
         return;
      }

   }
   else {
      $begin = Vim::get_service_content()->rootFolder;
   }
   if (defined $folder) {
      my $vms = Vim::find_entity_views (view_type => 'Folder',
                                        begin_entity => $begin,
                                        filter => {name => "^$folder\$"});
      unless (@$vms) {
         Util::trace(0, "Folder <$folder> not found.\n");
         return;
      }
      if ($#{$vms} != 0) {
         Util::trace(0, "Folder <$folder> not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $pool) {
      $vms = Vim::find_entity_views (view_type => 'ResourcePool',
                                     begin_entity => $begin,
                                     filter => {name => "^$pool\$"});
      unless (@$vms) {
         fUtil::trace(0, "Resource pool <$pool> not found.\n");
         return;
      }
      if ($#{$vms} != 0) {
         Util::trace(0, "Resource pool <$pool> not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $host) {
      my $hostView = Vim::find_entity_view (view_type => 'HostSystem',
                                            filter => {'name' => "^$host\$"});
      unless ($hostView) {
         Util::trace(0, "Host $host not found.");
         return;
      }
      $filter{'runtime.host'} = $hostView->{mo_ref}{value};
      $filter{'name'} = "^$name\$" if (defined $name);
      $entityViews = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
      unless (@$entityViews) {
         Util::trace(0, "No Virtual Machine found.\n");
         return;
      }
   }
   elsif (defined $name) {
      $filter{'name'} = "^$name\$" if (defined $name);
      $entityViews = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
      unless (@$entityViews) {
         Util::trace(0, "Virtual Machine $name not found.\n");
         return;
      }
   }
   else {
      $entityViews =
         Vim::find_entity_views (view_type => $entity,
                                 begin_entity => $begin,filter => \%filter);
       unless (@$entityViews) {
          Util::trace(0, "No Virtual Machine found.\n");
          return;
       }
   }

# sort the entities by name
my %entities;
my @sortedEntities;
   foreach (@$entityViews) {
      $entities{$_->name} = $_;
   }
   foreach (
      sort keys %entities) {push (@sortedEntities, $entities{$_});
   }
   if ($entityViews) {return \@sortedEntities;}
   else {return 0;}
}


sub validate {
   my $valid = 1;
   my $operation = Opts::get_option('operation');
   
   if (!defined ( Opts::get_option('vmname')||Opts::get_option('guestos')
      ||Opts::get_option('ipaddress')||Opts::get_option('datacenter')
      ||Opts::get_option('folder')||Opts::get_option('host')
      ||Opts::get_option('pool'))) {
      Util::trace(0,"--vmname or --guestos --ipaddress or --datacenter or
                                   --folder or --host  must be specified. \n");
      $valid = 0;
   }

   
   return $valid;
}


sub create_hash {
my ($ipaddress, $guestos) = @_;
my %filterHash;
   if ($ipaddress) {
      $filterHash{'guest.ipAddress'} = $ipaddress;
   }
   if ($guestos) {
      $filterHash{'config.guestFullName'} ='.*' . $guestos . '.*';
   }
   return %filterHash;
}




__END__

=head1 NAME

vmcontrol.pl - poweron, poweroff, suspend, reset, reboot,
                             shutdown and standby virtual machines.

=head1 SYNOPSIS

vmcontrol.pl --operation <poweron|poweroff|suspend|
    reset|reboot|shutdown|standby> [options]

=head1 DESCRIPTION

This VI Perl command-line utility provides an interface for seven
common provisioning operations: powering, poweringoff, resetting,
rebooting, shutting down, suspending and
setting into standby mode on one or many Virtual Machines.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<operation>

 Operation to be performed.  One of the following:
  I<poweron> (poweron one or more virtual machines),
  I<poweroff> (poweron one or more virtual machines ),
  I<suspend> (suspend one or more virtual machines),
  I<reboot> (reboot one or more virtual machines),
  I<reset> (reset one or more virtual machines),
  I<shutdown> (shutdown one or more virtual machines),
  I<standby> (set to standby mode one or more virtual machines),
  
=item B<url>

URL of the Virtual Data Center

=back
  

=head2 POWEROFF OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<ipaddress>

Optional. ipaddress of the VM machine

One cannot use ipaddress to I<poweron> a VM as in poweredoff state
ipaddress will not be recognised.

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back


=head2 POWERON OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.

=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<host>

Name of the  host for the virtual machine(s).

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=back


=head2 REBOOT OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<ipaddress>

Optional. ipaddress of the VM machine. 

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back



=head2 SHUTDOWN OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<ipaddress>

Optional. ipaddress of the VM machine. 


=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back




=head2 STANDBY OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<ipaddress>

Optional. ipaddress of the VM machine. 

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back


=head2 SUSPEND OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back


=head2 RESET OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine on which
operation is to be performed.


=item B<guestos>

Optional. Name of the guestos of the VM machine. If Windows is given operation
 on all the machines having Windows as OS will be done.

=item B<datacenter>

Optional. Name of the  datacenter for the virtual machine(s).
Operations on all the VMs in the given datacenter will be done.

=item B<pool>

Optional. Name of the  resource pool of the virtual machine(s).
 Operations on all the VMs in the given pool will be done.


=item B<folder>

Optional. Name of the folder which contains the Virtual Machines

Atleast one criteria for selecting the VM's should be specified

=back


=head1 EXAMPLES

Poweron a VM

   perl vmcontrol.pl --username root --password esxadmin --operation poweron 
                --vmname VM3 --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin
                --operation poweron --guestos Windows

   perl vmcontrol.pl --username root --password esxadmin
                  --vmname VM1 --guestos Windows --operation poweron

   perl vmcontrol.pl --username root --password esxadmin --operation poweron
                 --pool poolName --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin
                 --operation poweron --folder folderName

 Via Virtual Center:

   perl vmcontrol.pl --username manir --password mypassword --vmname VM2 
                  --operation poweron --url https://192.168.111.52:443/sdk/webService

   perl vmcontrol.pl --username manir --password mypassword --operation poweron 
                  --url https://192.168.111.52:443/sdk/webService  --pool Zod

   perl vmcontrol.pl --username manir --password mypassword
     	            --operation poweron --url https://192.168.111.52:443/sdk/webService
                  --datacenter Dracula

Poweroff a VM

   perl vmcontrol.pl --username root --password esxadmin --operation poweroff
     	            --vmname VM3 --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin --operation poweroff
     	            --guestos Windows --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin --vmname VM1 
     	            --guestos Windows --operation poweroff
     	            --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin --operation poweroff
     	            --pool poolName --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin --operation poweroff 
     	            --folder folderName --url https://192.168.111.2:443/sdk/webService

   perl vmcontrol.pl --username root --password esxadmin
     	            --operation poweroff --ipaddress 192.168.111.55

 Via Virtual Center:

   perl vmcontrol.pl --username manir --password mypassword --vmname VM2 
     	            --operation poweroff --url https://192.168.111.52:443/sdk/webService

Reboot

   perl vmcontrol.pl --username root --password esxadmin
     	            --operation reboot --vmname VM3
                  --url https://192.168.111.2:443/sdk/webService

Shutdown

   perl vmcontrol.pl --username root --password esxadmin --operation shutdown
     	            --vmname VM3

Reset

   perl vmcontrol.pl --username root --password esxadmin --operation reset
     	            --vmname VM3

   perl vmcontrol.pl --username manir --password mypassword --vmname VM2 
     	            --operation reset --url https://192.168.111.52:443/sdk/webService

Standby

   perl vmcontrol.pl --username root --password esxadmin --operation standby
     	            --vmname VM3

Suspend

   perl vmcontrol.pl --username root --password esxadmin --operation suspend
     	            --vmname VM3

   perl vmcontrol.pl --username manir --password mypassword --vmname VM2 
     	            --operation suspend --url https://192.168.111.52:443/sdk/webService

 Follow the same pattern for other operations :
 reset , shutdown, reboot, standby, suspend like in poweron and poweroff


=head1 SUPPORTED PLATFORMS

All operations supported on ESX 3.0.1

All operations supported on Virtual Center 2.0.1





