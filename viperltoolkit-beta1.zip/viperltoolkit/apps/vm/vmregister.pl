#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;

sub register;
sub unregister;
sub validate;
sub get_host;

my %opts = (
   'operation' => {
      type => "=s",
      help => "Operation to be performed on the VM: register, unregister",
      required => 1,
   },
   'vmname' => {
      type => "=s",
      help => "Name of the virtual machine",
      required => 1,
   },
   'datacenter' => {
      type => "=s",
      help => "Name of the datacenter",
      required => 0,
   },
   'vmxpath' => {
      type => "=s",
      help => "The vmx path",
      required => 0,
   },
   'respool' => {
      type => "=s",
      help => "Name of the resource pool to add vm to",
      required => 0,
   },
   'hostname' => {
      type => "=s",
      help => "Name of the esx host  to register the vm",
      required => 0,
   },
);


Opts::add_options(%opts);
Opts::parse();

my $pool;
my $host_view;
my $op = Opts::get_option('operation');
my $hostname = Opts::get_option('hostname'); 
my $resourcepool = Opts::get_option('respool');
my $vmxpath = Opts::get_option('vmxpath');
my $vmname = Opts::get_option('vmname');
my $datacenter = Opts::get_option('datacenter');

Opts::validate(\&validate);

Util::connect();

if ($op eq "register") {
   register();
} elsif ($op eq "unregister") {
   unregister();
}

Util::disconnect();

# Handles the register request for registering the VM
sub register() {
   if(defined(Opts::get_option('hostname'))) {
      $host_view = get_host();
   } else {
        Util::trace(0,"\nNo host specified. Default/standalone host will be used.\n");
   }
   my $begin = Vim::find_entity_view (view_type => 'Datacenter',
                                         filter => {name => "^$datacenter\$"});
   if (!$begin) {
      Util::trace(0, "\nNo data center found with name: $datacenter\n");
      return;
   }

   my $folder_view = Vim::find_entity_view(view_type => 'Folder',
                                           begin_entity => $begin,
                                           filter => {'childType' => "VirtualMachine"});
   if (!$folder_view) {
      Util::trace(0, "\nNo Folder found corresponding data center : $datacenter\n");
      return;
   }

   $pool = Vim::find_entity_view(view_type => 'ResourcePool',
                                 filter => { 'name' => '^' . $resourcepool . '$' } );
   if (!$pool) {
      Util::trace(0, "\nResource pool $resourcepool not found\n");
      return;
   }

   eval {
      my $response = $folder_view->RegisterVM(path => $vmxpath,
                                              name => $vmname,
                                              asTemplate => 'false',
                                              pool => $pool,
                                              host => $host_view);
      Util::trace(0,"\nRegister of VM  '$vmname' successfully completed\n");
   };
   if ($@) {
      if (ref($@) eq 'SoapFault') {
         if (ref($@->detail) eq 'AlreadyExists') {
            Util::trace(0,"\nVM $vmname already registered\n");
         }
         else {
            Util::trace(0,"\nFault: " . ref($@->detail));
         }
      }
   }
}



sub get_host {
   $host_view = Vim::find_entity_view(view_type => 'HostSystem',
                                      filter => { 'name' => '^' . $hostname . '$'});
   return $host_view;
}


# This is required to unregister the VM
sub unregister() {
   if ($op eq "unregister") {
      my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                       filter => {'config.name' => $vmname});
      if (!@$vm_views) {
         Util::trace(0, "\nThere is no VM '$vmname' registered\n");
         return;
      }
      foreach (@$vm_views){
         if ($_->runtime->powerState->val eq 'poweredOn'){
            Util::trace(0, "For $op VM $vmname should be powered off");
         }
         else{
            $_->UnregisterVM();
            Util::trace(0,"\nUnregister of VM '$vmname' successfully completed\n");
            last;
         }
      }
   }
}

sub validate {
   my $valid = 1;
   if (defined(Opts::get_option('operation'))) {
      if (($op ne 'register') && ($op ne 'unregister')) {
         Util::trace(0,"\nERROR: Invalid operation $op specified\n");
         $valid = 0;
      }
   }
   if (defined(Opts::get_option('operation'))) {
      if ($op eq 'register') {
         if (!defined(Opts::get_option('respool'))) {
            Util::trace(0,"\nERROR: Missing --respool\n");
            $valid = 0;
         }
         if (!defined(Opts::get_option('datacenter'))) {
            Util::trace(0,"\nERROR: Missing --datacenter\n");
            $valid = 0;
         }
         if (!defined(Opts::get_option('vmxpath'))){
            Util::trace(0,"\nERROR: Missing --vmxpath\n");
            $valid = 0;
         }
      }
   }
   return $valid;
}

__END__

=head1 NAME

vmregister.pl - registers/unregisters virtual machine

=head1 SYNOPSIS

vmregister.pl  --url <web service URL> --username <server login name>
               --password <server login password> --operation <register/unregister>
               --vmname <virtual machine name> [--hostname <name of the host>]
                [--vmxpath <Path of the vmx location>]  [--respool <resource pool>]
                [--datacenter <datacenter name>]

=head1 DESCRIPTION

This VI Perl command-line utility allows users to register a VM to a specified 
host and resource pool. Operations are register and unregister.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<operation>

Required. Operation to be performed. Must be one of the following:
I<register> (register a virtual machine to a specified host and
resource pool)
I<unregister> (unregister an already registered virtual machine).

=item B<vmname>

Required.For I<register>, name of the virtual machine to register and I<unregister>
operation, the name of the virtual machine to unregister.

=back

=head2 REGISTER OPTIONS

=over

=item B<operation>

Required. I<register> (register a virtual machine to a specified host and
resource pool)

=item B<vmname>

Required.For I<register>, name of the virtual machine to register.

=item B<respool>

Required. Resource Pool to add virtual machine to.

=item B<datacenter>

Required. Name of the Data Center.

=item B<hostname>

Required. ESX host name to register the virtual machine.

=item B<vmxpath>

Required. Path of the vmx location.

=back


=head2 UNREGISTER OPTIONS

=over

=item B<operation>

Required. I<unregister> (unregister an already registered virtual machine).

=item B<vmname>

Required.For I<unregister> operation, the name of the virtual machine to unregister.

=back

=head1 EXAMPLES

Registering a virtual machine

   vmregister.pl  --url https://192.168.111.52/sdk/vimService --username administrator
               --password mypassword --operation register --vmname FC5
               --hostname MYESX.InterraIT.info --vmxpath [lazy_100gb]FC/FC.vmx
               --respool PoolABC --datacenter Datacenter2

Unregistering a virtual machine

   vmregister.pl --url https://192.168.111.52/sdk/vimService --username administrator
              --password mypassword --operation unregister --vmname FC5
              --hostname MYESX.InterraIT.info

=head1 SUPPORTED PLATFORMS

All operations work with VMware VirtualCenter 2.0 or later.

All operations work with VMware ESX Server 3.0 or later.
