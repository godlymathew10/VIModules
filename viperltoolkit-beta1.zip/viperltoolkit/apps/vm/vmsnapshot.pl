#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;

sub get_virtual_machines;
sub create_hash;
sub create_snapshots;

my %opts = (
   sname  => {
      type     => "=s",
      variable => "sname",
      help     => "Snapshot name",
      required => 1,
   },

   datacenter  => {
      type     => "=s",
      variable => "datacenter",
      help     => "Source datacenter",
   },

   pool  => {
      type     => "=s",
      variable => "pool",
      help     => "Source resource pool",
   },

   host => {
      type     => "=s",
      variable => "host",
      help     => "Source host",
   },

   folder => {
      type     => "=s",
      variable => "folder",
      help     => "Source folder",
   },

   vmname => {
      type     => "=s",
      variable => "vmname",
      help     => "Virtual Machine Name",
   },

   ipaddress   => {
      type     => "=s",
      variable => "ipaddress",
      help     => "The IP address of the virtual machine",
   },
   
   powerstatus => {
      type     => "=s",
      variable => "  powerstatus",
      help     => "The state of the virtual machine",
   },

   guest_os    => {
      type     => "=s",
      variable => "guest_os",
      help     => "The guest OS running on virtual machine",
   },
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate();

my %filter_hash = create_hash(Opts::get_option('ipaddress'),
                              Opts::get_option('powerstatus'),
                              Opts::get_option('guest_os'));
Util::connect();

my $vm_views = get_virtual_machines ('VirtualMachine',
                                      Opts::get_option ('vmname'),
                                      Opts::get_option ('datacenter'),
                                      Opts::get_option ('folder'),
                                      Opts::get_option ('pool'),
                                      Opts::get_option ('host'),
                                      %filter_hash);

create_snapshots($vm_views);

Util::disconnect();


# This subroutine finds the VMs based on the selection criteria.
# Selection criteria can be datacenter, folder name, resource pool,
# hostname etc. All the virtual machines in a particular datacenter or 
# in a host will be extracted.
# =====================================================================
sub get_virtual_machines {
   my ($entity, $name, $datacenter, $folder, $pool, $host, %filter_hash) = @_;
   my $begin;
   my $entity_views;
   my %filter = %filter_hash;
   my $vms;

   if (defined $datacenter) {
      $begin = Vim::find_entity_view (view_type => 'Datacenter',
                                      filter => {name => "^$datacenter\$"});
      unless ($begin) {
         Util::trace(0, "Datacenter $datacenter not found.\n");
         return;
      }
   }
   else {
        $begin = Vim::get_service_content()->rootFolder;
   }
   if (defined $folder) {
      my $vms = Vim::find_entity_views (view_type => 'Folder',
                                        begin_entity => $begin,
                                        filter => {name => "^$folder\$"});
      unless (@$vms) {
         Util::trace(0, "Folder $folder not found.\n");
         return;
      }
      if ($#{$vms} != 0) {
         Util::trace(0, "Folder $folder not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $pool) {
      $vms = Vim::find_entity_views (view_type => 'ResourcePool',
                                     begin_entity => $begin,
                                     filter => {name => "^$pool\$"});
       unless (@$vms) {
          Util::trace(0, "Resource pool $pool not found.\n");
          return;
       }
      if ($#{$vms} != 0) {
         Util::trace(0, "Resource pool $pool not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $host) {
      my $hostView = Vim::find_entity_view (view_type => 'HostSystem',
                                            filter => {'name' => "^$host\$"});
      unless ($hostView) {
         Util::trace(0, "Host $host not found.");
         return;
      }
      $filter{'runtime.host'} = $hostView->{mo_ref}{value};
      $filter{'name'} = ".*$name.*" if (defined $name);
      $entity_views = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
       unless (@$entity_views) {
          Util::trace(0, "No Virtual Machine found.\n");
          return;
       }
   } elsif (defined $name) {
      $filter{'name'} = ".*$name.*" if (defined $name);
      $entity_views = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
       unless (@$entity_views) {
          Util::trace(0, "Virtual Machine with substring $name not found.\n");
          return;
       }
   }
   else {
      $entity_views = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                              filter => \%filter);
       unless (@$entity_views) {
          Util::trace(0, "No Virtual Machine found.\n");
          return;
       }
   }

# All the virtual machines retrieved are sorted by name
   my %entities;
   my @sorted_entities;
   foreach (@$entity_views) {
      $entities{$_->name} = $_;
   }
   foreach (sort keys %entities) {
      push (@sorted_entities, $entities{$_});
   }
   if ($entity_views) {
      # Print VM names
      Util::trace(0, "\n* * * Following virtual machines found * * *\n");
      foreach (@sorted_entities) {
         Util::trace(0, "\n -: ");
         Util::trace(0, $_->name);
      }
      Util::trace(0, "\n");
      return \@sorted_entities;
   }
   else {
      return 0;
   }
}

# Snapshots of all the vm's extracted in get_virtual_machines methode are created
# by calling the CreateSnapshot method and passing name of the snapshot and description
# as parameters.
# =====================================================================================
sub create_snapshots {
   my $vm_views = shift;
   my $sname = Opts::get_option ('sname');
   foreach (@$vm_views) {
      eval {
         $_->CreateSnapshot(name => $_->name . '$' . $sname,
                            description => 'Snapshot created for virtual machine: '
                                           . $_->name ,
                            memory => 0,
                            quiesce => 0);
         Util::trace(0, "\nSnapshot '" . $_->name . '$' . $sname
                      . "' completed for VM: " . $_->name);
      };
      if ($@) {
         Util::trace(0, "\nError creating snapshot of virtual Machine: " . $_->name);
         if (ref($@) eq 'SoapFault') {
            if (ref($@->detail) eq 'FileFault') {
               Util::trace(0,"\nFailed to access the virtual machine files\n");
            }
            if (ref($@->detail) eq 'InvalidName') {
                Util::trace(0,"\nSpecified snapshot name is invalid\n");
            }
            if (ref($@->detail) eq 'InvalidState') {
                Util::trace(0,"\nThe operation is not allowed in the current state.\n");
            }
            if (ref($@->detail) eq 'InvalidPowerState') {
                Util::trace(0,"\nCurrent power state of the virtual machine '"
                             . $_->name . "' is invalid\n");
            }
            if (ref($@->detail) eq 'NotSupported') {
                Util::trace(0,"\nHost does not support snapshots \n");
            }
            if (ref($@->detail) eq 'RuntimeFault') {
                Util::trace(0,"\nFault: " . ref($@->detail) . "\n");
            }
            if (ref($@->detail) eq 'SnapshotFault') {
                Util::trace(0, "\nError occurs during the snapshot operation.\nFault: "
                             . ref($@->detail) . "\n");
            }
            if (ref($@->detail) eq 'TaskInProgress') {
                Util::trace(0,"\nVirtual machine '" . $_->name . "' is busy\n");
            }
            if (ref($@->detail) eq 'VmConfigFault') {
                Util::trace(0,"\nVirtual machine's configuration is invalid\n");
            }
         } else {
             Util::trace(0,"\nError occurred : \n" . $@ . "\n");
         }
      }
      
   }
Util::trace(0, "\n");
}

sub create_hash {   
   my ($ipaddress, $powerstatus, $guest_os) = @_;
   my %filter_hash;
   if ($ipaddress) {
      $filter_hash{'guest.ipAddress'} = $ipaddress;
   }
   if ($powerstatus) {
      $filter_hash{'runtime.powerState'} = $powerstatus;
   }
   if ($guest_os) {
      $filter_hash{'config.guestFullName'} ='.*' . $guest_os . '.*';
   }
   return %filter_hash;
}


__END__

=head1 NAME

vmsnapshot.pl - Creates snapshots of virtual machines.

=head1 SYNOPSIS

 vmsnapshot.pl --url <web service URL> --username <server login name>
            --password <server login password> --sname <snapshot name>
            [--vmname <virtual machine name>] [--host <host name>]
            [--datacenter <datacenter name>] [--folder <folder name>]
            [--ipaddress <IP address of the virtual machine>]
            [-- powerstatus <virtual machine status>]
            [--guest_os <guest OS running>] [--pool <resource pool name>]

=head1 DESCRIPTION

This VI Perl command-line utility creates snapshots of virtual machines
based on the filter criteria. A snapshot captures the entire state of
a virtual machine at the time the user take the snapshot.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<sname>

Required. The name of the snapshot. The name of the newly created snapshot will
be the concatenation of virtual machine name and 'sname'. For example
if the virtual machine name is 'VM2' and sname is 'snap23', the name
of the newly created snapshot will be VM2$snap23

=back

=head2 VM OPTIONS

=over

=item B<vmname>

Optional. Name of the virtual machine whose snapshot is to be created. 'vnmame' can
also be a sub string. Suppose you want to create snapshot of all the virtual
machine which contains the sub string 'ba', then 'vmname' should be 'ba'. If
this option is not specified, then the CreateSnapshot operation will be performed
on a set of virtual machines based on the other parameters.

=item B<powerstatus>

Optional. Power state of the virtual machine.

=item B<ipaddress>

Optional. IP address of the virtual machine.

=item B<guest_os>

Optional. Guest operating system running on the virtual machine.

=back

=head2 INVENTORY OPTIONS

=over

=item B<host>

Optional. Name of the host.

=item B<datacenter>

Optional. Name of the datacenter.

=item B<folder>

Optional. Folder name.

=item B<pool>

Optional. Name of the resource pool.

=back

=head1 EXAMPLES

Create snapshots for all the virtual machines which are in resource pool 'PoolA'
and whose power status is 'ON'. Let the name of the snapshot be 'Snap14May':

    vmsnapshot.pl --url https://192.168.111.52:443/sdk/webService
      --username administrator --password mypassword
      --sname Snap14May --pool PoolA --powerstatus On

Create snapshots for all the virtual machines which are in datacenter 'CenterABC',
resource pool 'PoolA' and whose power status is 'ON'. Let the name of the
snapshot be 'Snap14May':

    vmsnapshot.pl --url https://192.168.111.52:443/sdk/webService
      --username administrator --password mypassword
      --sname Snap14May  --datacenter CenterABC --pool PoolA
      --powerstatus On

Create snapshots for all the virtual machines which are in folder 'Team2'
and whose guest OS is linux. Let the name of the snapshot be 'Snap14May':

    vmsnapshot.pl --url https://192.168.111.52:443/sdk/webService
      --username administrator --password mypassword
      --sname Snap14May --folder Team2 --geustOS linux

Create snapshots for all the virtual machines whoose name contains string 'VM2'.
Let the name of the snapshot be 'Snap14May':

    vmsnapshot.pl --url https://192.168.111.52:443/sdk/webService
      --username administrator --password mypassword
      --sname Snap14May --vmname VM2

=head1 KNOWN ISSUE

If you suspend a virtual machine and then take two successive snapshots,
the second snapshot operation fails with the error "Failure due to a malformed
request to the server". This error is expected and does not indicate a problem,
because suspended virtual machines do not change, the second snapshot would
overwrite the existing snapshot with identical data.


=head1 SUPPORTED PLATFORMS

All operations work with VMware VirtualCenter 2.0.1

All operations work with VMware ESX Server 3.0.1.

