#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;

sub usage;
sub validate;

my %opts = (
   datacenter  => {
      type     => "=s",
      variable => "datacenter",
      help     => "Source datacenter"
   },

   pool  => {
      type     => "=s",
      variable => "pool",
      help     => "Source resource pool"
   },

   host => {
      type      => "=s",
      variable  => "host",
      help      => "Source host"
   },

   folder => {
      type      => "=s",
      variable  => "folder",
      help      => "Source folder"
   },

   vmname => {
      type      => "=s",
      variable  => "vmname",
      help       => "Virtual Machine Name"
   },

   IPaddress => {
      type => "=s",
      variable => "IPaddress",
      help => "IP address of the virtual machine"
   },

   powerstatus => {
      type => "=s",
      variable => "  powerstatus",
      help => "State of the virtual machine"
   },

   guestOS => {
      type => "=s",
      variable => "guestOS",
      help => "Guest OS running on virtual machine"
   },
      
   operation => {
      type => "=s",
      help => "Operation to be performed"
   },

   target => {
      type => "=s",
      help => "Target Host"
   },
      
   revert => {
      type => "=s",
      help => "Name of snapshot to revert back"
   },
      
   'rename' => {
      type => "=s",
      help => "Name of snapshot to rename"
   },
      
   name => {
      type => "=s",
      help => "Name of snapshot after renaming"
   },
      
   remove => {
      type => "=s",
      help => "Name of the snapshot to be removed"
   },
      
   children => {
      type => "=s",
      help => "0|1"
   },
      
   snapshotname => {
      type => "=s",
      help => "Name of the snapshot to be created"
   },
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate(\&validate);

my $vm_name = Opts::get_option ('vmname');
my $datacenter = Opts::get_option ('datacenter');
my $folder = Opts::get_option ('folder');
my $pool = Opts::get_option ('pool');
my $host = Opts::get_option ('host');
my $resource = Opts::get_option ('resource');
my $shares = Opts::get_option ('shares');
my $reservation = Opts::get_option ('reservation');
my $limit = Opts::get_option ('limit');
my $name = Opts::get_option ('name');
my $ipaddress = Opts::get_option('IPaddress');
my $powerstatus = Opts::get_option('powerstatus');
my $guest_os = Opts::get_option('guestOS');

my %filter_hash = create_hash($ipaddress, $powerstatus, $guest_os);

my %operations = (
   "List",""
   ,"Revert",""
   ,"Goto", ""
   ,"Rename", ""
   ,"Remove",""
   ,"RemoveAll",""
   ,"Create", ""
);

# Validation Operation Argument
my $operation = Opts::get_option('operation');
if (!exists($operations{$operation})) {
   print "Unknown operation: '$operation'\n";
   print "List of valid operations:\n";
   map {print "   $_\n"; } %operations;
   exit(1);
}

Util::connect();

if ($operation eq 'List') {
  list_snapshot();
} if ($operation eq 'Create') {
  create_snapshot();
} if ($operation eq 'Revert') {
  revert_snapshot();
} if ($operation eq 'Goto') {
  goto_snapshot();
} if ($operation eq 'Rename') {
  rename_snapshot();
} if ($operation eq 'RemoveAll') {
  remove_all_snapshot();
} if ($operation eq 'Remove') {
  remove_snapshot();
}

Util::disconnect();

#This Subroutine List All the Snapshot for Virtual Machine.
#=========================================================
sub list_snapshot {
   my $vm_views = get_vms ('VirtualMachine', $vm_name, $datacenter, $folder,
                            $pool, $host, %filter_hash);
   foreach (@$vm_views) {
      my $count = 0;
      my $snapshots = $_->snapshot;
      next unless ($snapshots);

      Util::trace(0,"\nSnapshots for Virtual Machine ".$_->name, "\n");
      printf "\n%-47s%-16s %s %s\n", "Name", "Date","State", "Quiesced";

      print_tree ($_->snapshot->currentSnapshot, " ", $_->snapshot->rootSnapshotList);
   }
}

# Create: Creates a snapshot for one or more VMs.
# ==============================================
sub create_snapshot {
   my $vm_views = get_vms ('VirtualMachine', $vm_name, $datacenter, $folder,
                            $pool, $host, %filter_hash);
   my $snapshot_name = Opts::get_option('snapshotname');
   foreach (@$vm_views) {
      eval {
         $_->CreateSnapshot(name => $_->name.'$'.$snapshot_name,
                description => 'Snapshot created for Virtual Machine '.$_->name,
                memory => 0,
                quiesce => 0);

          Util::trace(0, "\n\nSnapshot for virtual machine ". $_->name .
                     " created sucessfully \n\n");
      };
      if ($@) {
         if (ref($@) eq 'SoapFault') {
            Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
         }
      }
   }
}


#Revert: Reverts to the current snapshot for a single VM.
#==============================
sub revert_snapshot {
   my $vmname = Opts::get_option('vmname');
   my $target_host = Opts::get_option('target');
   
   my $vm_view =
      Vim::find_entity_view(view_type => 'VirtualMachine',
                            filter => {"config.name" => $vmname});
   if ($vm_view) {
      if (defined $target_host) {
         my $target =
            Vim::find_entity_view (view_type => 'HostSystem',
                                   filter => $target_host);
         if (defined $target) {
            eval {
               $vm_view->RevertToCurrentSnapshot(host => $target);
               Util::trace(0, "\n\nOperation::Revert To Current Snap Shot For Virtual "
                            . "Machine " . $vm_view->name
                            . " completed sucessfully\n\n");
            };
            if ($@) {
               if (ref($@) eq 'SoapFault') {
                  Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
               }
            }
         }
         else {
            Util::trace(0, "Invlid parameter target");
         }
      }
      else {
         eval{
            $vm_view->RevertToCurrentSnapshot();
            Util::trace(0, "\n\nOperation::Revert To Current Snap Shot For Virtual "
                         . "Machine " . $vm_view->name ." completed sucessfully\n\n");
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
            }
         }
      }
   }
}

# Goto: Reverts to the specified snapshot for a single VM.
# ========================================================
sub goto_snapshot {
   my $vmname = Opts::get_option('vmname');
   my $target_host = Opts::get_option('target');
   my $revert_snapshot = Opts::get_option('revert');
    
   my $vm_view = Vim::find_entity_view(view_type => 'VirtualMachine',
                                       filter => {"config.name" => $vmname});
   if ($vm_view) {
      my ($ref, $nRefs) = find_snapshot_name ($vm_view->snapshot->rootSnapshotList,
                                              $revert_snapshot);
      if (defined $ref && $nRefs == 1) {
         my $snapshot = Vim::get_view (mo_ref =>$ref->snapshot);
         if (defined $target_host) {
            my $target = Vim::find_entity_view (view_type => 'HostSystem',
                                                filter => {name => $target_host});
            if (defined $target) {
               eval {
                  $snapshot->RevertToSnapshot(host => $target);
                  Util::trace(0, "\n\nOperation :: Revert To Snap Shot "
                                 . $revert_snapshot
                                 . " For Virtual Machine ". $vm_view->name
                                 . " completed sucessfully\n\n");
               };
               if ($@) {
                  if (ref($@) eq 'SoapFault') {
                     Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
                  }
               }
            }
            else {
               Util::trace(0, "Parameter target not defined");
            }
         }
         else {
            eval{
               $snapshot->RevertToSnapshot();
               Util::trace(0, "\n\nOperation :: Revert To Snap Shot ". $revert_snapshot
                            . " For Virtual Machine ". $vm_view->name
                            . " completed sucessfully\n\n");
            };
            if ($@) {
               if (ref($@) eq 'SoapFault') {
                  Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
               }
            }
         }
      }
      else {
         if ($nRefs > 1) {
            Util::trace(0,"\n\nMore than one snapshot exits with name"
                           ." $revert_snapshot\n\n");
         }
         if($nRefs == 0 ) {
            Util::trace(0,"\n\nSnapshot Not Found with name $revert_snapshot\n\n");
         }
      }
   }
}

# Rename: renames a named snapshot for a single VM.
# ================================================
sub rename_snapshot {
   my $vmname = Opts::get_option('vmname');
   my $name = Opts::get_option('name');
   my $rename_snapshot = Opts::get_option('rename');
    
    
   my $vm_view =
      Vim::find_entity_view(view_type => 'VirtualMachine',
                            filter => {"config.name" => $vmname});
   if ($vm_view) {
      my ($ref, $nRefs) =
         find_snapshot_name ($vm_view->snapshot->rootSnapshotList, $rename_snapshot);
      if (defined $ref && $nRefs == 1) {
         my $snapshot = Vim::get_view (mo_ref =>$ref->snapshot);
         eval{
            $snapshot->RenameSnapshot (name => $name);
            Util::trace(0, "\n\nOperation:: Rename Snap Shot ". $rename_snapshot . " for"
                         . " Virtual Machine ".$vm_view->name
                         ." completed sucessfully\n\n");
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
            }
         }
      }
      else {
         if ($nRefs > 1) {
            Util::trace(0,"\n\nMore than one snapshot exits with name"
                                ."$rename_snapshot\n\n");
         }
         if($nRefs == 0 ) {
            Util::trace(0,"\n\nSnapshot Not Found with name $rename_snapshot\n\n");
         }
      }
   }
}

#Removeall: removes all snapshots for a single VM.
#==============================
sub remove_all_snapshot {
   my $vmname = Opts::get_option('vmname');
    
   my $vm_view = Vim::find_entity_view(view_type => 'VirtualMachine',
                                       filter => {"config.name" => $vmname});
   if ($vm_view) {
      eval {
         $vm_view->RemoveAllSnapshots();
         Util::trace(0, "\n\nOperation :: Remove All Snap Shot For Virtual Machine"
                      . $vm_view->name ." completed sucessfully\n\n");
      };
      if ($@) {
         if (ref($@) eq 'SoapFault') {
            Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
         }
      }
   }
}

# Remove: removes a named snapshot for one or more virtual machines.
# ==================================================================
sub remove_snapshot {
   my $children = Opts::get_option('children');
   my $remove_snapshot = Opts::get_option('remove');
    
   my $vm_views =
      get_vms ('VirtualMachine', $vm_name, $datacenter, $folder,
               $pool, $host, %filter_hash);
   for (@$vm_views) {
      my ($ref, $nRefs) =
         find_snapshot_name ($_->snapshot->rootSnapshotList, $remove_snapshot);
      if (defined $ref && $nRefs == 1) {
         my $snapshot = Vim::get_view (mo_ref =>$ref->snapshot);
         eval {
            $snapshot->RemoveSnapshot (removeChildren => $children);
             Util::trace(0, "\n\nOperation :: Remove Snap Shot ". $remove_snapshot .
                            " For Virtual Machine ". $_->name 
                            ." completed sucessfully\n\n");
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               Util::trace(0, "\nFault: " . ref($@->detail) . "\n\n");
            }
         }
      }
      else {
         if ($nRefs > 1) {
            Util::trace(0,"\n\nMore than one snapshot exits with name"
                          ." $remove_snapshot\n\n");
         }
         if($nRefs == 0 ) {
            Util::trace(0,"\n\nSnapshot Not Found with name $remove_snapshot\n\n");
         }
      }
   }
}


# Print The Snapshot Tree For The Given Virtual Machine in tree format
# Because all snapshot for virtual machine are stored as per child 
# relationship structure.
# =====================================================
sub print_tree {
   my ($ref, $str, $tree) = @_;
   my $head = " ";
   foreach my $node (@$tree) {
      $head = ($ref->value eq $node->snapshot->value) ? " " : " " if (defined $ref);
      my $quiesced = ($node->quiesced) ? "Y" : "N";
      printf "%s%-48.48s%16.16s %s %s\n", $head, $str.$node->name,
             $node->createTime, $node->state->val, $quiesced;
      print_tree ($ref, $str . " ", $node->childSnapshotList);
   }
   return;
}


#  Find a snapshot with the name
#  This either returns: The reference to the snapshot
#  0 if not found & 1 if it's a duplicate
#  Duplicacy check is required for rename, remove and revert operations
#  For these operation specified snapshot name must be unique
# ==================================================
sub find_snapshot_name {
   my ($tree, $name) = @_;
   my $ref = undef;
   my $count = 0;
   foreach my $node (@$tree) {
      if ($node->name eq $name) {
         $ref = $node;
         $count++;
      }
      my ($subRef, $subCount) = find_snapshot_name($node->childSnapshotList, $name);
      $count = $count + $subCount;
      $ref = $subRef if ($subCount);
   }
   return ($ref, $count);
}

sub create_hash {
   my ($ipaddress, $powerstatus, $guest_os) = @_;
   my %filter_hash;
   if ($ipaddress) {
      $filter_hash{'guest.ipAddress'} = $ipaddress;
   }
   if ($powerstatus) {
      $filter_hash{'runtime.powerState'} = $powerstatus;
   }
   if ($guest_os) {
      $filter_hash{'config.guestFullName'} ='.*' . $guest_os . '.*';
   }
   return %filter_hash;
}

# This subroutine finds the VMs based on the selection criteria.
# Selection criteria can be datacenter, folder name, resource pool,
# hostname etc. All the virtual machines in a particular datacenter or 
# in a host will be extracted.
# =====================================================================
sub get_vms {
   my ($entity, $name, $datacenter, $folder, $pool, $host, %filter_hash) = @_;
   my $begin;
   my $entityViews;
   my %filter = %filter_hash;
   my $vms;

   if (defined $datacenter) {
      $begin =
         Vim::find_entity_view (view_type => 'Datacenter',
                                filter => {name => "^$datacenter\$"});
                                
      unless ($begin) {
         Util::trace(0, "Datacenter $datacenter not found.\n");
         return;
      }

   }
   else {
      $begin = Vim::get_service_content()->rootFolder;
   }
   if (defined $folder) {
      my $vms = Vim::find_entity_views (view_type => 'Folder',
                                        begin_entity => $begin,
                                        filter => {name => "^$folder\$"});
      unless (@$vms) {
         Util::trace(0, "Folder <$folder> not found.\n");
         return;
      }
      if ($#{$vms} != 0) {
         Util::trace(0, "Folder <$folder> not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $pool) {
      $vms = Vim::find_entity_views (view_type => 'ResourcePool',
                                     begin_entity => $begin,
                                     filter => {name => "^$pool\$"});
      unless (@$vms) {
         fUtil::trace(0, "Resource pool <$pool> not found.\n");
         return;
      }
      if ($#{$vms} != 0) {
         Util::trace(0, "Resource pool <$pool> not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $host) {
      my $hostView = Vim::find_entity_view (view_type => 'HostSystem',
                                            filter => {'name' => "^$host\$"});
      unless ($hostView) {
         Util::trace(0, "Host $host not found.");
         return;
      }
      $filter{'runtime.host'} = $hostView->{mo_ref}{value};
      $filter{'name'} = "^$name\$" if (defined $name);
      $entityViews = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
      unless (@$entityViews) {
         Util::trace(0, "No Virtual Machine found.\n");
         return;
      }
   }
   elsif (defined $name) {
      $filter{'name'} = "^$name\$" if (defined $name);
      $entityViews = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
      unless (@$entityViews) {
         Util::trace(0, "Virtual Machine $name not found.\n");
         return;
      }
   }
   else {
      $entityViews =
         Vim::find_entity_views (view_type => $entity,
                                 begin_entity => $begin,filter => \%filter);
       unless (@$entityViews) {
          Util::trace(0, "No Virtual Machine found.\n");
          return;
       }
   }
   # sort the entities by name
   my %entities;
   my @sortedEntities;
   foreach (@$entityViews) {
      $entities{$_->name} = $_;
   }
   foreach (sort keys %entities) {
      push (@sortedEntities, $entities{$_});
   }
   if ($entityViews) {return \@sortedEntities;}
   else {return 0;}
}

# This subroutine validates the arguemnt
# 1) snapshot arguemnt is required for Create operation
# 2) revert arguement is required for Goto operation
# 3) rename arguemnt is required for Rename operation
# 4) remove and children arguemnt is required for Remove operation.
# ===============================
sub validate {
   my $operation = Opts::get_option('operation');
   my $valid = 1;
   if ($operation && ($operation eq 'Create') 
      && (!Opts::option_is_set('snapshotname'))) {
      Util::trace(0, "Must specify snapshotname for operation Create");
      $valid = 0;
   }
   if ($operation && ($operation eq 'Revert') && (!Opts::option_is_set('vmname'))) {
      Util::trace(0, "Must specify vmname for operation Revert");
     $valid = 0;
   }
   if ($operation && ($operation eq 'Goto') && ((!Opts::option_is_set('vmname'))
      || (!Opts::option_is_set('revert')))) {
      Util::trace(0, "Must specify vmname and revert for operation Goto");
      $valid = 0;
   }
   if ($operation && ($operation eq 'Rename') && ((!Opts::option_is_set('vmname'))
      || (!Opts::option_is_set('name')) || (!Opts::option_is_set('rename')))) {
      Util::trace(0, "Must specify vmname, name, rename for operation Rename");
      $valid = 0;
   }
   if ($operation && ($operation eq 'RemoveAll') && (!Opts::option_is_set('vmname'))) {
      Util::trace(0, "Must specify vmname for operation RemoveAll");
      $valid = 0;
   }
   if ($operation && ($operation eq 'Remove') && ((!Opts::option_is_set('remove'))
      || (!Opts::option_is_set('children')))) {
      Util::trace(0, "Must specify remove and children for operation Remove");
      $valid = 0;
   }
   return $valid;
}

__END__


=head1 NAME

snapshotmanager.pl - List, Create, Revert, Goto, Rename, Remove, Remove All Snapshot/s.

=head1 SYNOPSIS

snapshotmanager.pl --operation <List|Create|Revert|Goto|Rename|Remove|RemoveAll> [options]

=head1 DESCRIPTION

This VI Perl command-line utility provides an interface for seven
basic operations for Snapshot:

 Listing all snapshots for one or more virtual machines,
 Creating a snapshot for one or more virtual machines,
 Reverting to the current snapshot for a single virtual machine,
 Reverting to the specified snapshot for a single virtual machine,
 Renaming a named snapshot for a single virtual machine,
 Removing all snapshots for a single virtual machine,
 Removing a named snapshot for one or more virtual machines.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<operation>

 Operation to be performed.  Must be one of the following:
  I<List> (List all snapshots for one or more virtual machines),
  I<Create> (Creating a snapshot for one or more virtual machines),
  I<Revert> (Reverting to the current snapshot for a single virtual machine),
  I<GoTo>   (Reverting to the specified snapshot for a single virtual machine),
  I<Rename> (Renaming a named snapshot [and children] for a single virtual machine),
  I<RemoveAll> (Removing all snapshots for a single virtual machine),
  I<Remove> (Removing a named snapshot for one or more virtual machines)

=back

=head2 List OPTIONS

=over


=item B<vmname>

Optional. The name of the source virtual machine.

=item B<datacenter>

Optional. Name of the target datacenter for selection of virtual machines.

=item B<pool>

Optional. Name of the target resource pool for selection of virtual machines.

=item B<host>

Optional. Name of the target host for selection of virtual machines.

=item B<folder>

Optional. Name of the target folder for selection of virtual machines.

=item B<ipaddress>

Optional. Ip Address of target virtual machine.

=item B<powerstatus>

Optional. Power Status for selection of virtual machines.

=item B<guestOS>

Optional. Guest OS for selection of virtual machines.


=back

=head2 Create OPTIONS

=over

=item B<vmname>

Optional. The name of the source virtual machine.

=item B<datacenter>

Optional. Name of the target datacenter for selection of virtual machines.

=item B<pool>

Optional. Name of the target resource pool for selection of virtual machines.

=item B<host>

Optional. Name of the target host for selection of virtual machines.

=item B<folder>

Optional. Name of the target folder for selection of virtual machines.

=item B<ipaddress>

Optional. Ip Address of target virtual machine.

=item B<powerstatus>

Optional. Power Status for selection of virtual machines.

=item B<guestOS>

Optional. Guest OS for selection of virtual machines.

=item B<snapshotname>

Required. Name of the new snapshot for operation <Create>

=back

=head2 Revert OPTIONS

=over

=item B<vmname>

Required. The name of the source virtual machine.

=item B<target>

Optional. Name of Target Host.

=back

=head2 GoTo OPTIONS

=over

=item B<vmname>

Required. The name of the source virtual machine.

=item B<revert>

Required. Name of snapshot to revert to.

=item B<target>

Optional. Name of Target Host.

=back

=head2 Rename OPTIONS

=over

=item B<vmname>

Required. The name of the source virtual machine.

=item B<rename>

Required. Name of snapshot to be renamed.

=item B<name>

Required. New name for the snapshot.

=back

=head2 RemoveAll OPTIONS

=over

=item B<vmname>

Required. The name of the source virtual machine.

=back

=head2 Remove OPTIONS

=over

=item B<vmname>

Optional. The name of the source virtual machine.

=item B<datacenter>

Optional. Name of the target datacenter for selection of virtual machines.

=item B<pool>

Optional. Name of the target resource pool for selection of virtual machines.

=item B<host>

Optional. Name of the target host for selection of virtual machines.

=item B<folder>

Optional. Name of the target folder for selection of virtual machines.

=item B<ipaddress>

Optional. Ip Address of target virtual machine.

=item B<powerstatus>

Optional. Power Status for selection of virtual machines.

=item B<guestOS>

Optional. Guest OS for selection of virtual machines.

=item B<remove>

Required. Name of snapshot to be removed for operation I<Remove>


=item B<children>

Required. Binary value 0|1 to decide whether children snapshots also needs
to be removed or not for operation I <Remove>


=back


=head1 EXAMPLES

List all the snapshots :

   perl snapshotmanager.pl --server <server host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation List
                    --vmname <Virtual Machine Name>

Create snapshot :

   perl snapshotmanager.pl --server <server host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation Create
                    --vmname <Virtual Machine Name> --snapshotname <Snapshot Name>

Revert snapshot :

   perl snapshotmanager.pl --server <server_host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation Revert
                    --vmname <Virtual Machine Name>

GoTo snapshot :

   perl snapshotmanager.pl --server <server_host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation Goto
                    --vmname <Virtual Machine Name> --revert <Name of Snapshot>

Rename snapshot :

   perl snapshotmanager.pl --server <server_host> --url <https://192.168.111.52/sdk/vimService>
                 --username <username> --password <password> --operation Rename
                 --rename <Name of snapshot to be renamed> --name <New name of snapshot>
                 --vmname <Virtual Machine Name>

Remove all :

   perl snapshotmanager.pl --server <server_host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation RemoveAll
                    --vmname <Virtual Machine Name>

Remove :

   perl snapshotmanager.pl --server <server_host> --url <https://192.168.111.52/sdk/vimService>
                    --username <username> --password <password> --operation Remove
                    --vmname <Virtual Machine Name> --remove <Name of snapshot>
                    --children <1|0>


=head1 KNOWN ISSUE

If you suspend a virtual machine and then take two successive snapshots,
the second snapshot operation fails with the error "Failure due to a malformed
request to the server". This error is expected and does not indicate a problem,
because suspended virtual machines do not change, the second snapshot would
overwrite the existing snapshot with identical data.


=head1 SUPPORTED PLATFORMS

All operations work with VMware VirtualCenter 2.0.1.

All operations work with VMware ESX Server 3.0.1.



