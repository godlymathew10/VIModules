#!E:/Perli/bin/perl.exe -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;

my %operations = (
   add_standalone => \&add_standalone_host,
   disconnect => \&disconnect_host,
   reconnect => \&reconnect_host,
   enter_maintenance => \&enter_maintenance_mode,
   exit_maintenance => \&exit_maintenance_mode,
   reboot => \&reboot_host,
   shutdown => \&shutdown_host,
);

my %opts = (
   target_host => {
      type => "=s",
      help => "Target host",
      required => 0,
   },
   target_username => {
      type => "=s",
      help => "Target host username (required for add_standalone)",
      required => 0,
   },
   target_password => {
      type => "=s",
      help => "Target host password (required for add_standalone)",
      required => 0,
   },
   operation => {
      type => "=s",
      help => "Operation to perform on target host: " .
          join(", ", sort keys %operations),
      required => 1,
   },
   url => {
      type => "=s",
      help => "URL of the virtual data center: " .
          join(", ", sort keys %operations),
      required => 1,
   },
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate(\&validate);


Util::connect();
my $operation = Opts::get_option('operation');
my $entity_view = get_views();
my $handler = $operations{$operation};
&$handler($entity_view);

Util::disconnect();


sub get_views {
   $operation = Opts::get_option('operation');
   if ($operation eq 'add_standalone') {
   my $folder_views =
      Vim::find_entity_views(view_type => 'Folder',
                             filter => { childType => ".*ComputeResource.*" });
      if (@$folder_views) {
         $entity_view = shift @$folder_views;
      }
      else {
         Util::trace(0,"=> Could not find host folder; are you connecting \n
                     directly to a host instead of to VirtualCenter?\n ");
         Opts::usage();
      }
   }
   else {
      my $target_host = Opts::get_option('target_host');
      my $host_views = Vim::find_entity_views(view_type => 'HostSystem',
                                              filter => { name => $target_host });
      if (@$host_views) {
         $entity_view = shift @$host_views;
      }
      else {
         Util::trace(0,"=> Could not find target host '$target_host" );
         Opts::usage();
      }
   }
}

#
# Add standalone server host
#
sub add_standalone_host {
   my $folder = shift;
   my $target_host = Opts::get_option('target_host');
   my $target_username = Opts::get_option('target_username');
   my $target_password = Opts::get_option('target_password');
   Util::trace(0, "Adding standalone host '$target_host'\n");

   eval {
      my $host_connect_spec = (HostConnectSpec->new(force => 0,
                                                    hostName => $target_host,
                                                    userName => $target_username,
                                                    password => $target_password,
                                                   ));
      $folder->AddStandaloneHost(spec => $host_connect_spec, addConnected => 1);
   };
   
   if ($@) {
      if (ref($@) eq 'SoapFault') {
         if (ref($@->detail) eq 'DuplicateName') {
            Util::trace(0,"Host $target_host already exist");
         }
         if (ref($@->detail) eq 'AlreadyConnected') {
            Util::trace(0,
                       "\nSpecified host is already connected to the Virtual Center\n");
         }
         else {
            Util::trace(0, "Fault: " . ref($@->detail));
         }
      }
   }
   else {
      Util::trace(0, "Host addition successfully completed\n");
   }
}


sub disconnect_host {
   my $target_host = shift;
   Util::trace(0, "Disconnecting host " . $target_host->name . "\n\n");
   eval {
      $target_host->DisconnectHost();
   };
   if ($@) {
      Util::trace (0, "Host  can't be disconnected \n" . $@->fault_string . "" );
   }
   else { 
      Util::trace(0, "Host disconnect successfully completed\n");
   }
}


sub reconnect_host {
   my $target_host = shift;
   Util::trace(0, "Reconnecting host " . $target_host->name . "\n\n");
   
   eval {
      $target_host->ReconnectHost();
   };
   if ($@) { 
      if (ref($@) eq 'SoapFault') {  
         if (ref($@->detail) eq 'InvalidState') {
            Util::trace(0,"Host is already connected");
         }
         else {
            Util::trace(0,"Fault: " . ref($@->detail));
         }
      }
   }
   else {
      Util::trace(0, "Host reconnect successfully completed\n");
   }
}

# This is used to enter the host in maintenance mode, It first suspends the
# running virtual machines and then puts the host in maintenance mode
sub enter_maintenance_mode {
   my $target_host = shift;
   my $vm_views = Vim::get_views(mo_ref_array => $target_host->vm);
   foreach (@$vm_views) {
      if ($_->runtime->powerState->val eq 'poweredOn') {
         Util::trace(0, "Suspending virtual machine " . $_->name . "...");
         eval {
            $_->SuspendVM(); 
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {  
               if (ref($@->detail) eq 'InvalidPowerState') {
                  Util::trace(0,"VM should be powered on");
               }
               else {
                  Util::trace(0,"Fault: " . ref($@->detail));
               }
            }
         }
         else { 
            Util::trace(0, "VM " . $_->name . " Suspended\n");
         }
      }
   }
   Util::trace(0,"\n Putting host " . $target_host->name . " in maintenance mode\n\n");
   eval { 
      $target_host->EnterMaintenanceMode(timeout => 0); 
   };
   if ($@) {
      if (ref($@) eq 'SoapFault') {  
         if (ref($@->detail) eq 'InvalidState') {
            Util::trace(0,"Host is already in the maintenance mode");
         }
         else {
            Util::trace(0,"Fault: " . ref($@->detail));
         }
      }
   }
   else {
      Util::trace(0, "Host entered maintenance mode successfully\n"); 
   }
}


# This is used to exit the host from  maintenance mode
sub exit_maintenance_mode {
   my $target_host = shift;
   Util::trace(0, "Taking host " . $target_host->name . " out of maintenance mode\n\n");
   eval { 
      $target_host->ExitMaintenanceMode(timeout => 0); 
   };
   if ($@) {
      if (ref($@) eq 'SoapFault') {
         if (ref($@->detail) eq 'InvalidState') {
            Util::trace(0,"Host is not in the maintenance mode");
         }
         else {
            Util::trace(0,"Fault: " . ref($@->detail));
         }
      }
   }
   else {
      Util::trace(0, "Host exited maintenance mode successfully\n ");
   }
}

# This subroutine is required for rebooting the host. All the VM's are suspended and
# maintenance mode is checked and after than the host is rebooted
sub reboot_host {
   my $target_host = shift;
   my $vm_views = Vim::get_views(mo_ref_array => $target_host->vm);

   foreach (@$vm_views) {
      if ($_->runtime->powerState->val eq 'poweredOn') {
         Util::trace(0,"\n Suspending virtual machine " . $_->name . "...");
         eval {
            $_->SuspendVM();
         };
         if($@) {
            if (ref($@) eq 'SoapFault') {
               if (ref($@->detail) eq 'InvalidPowerState') {
                  Util::trace(0,"VM should be powered on");
               }
               else {
                  Util::trace(0,"Fault: " . ref($@->detail));
               }
            }
         }
         else {
            Util::trace(0, "Virtual machine Suspended\n");
         }
      }
   }

   if($target_host->runtime->inMaintenanceMode eq 'false') {
      Util::trace(0,"\nPutting host " . $target_host->name . " in maintenance mode...");
      eval {
         $target_host->EnterMaintenanceMode(timeout => 0);
      };
      if ($@) { 
         Util::trace(0,"\n Host  can't be set into maintenance mode\n"
                      . $@->fault_string ."" );
      }
      else {
         Util::trace(0, "Host entered maintenance mode successfully\n"); 
      }
   }

   Util::trace(0, "Rebooting host " . $target_host->name . "...");
   eval {
      $target_host->RebootHost(force => 0); 
   };
   if ($@) { 
      Util::trace (0,"\n Host  can't reboot \n"  . $@->fault_string ."" );
   }
   else { 
      Util::trace(0, "Rebooting Host \n"); 
   }

   if ($target_host->runtime->inMaintenanceMode) {
      Util::trace(0,"Taking host " . $target_host->name . " out of maintenance mode..");
      eval {
         $target_host->ExitMaintenanceMode(timeout => 0);
      };
      if ($@) {
         if (ref($@) eq 'SoapFault') {
            if (ref($@->detail) eq 'InvalidState') {
               Util::trace(0,"Host is not in the maintenance mode");
            }
            else {
               Util::trace(0,"Fault: " . ref($@->detail));
            }
         }
      }
      else {
         Util::trace(0, "Exiting maintenance mode \n"); 
      }
   }
}

# This is used for shutting down the host. All the VM's are suspended
# mode is checked, for shutting down it should be in maintenance mode.
sub shutdown_host {
   my $target_host = shift;
   my $vm_views = Vim::get_views(mo_ref_array => $target_host->vm);
   foreach (@$vm_views) {
      if($_->runtime->powerState->val eq 'poweredOn') {
         Util::trace(0,"\n Suspending virtual machine " . $_->name . "...");
         eval {
            $_->SuspendVM();
         };
         if ($@) {
            if (ref($@) eq 'SoapFault') {
               if (ref($@->detail) eq 'InvalidPowerState') {
                 Util::trace(0,"VM should be powered on");
               }
               else {
                  Util::trace(0,"Fault: " . ref($@->detail));
               }
            }
         }
         else {
            Util::trace(0, "Virtual machine" . $_->name . " Suspended\n");
         }
      }
   }
   if($target_host->runtime->inMaintenanceMode eq 'false') {
      Util::trace(0, "\nPutting host " . $target_host->name . "in maintenance mode...");
      eval {
         $target_host->EnterMaintenanceMode(timeout => 0);
      };
      if ($@) { 
         Util::trace(0, "\n Host  can't be set into maintenance mode\n"
                      . $@->fault_string ."" );
      }
      else {  
         Util::trace(0, "\n Host entered maintenance mode successfully\n");
      }
   }

   Util::trace(0, "Shutting down host " . $target_host->name . "...");
   eval {
      $target_host->ShutdownHost(force => 0);
   };
   if ($@) { 
      Util::trace(0,"\n Can't shutdown host\n" . $@->fault_string ."" );
   }
   else { 
      Util::trace(0, "Shutting down host \n"); 
   }
}

sub validate {
   my $operation = Opts::get_option('operation');
   my $valid = 1;
   if (($operation eq 'add_standalone') &&
       (!Opts::option_is_set('target_username') ||
       !Opts::option_is_set('target_password'))) {
       Util::trace(0, " Target_username and target_password
                         for add_standalone must be specified \n");
      $valid = 0;
   }
   if (!exists($operations{$operation})) {
      map { print "   $_\n"; } sort keys %operations;
      Util::trace(0," Unknown operation: '$operation'\n  List of valid operations: ");
      $valid = 0;
   }
   return $valid;
}
__END__

=head1 NAME

hostops.pl - Performs add_standalone, disconnect, reconnect, enter_maintenance, 
             exit_maintenance, reboot, and shutdown

=head1 SYNOPSIS

    hostops.pl --operation <disconnect|reconnect|enter_maintenance|
                 exit_maintenance|reboot|shutdown|add_standalone> [options]

=head1 DESCRIPTION

This scripts allows users to perform basic host operations. The supported
operations are: add_standalone, disconnect, reconnect, enter_maintenance,
exit_maintenance, reboot, and shutdown.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over

=item B<operation>

 Operation to be performed. It is a mandatory field. One of the following:
   I<shutdown> (shutdown the host),
   I<reboot> (reboot the host ),
   I<enter_maintenance> (set host into maintenance mode),
   I<exit_maintenance> (exit the maintenance mode),
   I<disconnect> (disconnect the host from virtual center server),
   I<reconnect> (reconnect the host to virtual center server),
   I<add_standalone> (add new host to the virtual center server),


=item B<url>

URL of the Virtual Data Center. 

=item B<username>

Username of the Host server

=item B<password>

Password of the host server

=back

=head2 ADD STANDALONE OPTIONS

=over

=item B<target_host>

Required. Domain name of the target_host i.e ESX server

=item B<target_username>

Required. Username of the Host to be added.

=item B<target_password>

Required. Password of the target host

=back



=head2 DISCONNECT HOST OPTIONS

=over

=item B<target_host>

Required. Domain name of the target_host i.e ESX server

=item B<target_username>

Required. Username of the Host to be disconnected.

=item B<target_password>

Required. Password of the target host


=back



=head2 RECONNECT HOST OPTIONS

=over

=item B<target_host>

Required. Domain name of the target_host i.e ESX server


=item B<target_username>

Required. Username of the Host to be reconnected.

=item B<target_password>

Required. Password of the target host

=back


=head2 ENTER MAINTENANCE MODE OPTIONS

=over

=item B<target_host>

Optional. Domain name of the target_host i.e ESX server.
When we do this operation via Virtual Center then this is required

=item B<target_username>

Optional. Username of the Host to be sent into maintenance mode.

=item B<target_password>

Optional . Password of the target host

=back



=head2 EXIT MAINTENANCE MODE OPTIONS

=over

=item B<target_host>

Optional. Domain name of the target_host i.e ESX server


=item B<target_username>

Optional. Username of the Host to be exited from the maintenance mode.
When we do this operation via Virtual Center then this is required

=item B<target_password>

Optional . Password of the target host

=back


=head2 SHUTDOWN OPTIONS

=over

=item B<target_host>

Optional. Domain name of the target_host i.e ESX server.
When we do this operation via Virtual Center then this is required

=item B<target_username>

Optional. Username of the Host to be shutdown.

=item B<target_password>

Optional . Password of the target host

=back


=head2 REBOOT OPTIONS

=over

=item B<target_host>

Optional. Domain name of the target_host i.e ESX server
When we do this operation via Virtual Center then this is required

=item B<target_username>

Optional. Username of the Host rebooted.

=item B<target_password>

Optional . Password of the target host

=back





=head1 EXAMPLES

Shutdown a Host

 hostops.pl --username root --password esxadmin --operation shutdown
           --url https://192.168.111.2:443/sdk/webService
  (Host must be in maintenance mode for this operation)

Reboot a Host

 hostops.pl --username root --password esxadmin --operation reboot
           --url https://192.168.111.2:443/sdk/webService
  (Host must be in maintenance mode for this operation)

Enter in maintenance mode:

 hostops.pl --username root --password esxadmin --operation enter_maintenance
           --url https://192.168.111.2:443/sdk/webService

 hostops.pl --url https://192.168.111.52:443/sdk/webService
           --username manir --password mypassword --operation enter_maintenance
           --target_host ESX.InterraIT.info --target_host 192.168.111.2
           --target_username root --target_password esxadmin

Exit maintenance mode

 hostops.pl --username root --password esxadmin --operation exit_maintenance
           --url https://192.168.111.2:443/sdk/webService

Reconnect:

 hostops.pl --url https://192.168.111.52:443/sdk/webService --username user
           --password mypassword --target_host 192.168.111.2
           --target_username root --target_password esxadmin --operation reconnect


Disconnect:

 hostops.pl --url https://192.168.111.52:443/sdk/webService --username user
           --password mypassword --target_host 192.168.111.2
           --target_username root --target_password esxadmin --operation disconnect


Add Standalone:

 hostops.pl --url https://192.168.111.52:443/sdk/webService --username user
           --password mypassword --target_host 192.168.111.2
           --target_username root --target_password esxadmin
           --operation add_standalone


=head1 SUPPORTED PLATFORMS

All operations supported via Virtual Data Center 2.0.1.

enter_maintenance, exit_maintenance, shutdown , reboot works with ESX Sever 3.0.1


