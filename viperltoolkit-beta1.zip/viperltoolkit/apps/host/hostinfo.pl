#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use VMware::VIM2Runtime;
use VMware::VILib;
sub create_hash;
sub get_host_info;

my %field_values = (
   'hostname' => 'hostname',
   'portnumber' => 'portnumber',
   'boottime' => 'boottime',
   'cpumodel' => 'cpumodel',
   'cpuspeed' => 'cpuspeed',
   'cpuusage' => 'cpuusage' ,
   'filesystem' => 'filesystem',
   'host_status' => 'host_status',
   'maintenancemode' => 'maintenancemode',
   'memorysize' => 'memorysize' ,
   'memoryusage' => 'memoryusage',
   'networkadapters' =>'networkadapters',
   'portnumber' => 'portnumber',
   'rebootrequired' => 'rebootrequired',
   'software' => 'software',
   'vmotion' => 'vmotion',
);

my %host_status = (
   'gray' => 'The status is unknown',
   'green' => 'The entity is OK',
   'red' => 'The entity definitely has a problem',
   'yellow' => 'The entity might have a problem',
);

my %opts = (
   'hostipaddress' => {
      type => "=s",
      help => "Host IP Address",
      required => 0,
   },
   'datacenter' => {
      type => "=s",
      help => "Name of the DataCentre",
      required => 0,
   },
   'folder' => {
      type => "=s",
      help => "Name of the Folder",
      required => 0,
   },
   'vmotion' => {
      type => "=s",
      help => "Is vmotion",
      required => 0,
   },
   'maintenancemode' => {
      type => "=s",
      help => "Is in maintenance mode",
      required => 0,
   },
   'fields' => {
      type => "=s",
      help => "If no fields specified, all properties will be displayed",
      required => 0,
   },
   'fileoutput'=>{
      type => "=s",
      help => "The results to be displayed to a file given a xml file name",
      required => 0,
   }
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate(\&validate);

my @valid_properties;
my $counter =0;
my $filename;

Util::connect();

get_host_info();

Util::disconnect();


# This subroutine first retrieve the hosts based on the user criteria like
# hostipaddress, datacenter, folder etc. and then for each host it displays
# the host information like BootTime, cpumodel, cpuspeed, filesystem,
# memoryusage, networkadapters etc.
# =========================================================================
sub get_host_info {
   my $hostipaddress = Opts::get_option('hostipaddress');
   my $datacenter = Opts::get_option('datacenter');
   my $folder = Opts::get_option('folder');
   my $vmotion = Opts::get_option('vmotion');
   my $maintenancemode = Opts::get_option('maintenancemode');
   my %filterHashHost = create_hash($vmotion, $maintenancemode);
   my $filename;
   my $host_views = get_hosts ('HostSystem', $datacenter,
                             $folder,$hostipaddress, %filterHashHost);
   if ($host_views){
      $host_views = Vim::find_entity_views((view_type => 'HostSystem'),
                                         filter => { %filterHashHost } );

      if (defined (Opts::get_option('fileoutput'))) {
         $filename = Opts::get_option('fileoutput');
         my $extension = lc substr($filename, length($filename)-4, 4);
         if($extension ne '.xml') {
            $filename =$filename.'.xml';
         }
         open(OUTFILE, ">$filename");
         print OUTFILE  "<Root>\n";
      }

      foreach (@$host_views) {
         my $hardware = $_->hardware;
         my $cpu_hz = $hardware->cpuInfo->hz;
         my $cpu_cores = $hardware->cpuInfo->numCpuCores;

         my $status = $_->summary->overallStatus->val;
         $counter =0;
         my $host_view = $_;
         if (defined (Opts::get_option('fileoutput'))) {
            print OUTFILE  "<host name=".$_->name.">\n";
         }
         if (defined (Opts::get_option('fields'))) {
            foreach (@valid_properties) {
               if ($_ eq 'boottime') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE  "<BootTime>" . $host_view->runtime->bootTime
                                                 . "</BootTime>\n";
                  }
                  else {
                     Util::trace(0, "Boot time:\t\t"
                                  . $host_view->runtime->bootTime . "\n");
                  }
               }
               elsif ($_ eq 'cpumodel') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<CpuModel>\t\t" .
                        $host_view->summary->hardware->cpuModel ."</CpuModel>\n";
                  }
                  else {
                     Util::trace(0, "Cpu Model :\t\t"
                                  . $host_view->summary->hardware->cpuModel . "\n");
                  }
               }
               elsif ($_ eq 'cpuspeed') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<CPUSpeed> t\t" . ($cpu_hz * $cpu_cores)
                                                    . "</CPUSpeed>\n";
                  }
                  else {
                     Util::trace(0,"\nCPU speed :\t\t" . ($cpu_hz * $cpu_cores) . "\n");
                  }
               }
               elsif ($_ eq 'cpuusage') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<CpuUsage>\t\t"
                                  . $host_view->summary->quickStats->overallCpuUsage
                                  . " MHz</CpuUsage>\n";
                  }
                  else {
                     Util::trace(0, "Cpu Usage :\t\t"
                                  . $host_view->summary->quickStats->overallCpuUsage
                                  . " MHz\n");
                  }
               }
               elsif ($_ eq 'filesystem') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<FileSystem>\t\t";
                     print OUTFILE @{
                        $host_view->config->fileSystemVolume->volumeTypeList};
                     print OUTFILE "</FileSystem>\n";
                  }
                  else {
                     Util::trace(0, "File system:\t\t");
                     Util::trace(0, @{
                        $host_view->config->fileSystemVolume->volumeTypeList});
                     Util::trace(0, "\n");
                  }
               }
               elsif ($_ eq 'hostname') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "\n<HostName>\t\t"
                                  . $host_view->name . "</HostName>\n";
                  }
                  else {
                     Util::trace(0, "\n\nHost Name:\t\t" . $host_view->name . "\n");
                  }
               }
               elsif ($_ eq 'host_status') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<HostStatus>\t\t" . $host_status{$status}
                                   . "</HostStatus>\n";
                  }
                  else {
                     Util::trace(0, "Host status :\t\t" . $host_status{$status} . "\n");
                  }
               }
               elsif ($_ eq 'maintenancemode') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<MaintainenceMode>\t"
                                   . $host_view->runtime->inMaintenanceMode
                                   . "</MaintainenceMode>\n";
                  }
                  else {
                     Util::trace(0, "Maintainence mode:\t"
                                  . $host_view->runtime->inMaintenanceMode . "\n");
                  }
               }
               elsif ($_ eq 'memorysize') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<PhysicalMemory>\t"
                                  . $host_view->summary->hardware->memorySize
                                  . " bytes</PhysicalMemory>\n";
                  }
                  else {
                     Util::trace(0, "Physical memory :\t"
                                  . $host_view->summary->hardware->memorySize
                                  . " bytes\n");
                  }
               }
               elsif ($_ eq 'memoryusage') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<MemoryUsage>\t\t"
                                   . $host_view->summary->quickStats->overallMemoryUsage
                                  . " MB</MemoryUsage>\n";
                  }
                  else {
                     Util::trace(0, "Memory Usage :\t\t"
                                  . $host_view->summary->quickStats->overallMemoryUsage
                                  . " MB\n");
                  }
               }
               elsif ($_ eq 'networkadapters') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<NetworkAdapters> \t"
                                   . $host_view->summary->hardware->numNics
                                   . "</NetworkAdapters>\n";
                  }
                  else {
                     Util::trace(0, "Network adapters :\t"
                                  . $host_view->summary->hardware->numNics . "\n");
                  }
               }
               elsif ($_ eq 'portnumber') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<PortNumber>\t\t"
                                   .$host_view->summary->config->port
                                   . "</PortNumber>\n";
                  }
                  else {
                     Util::trace(0, "Port Number:\t\t"
                                  . $host_view->summary->config->port . "\n");
                  }
               }
               elsif ($_ eq 'rebootrequired') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<RebootRequired>\t"
                                  . $host_view->summary->rebootRequired
                                  . "</RebootRequired>\n";
                  }
                  else {
                     Util::trace(0, "Reboot required :\t"
                                  . $host_view->summary->rebootRequired . "\n");
                  }
               }
               elsif ($_ eq 'software') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<SoftwareOnHost>\t"
                                 . ${$host_view->summary->config->product}{'fullName'}
                                   . "</SoftwareOnHost>\n";
                  }
                  else {
                     Util::trace(0, "Software on host :\t"
                                  . ${$host_view->summary->config->product}{'fullName'}
                                  . "\n");
                  }
               }
               elsif ($_ eq 'vmotion') {
                  if (defined (Opts::get_option('fileoutput'))) {
                     print OUTFILE "<VMotion>\t\t"
                                   . $host_view->summary->config->vmotionEnabled
                                   . "</VMotion>\n";
                  }
                  else {
                     Util::trace(0, "VMotion :\t\t"
                                  . $host_view->summary->config->vmotionEnabled . "\n");
                  }
               }
               else {
                  Util::trace(0, "$_". Not Supported."\n");
               }
            }
         }

         if (!defined (Opts::get_option('fields') )) {
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "\n<HostName>\t\t" . $host_view->name . "</HostName>\n";
            }
            else {
               Util::trace(0, "\n\nHost Name:\t\t" . $host_view->name . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<PortNumber>\t\t"
                             . $host_view->summary->config->port . "</PortNumber>\n";
            }
            else {
               Util::trace(0, "Port Number:\t\t"
                            . $host_view->summary->config->port . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<BootTime>\t\t" . $host_view->runtime->bootTime
                            . "</BootTime>\n";
            }
            else {
               Util::trace(0, "Boot time:\t\t" . $host_view->runtime->bootTime . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<MaintainenceMode>\t"
                           . $host_view->runtime->inMaintenanceMode
                           . "</MaintainenceMode>\n";
            }
            else {
               Util::trace(0, "Maintainence mode:\t"
                            . $host_view->runtime->inMaintenanceMode . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<FileSystem>\t\t"
                           . @{$host_view->config->fileSystemVolume->volumeTypeList}
                           . "</FileSystem>\n";
            }
            else {
               Util::trace(0, "File system:\t\t");
               Util::trace(0, @{$host_view->config->fileSystemVolume->volumeTypeList});
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "\n<CPUSpeed>\t\t"
                             . ($host_view->hardware->cpuInfo->hz)*
                               ($host_view->hardware->cpuInfo->numCpuCores)
                             . "</CPUSpeed>\n";
            }
            else {
               Util::trace(0, "\nCPU speed :\t\t"
                            . ($host_view->hardware->cpuInfo->hz)*
                              ($host_view->hardware->cpuInfo->numCpuCores)
                            . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<HostStatus> \t\t"
                            . $host_status{$status} . "</HostStatus>\n";
            }
            else {
               Util::trace(0, "\nHost status :\t\t" . $host_status{$status} . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<RebootRequired>\t"
                            . $host_view->summary->rebootRequired
                            . "</RebootRequired>\n";
            }
            else {
               Util::trace(0, "Reboot required :\t"
                            . $host_view->summary->rebootRequired . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<CpuUsage>\t\t"
                            . $host_view->summary->quickStats->overallCpuUsage
                            . " MHz</CpuUsage>\n";
            }
            else {
               Util::trace(0, "Cpu Usage :\t\t"
                            . $host_view->summary->quickStats->overallCpuUsage
                            . " MHz\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<MemoryUsage>\t\t"
                            . $host_view->summary->quickStats->overallMemoryUsage
                            . " MB</MemoryUsage>\n";
            }
            else {
               Util::trace(0, "Memory Usage :\t\t"
                            . $host_view->summary->quickStats->overallMemoryUsage
                            . " MB\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<CpuModel>\t\t"
                           . $host_view->summary->hardware->cpuModel . "</CpuModel>\n";
            }
            else {
               Util::trace(0, "Cpu Model :\t\t"
                            . $host_view->summary->hardware->cpuModel . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<PhysicalMemory>\t"
                            . $host_view->summary->hardware->memorySize
                            . " bytes</PhysicalMemory>\n";
            }
            else {
               Util::trace(0, "Physical memory :\t"
                            . $host_view->summary->hardware->memorySize
                            . " bytes\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<NetworkAdapters>\t"
                            . $host_view->summary->hardware->numNics
                            . "</NetworkAdapters>\n";
            }
            else {
               Util::trace(0, "Network adapters :\t"
                            . $host_view->summary->hardware->numNics . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<SoftwareOnHost>\t"
                            . ${$host_view->summary->config->product}{'fullName'}
                            . "</SoftwareOnHost>\n";
            }
            else {
               Util::trace(0, "Software on host :\t"
                        . ${$host_view->summary->config->product}{'fullName'} . "\n");
            }
            if (defined (Opts::get_option('fileoutput'))) {
               print OUTFILE "<VMotion>\t\t"
                             . $host_view->summary->config->vmotionEnabled
                             . "</VMotion>\n";
            }
            else {
               Util::trace(0, "VMotion :\t\t"
                            . $host_view->summary->config->vmotionEnabled . "\n");
            }
         }
         if (defined (Opts::get_option('fileoutput'))) {
            print OUTFILE  "</host>\n";
         }
      }
      if (defined (Opts::get_option('fileoutput'))) {
         print OUTFILE  "</Root>\n";
      }
   }
}

# This subroutine retrieves the hosts based on the
# user criteria like datacenter, folder etc.
# =================================================
sub get_hosts {
   my ($entity, $datacenter, $folder, $host, %filterHash) = @_;
   my $begin;
   my $entityViews;
   my %filter = %filterHash;
   my $vms;

   if (defined $datacenter) {
      $begin = Vim::find_entity_view (view_type => 'Datacenter',
                                filter => {name => "^$datacenter\$"});
      unless ($begin) {
         Util::trace(0, "Datacenter $datacenter not found.\n");
         return;
      }
   }
   else {
      $begin = Vim::get_service_content()->rootFolder;
   }
   if (defined $folder) {
      my $vms = Vim::find_entity_views (view_type => 'Folder',
                                        begin_entity => $begin,
                                        filter => {name => "^$folder\$"});
      unless (@$vms) {
         Util::trace(0, "Folder <$folder> not found.\n");
         return;
      }

      if ($#{$vms} != 0) {
         Util::trace(0, "Folder <$folder> not unique.\n");
         return;
      }
      $begin = shift (@$vms);
   }
   if (defined $host) {
      my $hostView = Vim::find_entity_view (view_type => 'HostSystem',
                                           filter => {'name' => "^$host\$"});
      unless ($hostView) {
         Util::trace(0, "Host $host not found.");
         return;
      }
   }
   else {
      $entityViews = Vim::find_entity_views (view_type => $entity,
                                             begin_entity => $begin,
                                             filter => \%filter);
      unless (@$entityViews) {
         Util::trace(0, "No Host found.\n");
         return;
      }
   }

# sort the virtual machines by name
   my %entities;
   my @sortedEntities;
   foreach (@$entityViews) {
      $entities{$_->name} = $_;
   }
   foreach (sort keys %entities) {
      push (@sortedEntities, $entities{$_});
   }
   if ($entityViews) {
      return \@sortedEntities;
   }
   else {
      return 0;
   }
}

# Create hash for filter criteria
# ================================
sub create_hash {
   my ($vmotion, $maintenancemode) = @_;
   my %filterHash;
   if ($vmotion) {
      $filterHash{'summary.config.vmotionEnabled'} = $vmotion;
   }
   if ( $maintenancemode) {
      $filterHash{'runtime.inMaintenanceMode'} = $maintenancemode;
   }
   return %filterHash;
}

# validate the host's fields to be displayed
# ===========================================
sub validate {
   my $valid = 1;
   my @properties_to_add;
   my $length =0;

   if (defined (Opts::get_option('fields'))) {
      my @filter_Array = split (',', Opts::get_option('fields'));
      foreach (@filter_Array) {
         if ($field_values{ $_ }) {
            $properties_to_add[$length] = $field_values{$_};
            $length++;
           } else {
            Util::trace(0, "\n".$_." Not Supported. \n");
         }
      }
      @valid_properties = sort  @properties_to_add;
   }
   return $valid;
}

__END__

=head1 NAME

hostinfo.pl - lists the hosts and their attributes

=head1 SYNOPSIS

 hostinfo.pl --url <web service URL> --username <server login name>
        --password <server login password> --datacenter <name of the datacenter>
          [--fields <attributes to be displayed>]
          [--fileoutput <name of the file to print the results to>]
          [--hostipaddress <ipaddresss of the host>]
          [--maintenancemode <boolean value to filter hosts in and not in maintenance mode>]
          [--vmotion <boolean value to filter hosts with vmotion enabled or disabled>]

=head1 DESCRIPTION

This VI Perl command-line utility provides a query tool that
lists various hosts and attributes for a host or set of hosts.

=head1 OPTIONS

=head2 GENERAL OPTIONS

=over


=item B<datacenter>

Optional. Name of the datacenter. When datacenter is specified, only hosts in this
datacenter will be listed.

=item B<fileoutput>

Optional. An xml filename or path of an xml filename to which the output
will be written to. If fileoutput not used, the output will be displayed.

=item B<folder>

Optional. Name of the Folder. When Folder is specified,
only hosts in this Folder will be listed.

=item B<hostipaddress>

Optional. Filters host based on hostipaddress. When hostipaddress is specified,
only host having this ip address will be listed.

=item B<maintenancemode>

Optional. Filters host based on maintenancemode. When maintenancemode is specified,
only host having this maintenancemode will be listed.

=item B<vmotion>

Optional. Filters host based on vmotion enabled or disabled. When vmotion is specified,
only hosts having this vmotion property will be listed.

=back

=head2 FIELDS OPTIONS

=over

=item B<hostname>

Optional. Display property hostname, when specified.

=item B<portnumber>

Optional. Display property portnumber when specified. It lists the port number.

=item B<boottime>

Optional. Display property bootTime when specified. bootTime displays the time when
the host was booted in dateTime format.

=item B<cpumodel>

Optional Display property cpumodel when specified. It provides
the cpu model identification.

=item B<cpuspeed>

Optional. Display property cpuspeed when specified. The product of the speed of cpu
cores and number of processors contained by a CPU package is approximately equal to
the sum of the MHz for all the individual cores on the host. This product forms the
cpuspeed.

=item B<cpuusage>

Optional. Display property cpuusage when specified. It specifies the aggregated CPU usage
across all cores on the host in MHz.

=item B<filesystem>

Optional. Display property filesystem when specified. It describes the file system volume
information for the host, listing the supported file system volume types.

=item B<host_status>

Optional. Display property host_status when specified. It gives the overall
alarm status of the host.

=item B<maintenancemode>

Optional. Display property maintenancemode when specified. It indicates whether or not the
host is in maintenance mode. It is set when the host has entered the maintenance mode.

=item B<memorysize>

Optional. Display property memorysize when specified. It provides the physical
memory size in bytes.

=item B<memoryusage>

Optional. Display property memoryusage when specified. It gives the Physical memory usage
on the host in MB. 

=item B<networkadapters>

Optional. Display property networkadapters when specified. It gives the number
of network adapters.

=item B<rebootrequired>

Optional. Display property reebootrequired when specified. Indicates whether or not the host
requires a reboot due to a configuration change.

=item B<software>

Optional. Display property software when specified. It gives the complete product name,
including the version information

=item B<vmotion>

Optional. Display property vmotion when specified. It indicates whether vmotion is
enabled or disabled for the host.

=back

=head1 EXAMPLES

List all hosts and all properties of the hosts that are part of ha datacenter.

 hostinfo.pl --username administrator --password mypassword
            --url https://192.168.111.52/sdk/vimService
            --datacenter ha

List all hosts that are part of ha datacenter and
selected properties of the hosts, as specified in the fields

 hostinfo.pl --username administrator --password mypassword
            --url https://192.168.111.52/sdk/vimService
            --fields hostname, portnumber ,boottime,cpumodel,cpuspeed,
                 cpuusage,filesystem,host_status, maintenancemode,
                 memorysize,memoryusage,networkadapters,portnumber,
                 rebootrequired,	software,vmotion
            --datacenter ha

List all hosts and all the properties of the hosts.
The results are displayed in the file mentioned in fileoutput.

 hostinfo.pl --username administrator --password mypassword
            --url https://192.168.111.52/sdk/vimService
            --fileoutput D:\Output\result.xml

Lists the properties of only one host having the
ip address specified in the hostipaddress

 hostinfo.pl --username administrator --password mypassword
            --url https://192.168.111.52/sdk/vimService
            --hostipaddress 192.168.111.2

Lists the properties of all the hosts having their maintenance mode
and vmotion property as specified in maintenancemode and vmotion respectively.

 hostinfo.pl --username administrator --password mypassword
            --url https://192.168.111.52/sdk/vimService --maintenancemode 0
            --vmotion 1

Lists the properties of all the hosts part of the folder as specified in folder.

 hostinfo.pl --username administrator --password mypassword
          --url https://192.168.111.52/sdk/vimService
          --folder myfolder

=head1 SUPPORTED PLATFORMS

This script works with VMware VirtualCenter 2.0 or later.

This script works with VMware ESX Server 3.0 or later.
