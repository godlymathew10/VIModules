#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use 5.006001;
use strict;
use warnings;

use XML::LibXML;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Headers;
use HTTP::Response;
use HTTP::Cookies;
use Data::Dumper;

#########################################################
package XmlUtil;

sub escape_xml_string {
   my $string = shift;
   if (defined $string) {
      $string =~ s/\&/\&amp;/g;
      $string =~ s/</\&lt;/g;
      $string =~ s/>/\&gt;/g;
   } else {
      $string = "";
   }
   return $string;
}

sub get_first_child_element {
   my $parent_node = shift;
   my @child_nodes = $parent_node->childNodes;
   my $node;
   foreach $node (@child_nodes) {
      if ($node->nodeType == XML::LibXML::XML_ELEMENT_NODE) {
         return $node;
      }
   }
}

1;
#########################################################



#########################################################
package SoapFault;
use Data::Dumper;
use Class::MethodMaker  [ scalar => [qw(detail fault_string)] ];

sub new {
   my ($class, $fault_node) = @_;
   my $self = {};
   if (! $fault_node) {
      return bless $self, $class;
   }
   my $detail_node = $fault_node->getChildrenByTagName('detail')->shift;
   my $fault_detail_child = XmlUtil::get_first_child_element($detail_node);
   my $faultName = $fault_detail_child->localname;
   $faultName =~ /(.*)Fault/;
   $self->{detail} = $1->deserialize($fault_detail_child);
   my $fault_string_node = $fault_node->getChildrenByTagName('faultstring')->shift;
   $self->{fault_string} = $fault_string_node->textContent;
   bless $self, $class;
}

use overload '""' => \&stringify;

sub stringify{
   my $self = shift;
   my $fault = "SOAP Fault:\n";
   $fault .= "Fault string: " . $self->{fault_string};
   $fault .= "\nFault detail:\n" . Dumper $self->{detail};
   return $fault;
}

1;
#########################################################


#########################################################
package SoapResponse;

sub new {
   my ($class, $result, $fault) = @_;
   my $self = { result => $result,
                fault => $fault, };
   bless $self, $class;
}

sub result {
   my ($self, $val) = @_;
   if ($val) {
      $self->{result} = $val;
      $self;
   } else {
      $self->{result};
   }
}

sub fault {
   my ($self, $val) = @_;
   if ($val) {
      $self->{fault} = $val;
      $self;
   } else {
      $self->{fault};
   }
}

1;
#########################################################



#########################################################
package SoapClient;

my $soap_header  = <<'END';
<?xml version="1.0" encoding="UTF-8"?>
   <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   <soapenv:Body>
END

my $soap_footer = <<'END';
</soapenv:Body></soapenv:Envelope>
END


sub new {
   my ($class, $url) = @_;
   my $user_agent = LWP::UserAgent->new;
   my $cookie_jar = HTTP::Cookies->new(ignore_discard => 1);
   $user_agent->cookie_jar( $cookie_jar );
   $user_agent->protocols_allowed( ['http', 'https'] );
   my $self = { user_agent => $user_agent,
                url => $url, };
   bless $self, $class;   
}

sub save_session {
   my ($self, $file) = @_;
   my $user_agent = $self->{user_agent};
   $user_agent->cookie_jar->save($file); 
}

sub load_session {
   my ($self, $file) = @_;
   my $user_agent = $self->{user_agent};
   $user_agent->cookie_jar->load($file);                                 
}

sub request {
   my ($self, $op_name, $body_content) = @_;
   my $user_agent = $self->{user_agent};
   my $url = $self->{url};
   
   my $request_envelope =
      "$soap_header<$op_name xmlns=\"urn:vim2\">$body_content</$op_name>$soap_footer";
   
   # http header
   my $http_header = HTTP::Headers->new(
                        Content_Type => 'text/xml',
                        Content_Length => byte_length($request_envelope));
   # request
   my $request = HTTP::Request->new('POST',
                                    $url,
                                    $http_header,
                                    $request_envelope);
   
   # send request
   my $response = $user_agent->request($request);   
   my $xml_parser = XML::LibXML->new;   
   my $result;   
   eval { $result = $xml_parser->parse_string($response->content) };
   if ($@) {
      # response is not well formed xml - possibly be a setup issue
      Carp::confess("SOAP request error: " . $response->content);
   }   
   my $body = $result->documentElement()->getChildrenByTagName('soapenv:Body')->shift;
   my $return_val = $body->getChildrenByTagName("${op_name}Response")->shift;
   if (! $return_val) {
      # must be fault
      $return_val = $body->getChildrenByTagName('soapenv:Fault')->shift;
      if (! $return_val) {
         # neither a valid response or a fault - fatal error
         Carp::confess("Unexpected response from server: " . $response->content);         
      }
      # should be trapped by caller
      return (undef, $return_val);
   } else {
      my @returnvals = $return_val->getChildrenByTagName('returnval');
      return (\@returnvals, undef);
   }
}

sub byte_length {
    my ($string) = @_;

    use bytes;
    return length($string);
}

1;
#########################################################


#########################################################
package PrimType;

sub new {
   my ($class, $val, $type_name) = @_;
   my $self = { val => $val , type_name => $type_name};
   bless $self, $class;   
}

sub serialize {
   my ($self, $tag, $emit_type) = @_;
   my $val = $self->{val};   
   my $serialized_string = "<$tag>";
   if ($emit_type) {
      my $type_name = $self->{type_name};
      $serialized_string = "<$tag xsi:type=\"xsd:${type_name}\">";      
   }
   $serialized_string .= "$val</$tag>";
}

sub val {
   my $self = shift;
   return $self->{val};
}

1;
#########################################################


#########################################################
package SimpleType;

sub new {
   my ($class, $val) = @_;
   my $self = { val => $val };
   bless $self, $class;   
}

sub serialize {
   my ($self, $tag, $emit_type) = @_;
   my $val = $self->{val};
   my $serialized_string = "<$tag>";
   if ($emit_type) {
      my $type_name = ref $self;
      $serialized_string = "<$tag xsi:type=\"$type_name\">";      
   }
   $serialized_string = "$serialized_string$val</$tag>";
}

sub deserialize {
   my ($class, $element_node) = @_;
   if (! defined($element_node)) {
      return undef;
   }
   my $content = $element_node->textContent;
   my $self = { val => $content };
   bless $self, $class;
}

sub val {
   my $self = shift;
   return $self->{val};
}

1;
##################################################################################



##################################################################################
package ComplexType;

sub deserialize {
   my ($class, $element_node) = @_;
   if (! defined($element_node)) {
      return undef;
   }
   my $type_node =
      $element_node->getAttributeNodeNS('http://www.w3.org/2001/XMLSchema-instance',
                                        'type');
   if ($type_node) {
      $class = $type_node->textContent;
   }
   my $self = {};
   my @property_list = $class->get_property_list();
   foreach (@property_list) {
      my ($property_name, $class_name, $isarray) = @$_;      
      my @child_nodes = $element_node->getChildrenByTagName($property_name);
      if (! @child_nodes) {
         next;
      }      
      my $property_val = [];
      foreach (@child_nodes) {
         my $val;
         my $child_class_name = $class_name;
         
         if (defined $child_class_name) {
            my $child_type_node =
               $_->getAttributeNodeNS('http://www.w3.org/2001/XMLSchema-instance', 'type');
            if ($child_type_node) {
               $child_class_name = $child_type_node->textContent;
               if ($child_class_name =~ /^xsd:/) {
                  undef $child_class_name;
               }
            }
         }
         
         if ($child_class_name) {            
            $val = $child_class_name->deserialize($_);
         } else {
            # a little hack to make it convenient to use
            # true/false in a conditional.  text content 'true' / 'false'
            # are treated as boolean
            if ($_->textContent eq 'true') {
               $val = '1';
            } elsif ($_->textContent eq 'false') {
               $val = '0';
            } else {
               $val = $_->textContent;
            }
         }
         if ($isarray) {
            $property_val = [@$property_val, $val];
         } else {
            $property_val = $val;
         }
      }      
      my $propValType = ref $property_val;
      if ($propValType =~ /ArrayOf.*/) {
         my @keyvals = %$property_val;
         if (@keyvals) {
            $self->{$property_name} = pop @keyvals;
         }
      } else {
         $self->{$property_name} = $property_val;
      }
   } 
   bless $self, $class;   
}


sub serialize {
   my ($self, $tag, $emit_type) = @_;
   my @property_list = $self->get_property_list();
   my $serialized_string = "<$tag>";
   if ($emit_type) {
      my $type_name = ref $self;
      $serialized_string = "<$tag xsi:type=\"$type_name\">";
   } 
   foreach (@property_list) {
      my ($property_name, $class_name, $isarray) = @$_;
      if (! exists($self->{$property_name})) {
         next;
      }
      my $val = $self->{$property_name};
      my @values;
      if ($isarray) {
         @values = @$val;
      } else {
         @values = $val;
      }
      foreach (@values) {
         if (defined ($class_name)) {
            # complex type
            my $show_type;
            my $obj_type_name = ref $_;
            if ($class_name ne $obj_type_name) {               
               $show_type = 1;
               if ($class_name eq 'anyType' &&  ! $obj_type_name) {
                  # primitive going out as any -- treat them as xsd:string
                  $serialized_string .=       
                     "<$property_name xsi:type=\"xsd:string\">" .
                     XmlUtil::escape_xml_string($_) . "</$property_name>";
                  next;
               }
            }
            if ($obj_type_name && $class_name eq 'ManagedObjectReference') {
               $obj_type_name = 'ManagedObjectReference';   
            }
            if ($class_name ne 'anyType') {
               if (! $obj_type_name || ! $obj_type_name->isa($class_name)) {
                  Carp::confess("Cannot serialize $property_name as $class_name");
               }
            }               
            $serialized_string .= $_->serialize($property_name, $show_type);
         } else {
            # primitive
            $serialized_string .=       
               "<$property_name>" . XmlUtil::escape_xml_string($_) . "</$property_name>";         
         }
      }
   }
   $serialized_string .= "</$tag>";
}


sub new {
   my ($class, %args) = @_;
   my $self = {};
   bless $self, $class;
   if (%args) {
      foreach ($class->get_property_list()) {
         my ($name, $type) = @$_;
         if (exists $args{$name}) {
            $self->{$name} = $args{$name};
         }
      }
   }
   $self;
}

sub get_property_list {
   return ();
}

1;
##################################################################################


##################################################################################   
package ManagedObjectReference;
our @ISA = qw(ComplexType);

our @property_list = (['type', undef],
                      ['value', undef]);
                      
use Class::MethodMaker  [ scalar => [qw(type value)] ];

sub get_property_list {
   return @property_list;   
}

sub deserialize {
   my ($class, $element_node) = @_;
   if (! defined($element_node)) {
      return undef;
   }
   # deserialize ManagedObjectReference
   my $self = {
      type => $element_node->getAttribute('type'),
      value => $element_node->textContent
   };
   bless $self, $class;
}

sub serialize {
   my ($self, $tag, $show_type) = @_;
   my $type = $self->{type};
   my $id = $self->{value};
   if ($show_type) {
      return "<$tag xsi:type=\"ManagedObjectReference\" type=\"$type\">$id</$tag>\n";
   } else {
      return "<$tag type=\"$type\">$id</$tag>\n";
   }
}

1;
##################################################################################




##################################################################################
package DynamicArray;
our @ISA = qw(ComplexType);

our @property_list = (
   ['dynamicType', undef, undef],
   ['val', 'anyType', 1],
);

use Class::MethodMaker  [ scalar => [qw(dynamicType val)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DynamicData;
our @ISA = qw(ComplexType);

our @property_list = (
   ['dynamicType', undef, undef],
   ['dynamicProperty', 'DynamicProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(dynamicType dynamicProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DynamicProperty;
our @ISA = qw(ComplexType);

our @property_list = (
   ['name', undef, undef],
   ['val', 'anyType', undef],
);

use Class::MethodMaker  [ scalar => [qw(name val)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfDynamicProperty;
our @ISA = qw(ComplexType);

our @property_list = (
   ['DynamicProperty', 'DynamicProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(DynamicProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCommunication;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNotConnected;
our @ISA = qw(HostCommunication);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNotReachable;
our @ISA = qw(HostCommunication);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidArgument;
our @ISA = qw(RuntimeFault);

our @property_list = (
   ['invalidProperty', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(invalidProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidRequest;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidType;
our @ISA = qw(InvalidRequest);

our @property_list = (
   ['argument', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(argument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ManagedObjectNotFound;
our @ISA = qw(RuntimeFault);

our @property_list = (
   ['obj', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(obj)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MethodNotFound;
our @ISA = qw(InvalidRequest);

our @property_list = (
   ['receiver', 'ManagedObjectReference', undef],
   ['method', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(receiver method)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotEnoughLicenses;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotImplemented;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotSupported;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RequestCanceled;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SecurityError;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SystemError;
our @ISA = qw(RuntimeFault);

our @property_list = (
   ['reason', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidCollectorVersion;
our @ISA = qw(MethodFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidProperty;
our @ISA = qw(MethodFault);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PropertyFilterSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['propSet', 'PropertySpec', 1],
   ['objectSet', 'ObjectSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(propSet objectSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPropertyFilterSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PropertyFilterSpec', 'PropertyFilterSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(PropertyFilterSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PropertySpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['type', undef, undef],
   ['all', undef, undef],
   ['pathSet', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(type all pathSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPropertySpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PropertySpec', 'PropertySpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(PropertySpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ObjectSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['obj', 'ManagedObjectReference', undef],
   ['skip', undef, undef],
   ['selectSet', 'SelectionSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(obj skip selectSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfObjectSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ObjectSpec', 'ObjectSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(ObjectSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SelectionSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfSelectionSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['SelectionSpec', 'SelectionSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(SelectionSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TraversalSpec;
our @ISA = qw(SelectionSpec);

our @property_list = (
   ['type', undef, undef],
   ['path', undef, undef],
   ['skip', undef, undef],
   ['selectSet', 'SelectionSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(type path skip selectSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ObjectContent;
our @ISA = qw(DynamicData);

our @property_list = (
   ['obj', 'ManagedObjectReference', undef],
   ['propSet', 'DynamicProperty', 1],
   ['missingSet', 'MissingProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(obj propSet missingSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfObjectContent;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ObjectContent', 'ObjectContent', 1],
);

use Class::MethodMaker  [ scalar => [qw(ObjectContent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UpdateSet;
our @ISA = qw(DynamicData);

our @property_list = (
   ['version', undef, undef],
   ['filterSet', 'PropertyFilterUpdate', 1],
);

use Class::MethodMaker  [ scalar => [qw(version filterSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PropertyFilterUpdate;
our @ISA = qw(DynamicData);

our @property_list = (
   ['filter', 'ManagedObjectReference', undef],
   ['objectSet', 'ObjectUpdate', 1],
   ['missingSet', 'MissingObject', 1],
);

use Class::MethodMaker  [ scalar => [qw(filter objectSet missingSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPropertyFilterUpdate;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PropertyFilterUpdate', 'PropertyFilterUpdate', 1],
);

use Class::MethodMaker  [ scalar => [qw(PropertyFilterUpdate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ObjectUpdate;
our @ISA = qw(DynamicData);

our @property_list = (
   ['kind', 'ObjectUpdateKind', undef],
   ['obj', 'ManagedObjectReference', undef],
   ['changeSet', 'PropertyChange', 1],
   ['missingSet', 'MissingProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(kind obj changeSet missingSet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfObjectUpdate;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ObjectUpdate', 'ObjectUpdate', 1],
);

use Class::MethodMaker  [ scalar => [qw(ObjectUpdate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PropertyChange;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['op', 'PropertyChangeOp', undef],
   ['val', 'anyType', undef],
);

use Class::MethodMaker  [ scalar => [qw(name op val)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPropertyChange;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PropertyChange', 'PropertyChange', 1],
);

use Class::MethodMaker  [ scalar => [qw(PropertyChange)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MissingProperty;
our @ISA = qw(DynamicData);

our @property_list = (
   ['path', undef, undef],
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(path fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfMissingProperty;
our @ISA = qw(ComplexType);

our @property_list = (
   ['MissingProperty', 'MissingProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(MissingProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MissingObject;
our @ISA = qw(DynamicData);

our @property_list = (
   ['obj', 'ManagedObjectReference', undef],
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(obj fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfMissingObject;
our @ISA = qw(ComplexType);

our @property_list = (
   ['MissingObject', 'MissingObject', 1],
);

use Class::MethodMaker  [ scalar => [qw(MissingObject)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LocalizedMethodFault;
our @ISA = qw(DynamicData);

our @property_list = (
   ['fault', 'MethodFault', undef],
   ['localizedMessage', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(fault localizedMessage)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MethodFault;
our @ISA = qw(ComplexType);

our @property_list = (
   ['dynamicType', undef, undef],
   ['dynamicProperty', 'DynamicProperty', 1],
);

use Class::MethodMaker  [ scalar => [qw(dynamicType dynamicProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RuntimeFault;
our @ISA = qw(MethodFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AboutInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['fullName', undef, undef],
   ['vendor', undef, undef],
   ['version', undef, undef],
   ['build', undef, undef],
   ['localeVersion', undef, undef],
   ['localeBuild', undef, undef],
   ['osType', undef, undef],
   ['productLineId', undef, undef],
   ['apiType', undef, undef],
   ['apiVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name fullName vendor version build localeVersion localeBuild osType productLineId apiType apiVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AuthorizationDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['privilege', 'ElementDescription', 1],
   ['privilegeGroup', 'ElementDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(privilege privilegeGroup)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Permission;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['principal', undef, undef],
   ['group', undef, undef],
   ['roleId', undef, undef],
   ['propagate', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity principal group roleId propagate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPermission;
our @ISA = qw(ComplexType);

our @property_list = (
   ['Permission', 'Permission', 1],
);

use Class::MethodMaker  [ scalar => [qw(Permission)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AuthorizationRole;
our @ISA = qw(DynamicData);

our @property_list = (
   ['roleId', undef, undef],
   ['system', undef, undef],
   ['name', undef, undef],
   ['info', 'Description', undef],
   ['privilege', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(roleId system name info privilege)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAuthorizationRole;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AuthorizationRole', 'AuthorizationRole', 1],
);

use Class::MethodMaker  [ scalar => [qw(AuthorizationRole)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AuthorizationPrivilege;
our @ISA = qw(DynamicData);

our @property_list = (
   ['privId', undef, undef],
   ['onParent', undef, undef],
   ['name', undef, undef],
   ['privGroupName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(privId onParent name privGroupName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAuthorizationPrivilege;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AuthorizationPrivilege', 'AuthorizationPrivilege', 1],
);

use Class::MethodMaker  [ scalar => [qw(AuthorizationPrivilege)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Capability;
our @ISA = qw(DynamicData);

our @property_list = (
   ['provisioningSupported', undef, undef],
   ['multiHostSupported', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(provisioningSupported multiHostSupported)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterComputeResourceSummary;
our @ISA = qw(ComputeResourceSummary);

our @property_list = (
   ['currentFailoverLevel', undef, undef],
   ['numVmotions', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(currentFailoverLevel numVmotions)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ComputeResourceSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['totalCpu', undef, undef],
   ['totalMemory', undef, undef],
   ['numCpuCores', undef, undef],
   ['numCpuThreads', undef, undef],
   ['effectiveCpu', undef, undef],
   ['effectiveMemory', undef, undef],
   ['numHosts', undef, undef],
   ['numEffectiveHosts', undef, undef],
   ['overallStatus', 'ManagedEntityStatus', undef],
);

use Class::MethodMaker  [ scalar => [qw(totalCpu totalMemory numCpuCores numCpuThreads effectiveCpu effectiveMemory numHosts numEffectiveHosts overallStatus)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldDef;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['name', undef, undef],
   ['type', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key name type)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfCustomFieldDef;
our @ISA = qw(ComplexType);

our @property_list = (
   ['CustomFieldDef', 'CustomFieldDef', 1],
);

use Class::MethodMaker  [ scalar => [qw(CustomFieldDef)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldValue;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfCustomFieldValue;
our @ISA = qw(ComplexType);

our @property_list = (
   ['CustomFieldValue', 'CustomFieldValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(CustomFieldValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldStringValue;
our @ISA = qw(CustomFieldValue);

our @property_list = (
   ['value', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationSpecInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['description', undef, undef],
   ['type', undef, undef],
   ['changeVersion', undef, undef],
   ['lastUpdateTime', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name description type changeVersion lastUpdateTime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfCustomizationSpecInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['CustomizationSpecInfo', 'CustomizationSpecInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(CustomizationSpecInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationSpecItem;
our @ISA = qw(DynamicData);

our @property_list = (
   ['info', 'CustomizationSpecInfo', undef],
   ['spec', 'CustomizationSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(info spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
   ['name', undef, undef],
   ['url', undef, undef],
   ['capacity', undef, undef],
   ['freeSpace', undef, undef],
   ['accessible', undef, undef],
   ['multipleHostAccess', undef, undef],
   ['type', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore name url capacity freeSpace accessible multipleHostAccess type)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['url', undef, undef],
   ['freeSpace', undef, undef],
   ['maxFileSize', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name url freeSpace maxFileSize)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreCapability;
our @ISA = qw(DynamicData);

our @property_list = (
   ['directoryHierarchySupported', undef, undef],
   ['rawDiskMappingsSupported', undef, undef],
   ['perFileThinProvisioningSupported', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(directoryHierarchySupported rawDiskMappingsSupported perFileThinProvisioningSupported)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreHostMount;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', 'ManagedObjectReference', undef],
   ['mountInfo', 'HostMountInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(key mountInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfDatastoreHostMount;
our @ISA = qw(ComplexType);

our @property_list = (
   ['DatastoreHostMount', 'DatastoreHostMount', 1],
);

use Class::MethodMaker  [ scalar => [qw(DatastoreHostMount)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Description;
our @ISA = qw(DynamicData);

our @property_list = (
   ['label', undef, undef],
   ['summary', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(label summary)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DiagnosticManagerLogDescriptor;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['fileName', undef, undef],
   ['creator', undef, undef],
   ['format', undef, undef],
   ['mimeType', undef, undef],
   ['info', 'Description', undef],
);

use Class::MethodMaker  [ scalar => [qw(key fileName creator format mimeType info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfDiagnosticManagerLogDescriptor;
our @ISA = qw(ComplexType);

our @property_list = (
   ['DiagnosticManagerLogDescriptor', 'DiagnosticManagerLogDescriptor', 1],
);

use Class::MethodMaker  [ scalar => [qw(DiagnosticManagerLogDescriptor)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DiagnosticManagerLogHeader;
our @ISA = qw(DynamicData);

our @property_list = (
   ['lineStart', undef, undef],
   ['lineEnd', undef, undef],
   ['lineText', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(lineStart lineEnd lineText)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DiagnosticManagerBundleInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['system', 'ManagedObjectReference', undef],
   ['url', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(system url)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfDiagnosticManagerBundleInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['DiagnosticManagerBundleInfo', 'DiagnosticManagerBundleInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(DiagnosticManagerBundleInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ElementDescription;
our @ISA = qw(Description);

our @property_list = (
   ['key', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfElementDescription;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ElementDescription', 'ElementDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(ElementDescription)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostServiceTicket;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', undef, undef],
   ['port', undef, undef],
   ['service', undef, undef],
   ['serviceVersion', undef, undef],
   ['sessionId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(host port service serviceVersion sessionId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseSource;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseServerSource;
our @ISA = qw(LicenseSource);

our @property_list = (
   ['licenseServer', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseServer)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LocalLicenseSource;
our @ISA = qw(LicenseSource);

our @property_list = (
   ['licenseKeys', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseKeys)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseFeatureInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['featureName', undef, undef],
   ['state', 'LicenseFeatureInfoState', undef],
   ['costUnit', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key featureName state costUnit)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfLicenseFeatureInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['LicenseFeatureInfo', 'LicenseFeatureInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(LicenseFeatureInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseReservationInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['state', 'LicenseReservationInfoState', undef],
   ['required', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key state required)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfLicenseReservationInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['LicenseReservationInfo', 'LicenseReservationInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(LicenseReservationInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseAvailabilityInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['feature', 'LicenseFeatureInfo', undef],
   ['total', undef, undef],
   ['available', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(feature total available)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfLicenseAvailabilityInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['LicenseAvailabilityInfo', 'LicenseAvailabilityInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(LicenseAvailabilityInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseUsageInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['source', 'LicenseSource', undef],
   ['sourceAvailable', undef, undef],
   ['reservationInfo', 'LicenseReservationInfo', 1],
   ['featureInfo', 'LicenseFeatureInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(source sourceAvailable reservationInfo featureInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MethodDescription;
our @ISA = qw(Description);

our @property_list = (
   ['key', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NetworkSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['network', 'ManagedObjectReference', undef],
   ['name', undef, undef],
   ['accessible', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(network name accessible)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerformanceDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['counterType', 'ElementDescription', 1],
   ['statsType', 'ElementDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(counterType statsType)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfProviderSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['currentSupported', undef, undef],
   ['summarySupported', undef, undef],
   ['refreshRate', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity currentSupported summarySupported refreshRate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfCounterInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['nameInfo', 'ElementDescription', undef],
   ['groupInfo', 'ElementDescription', undef],
   ['unitInfo', 'ElementDescription', undef],
   ['rollupType', 'PerfSummaryType', undef],
   ['statsType', 'PerfStatsType', undef],
   ['associatedCounterId', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(key nameInfo groupInfo unitInfo rollupType statsType associatedCounterId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfCounterInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfCounterInfo', 'PerfCounterInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfCounterInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfMetricId;
our @ISA = qw(DynamicData);

our @property_list = (
   ['counterId', undef, undef],
   ['instance', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(counterId instance)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfMetricId;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfMetricId', 'PerfMetricId', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfMetricId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfQuerySpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['startTime', undef, undef],
   ['endTime', undef, undef],
   ['maxSample', undef, undef],
   ['metricId', 'PerfMetricId', 1],
   ['intervalId', undef, undef],
   ['format', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity startTime endTime maxSample metricId intervalId format)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfQuerySpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfQuerySpec', 'PerfQuerySpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfQuerySpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfSampleInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['timestamp', undef, undef],
   ['interval', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(timestamp interval)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfSampleInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfSampleInfo', 'PerfSampleInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfSampleInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfMetricSeries;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', 'PerfMetricId', undef],
);

use Class::MethodMaker  [ scalar => [qw(id)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfMetricSeries;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfMetricSeries', 'PerfMetricSeries', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfMetricSeries)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfMetricIntSeries;
our @ISA = qw(PerfMetricSeries);

our @property_list = (
   ['value', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfMetricSeriesCSV;
our @ISA = qw(PerfMetricSeries);

our @property_list = (
   ['value', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfMetricSeriesCSV;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfMetricSeriesCSV', 'PerfMetricSeriesCSV', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfMetricSeriesCSV)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfEntityMetricBase;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfEntityMetricBase;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfEntityMetricBase', 'PerfEntityMetricBase', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfEntityMetricBase)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfEntityMetric;
our @ISA = qw(PerfEntityMetricBase);

our @property_list = (
   ['sampleInfo', 'PerfSampleInfo', 1],
   ['value', 'PerfMetricSeries', 1],
);

use Class::MethodMaker  [ scalar => [qw(sampleInfo value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfEntityMetricCSV;
our @ISA = qw(PerfEntityMetricBase);

our @property_list = (
   ['sampleInfoCSV', undef, undef],
   ['value', 'PerfMetricSeriesCSV', 1],
);

use Class::MethodMaker  [ scalar => [qw(sampleInfoCSV value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfEntityMetricCSV;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfEntityMetricCSV', 'PerfEntityMetricCSV', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfEntityMetricCSV)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfCompositeMetric;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'PerfEntityMetricBase', undef],
   ['childEntity', 'PerfEntityMetricBase', 1],
);

use Class::MethodMaker  [ scalar => [qw(entity childEntity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PerfInterval;
our @ISA = qw(DynamicData);

our @property_list = (
   ['samplingPeriod', undef, undef],
   ['name', undef, undef],
   ['length', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(samplingPeriod name length)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPerfInterval;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PerfInterval', 'PerfInterval', 1],
);

use Class::MethodMaker  [ scalar => [qw(PerfInterval)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourceAllocationInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['reservation', undef, undef],
   ['expandableReservation', undef, undef],
   ['limit', undef, undef],
   ['shares', 'SharesInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(reservation expandableReservation limit shares)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourceConfigSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['changeVersion', undef, undef],
   ['lastModified', undef, undef],
   ['cpuAllocation', 'ResourceAllocationInfo', undef],
   ['memoryAllocation', 'ResourceAllocationInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity changeVersion lastModified cpuAllocation memoryAllocation)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfResourceConfigSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ResourceConfigSpec', 'ResourceConfigSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(ResourceConfigSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolResourceUsage;
our @ISA = qw(DynamicData);

our @property_list = (
   ['reservationUsed', undef, undef],
   ['reservationUsedForVm', undef, undef],
   ['unreservedForPool', undef, undef],
   ['unreservedForVm', undef, undef],
   ['overallUsage', undef, undef],
   ['maxUsage', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(reservationUsed reservationUsedForVm unreservedForPool unreservedForVm overallUsage maxUsage)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolRuntimeInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['memory', 'ResourcePoolResourceUsage', undef],
   ['cpu', 'ResourcePoolResourceUsage', undef],
   ['overallStatus', 'ManagedEntityStatus', undef],
);

use Class::MethodMaker  [ scalar => [qw(memory cpu overallStatus)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['config', 'ResourceConfigSpec', undef],
   ['runtime', 'ResourcePoolRuntimeInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(name config runtime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionCompatibility;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
   ['compatibility', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(host compatibility)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVMotionCompatibility;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVMotionCompatibility', 'HostVMotionCompatibility', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVMotionCompatibility)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ServiceContent;
our @ISA = qw(DynamicData);

our @property_list = (
   ['rootFolder', 'ManagedObjectReference', undef],
   ['propertyCollector', 'ManagedObjectReference', undef],
   ['about', 'AboutInfo', undef],
   ['setting', 'ManagedObjectReference', undef],
   ['userDirectory', 'ManagedObjectReference', undef],
   ['sessionManager', 'ManagedObjectReference', undef],
   ['authorizationManager', 'ManagedObjectReference', undef],
   ['perfManager', 'ManagedObjectReference', undef],
   ['scheduledTaskManager', 'ManagedObjectReference', undef],
   ['alarmManager', 'ManagedObjectReference', undef],
   ['eventManager', 'ManagedObjectReference', undef],
   ['taskManager', 'ManagedObjectReference', undef],
   ['customizationSpecManager', 'ManagedObjectReference', undef],
   ['customFieldsManager', 'ManagedObjectReference', undef],
   ['accountManager', 'ManagedObjectReference', undef],
   ['diagnosticManager', 'ManagedObjectReference', undef],
   ['licenseManager', 'ManagedObjectReference', undef],
   ['searchIndex', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(rootFolder propertyCollector about setting userDirectory sessionManager authorizationManager perfManager scheduledTaskManager alarmManager eventManager taskManager customizationSpecManager customFieldsManager accountManager diagnosticManager licenseManager searchIndex)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SessionManagerLocalTicket;
our @ISA = qw(DynamicData);

our @property_list = (
   ['userName', undef, undef],
   ['passwordFilePath', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(userName passwordFilePath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserSession;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['userName', undef, undef],
   ['fullName', undef, undef],
   ['loginTime', undef, undef],
   ['lastActiveTime', undef, undef],
   ['locale', undef, undef],
   ['messageLocale', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key userName fullName loginTime lastActiveTime locale messageLocale)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfUserSession;
our @ISA = qw(ComplexType);

our @property_list = (
   ['UserSession', 'UserSession', 1],
);

use Class::MethodMaker  [ scalar => [qw(UserSession)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SharesInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['shares', undef, undef],
   ['level', 'SharesLevel', undef],
);

use Class::MethodMaker  [ scalar => [qw(shares level)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['methodInfo', 'ElementDescription', 1],
   ['state', 'ElementDescription', 1],
   ['reason', 'TypeDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(methodInfo state reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskFilterSpecByEntity;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['recursion', 'TaskFilterSpecRecursionOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity recursion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskFilterSpecByTime;
our @ISA = qw(DynamicData);

our @property_list = (
   ['timeType', 'TaskFilterSpecTimeOption', undef],
   ['beginTime', undef, undef],
   ['endTime', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(timeType beginTime endTime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskFilterSpecByUsername;
our @ISA = qw(DynamicData);

our @property_list = (
   ['systemUser', undef, undef],
   ['userList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(systemUser userList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskFilterSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'TaskFilterSpecByEntity', undef],
   ['time', 'TaskFilterSpecByTime', undef],
   ['userName', 'TaskFilterSpecByUsername', undef],
   ['state', 'TaskInfoState', 1],
   ['alarm', 'ManagedObjectReference', undef],
   ['scheduledTask', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity time userName state alarm scheduledTask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfTaskInfoState;
our @ISA = qw(ComplexType);

our @property_list = (
   ['TaskInfoState', 'TaskInfoState', 1],
);

use Class::MethodMaker  [ scalar => [qw(TaskInfoState)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['task', 'ManagedObjectReference', undef],
   ['name', undef, undef],
   ['descriptionId', undef, undef],
   ['entity', 'ManagedObjectReference', undef],
   ['entityName', undef, undef],
   ['locked', 'ManagedObjectReference', 1],
   ['state', 'TaskInfoState', undef],
   ['cancelled', undef, undef],
   ['cancelable', undef, undef],
   ['error', 'LocalizedMethodFault', undef],
   ['result', 'anyType', undef],
   ['progress', undef, undef],
   ['reason', 'TaskReason', undef],
   ['queueTime', undef, undef],
   ['startTime', undef, undef],
   ['completeTime', undef, undef],
   ['eventChainId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key task name descriptionId entity entityName locked state cancelled cancelable error result progress reason queueTime startTime completeTime eventChainId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfTaskInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['TaskInfo', 'TaskInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(TaskInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskReason;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskReasonSystem;
our @ISA = qw(TaskReason);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskReasonUser;
our @ISA = qw(TaskReason);

our @property_list = (
   ['userName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(userName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskReasonAlarm;
our @ISA = qw(TaskReason);

our @property_list = (
   ['alarmName', undef, undef],
   ['alarm', 'ManagedObjectReference', undef],
   ['entityName', undef, undef],
   ['entity', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(alarmName alarm entityName entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskReasonSchedule;
our @ISA = qw(TaskReason);

our @property_list = (
   ['name', undef, undef],
   ['scheduledTask', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(name scheduledTask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TypeDescription;
our @ISA = qw(Description);

our @property_list = (
   ['key', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfTypeDescription;
our @ISA = qw(ComplexType);

our @property_list = (
   ['TypeDescription', 'TypeDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(TypeDescription)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserSearchResult;
our @ISA = qw(DynamicData);

our @property_list = (
   ['principal', undef, undef],
   ['fullName', undef, undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(principal fullName group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfUserSearchResult;
our @ISA = qw(ComplexType);

our @property_list = (
   ['UserSearchResult', 'UserSearchResult', 1],
);

use Class::MethodMaker  [ scalar => [qw(UserSearchResult)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PosixUserSearchResult;
our @ISA = qw(UserSearchResult);

our @property_list = (
   ['id', undef, undef],
   ['shellAccess', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(id shellAccess)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineMksTicket;
our @ISA = qw(DynamicData);

our @property_list = (
   ['ticket', undef, undef],
   ['cfgFile', undef, undef],
   ['host', undef, undef],
   ['port', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ticket cfgFile host port)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Action;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MethodActionArgument;
our @ISA = qw(DynamicData);

our @property_list = (
   ['value', 'anyType', undef],
);

use Class::MethodMaker  [ scalar => [qw(value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfMethodActionArgument;
our @ISA = qw(ComplexType);

our @property_list = (
   ['MethodActionArgument', 'MethodActionArgument', 1],
);

use Class::MethodMaker  [ scalar => [qw(MethodActionArgument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MethodAction;
our @ISA = qw(Action);

our @property_list = (
   ['name', undef, undef],
   ['argument', 'MethodActionArgument', 1],
);

use Class::MethodMaker  [ scalar => [qw(name argument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SendEmailAction;
our @ISA = qw(Action);

our @property_list = (
   ['toList', undef, undef],
   ['ccList', undef, undef],
   ['subject', undef, undef],
   ['body', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(toList ccList subject body)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SendSNMPAction;
our @ISA = qw(Action);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RunScriptAction;
our @ISA = qw(Action);

our @property_list = (
   ['script', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(script)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmAction;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAlarmAction;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AlarmAction', 'AlarmAction', 1],
);

use Class::MethodMaker  [ scalar => [qw(AlarmAction)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmTriggeringAction;
our @ISA = qw(AlarmAction);

our @property_list = (
   ['action', 'Action', undef],
   ['green2yellow', undef, undef],
   ['yellow2red', undef, undef],
   ['red2yellow', undef, undef],
   ['yellow2green', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(action green2yellow yellow2red red2yellow yellow2green)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GroupAlarmAction;
our @ISA = qw(AlarmAction);

our @property_list = (
   ['action', 'AlarmAction', 1],
);

use Class::MethodMaker  [ scalar => [qw(action)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['expr', 'TypeDescription', 1],
   ['stateOperator', 'ElementDescription', 1],
   ['metricOperator', 'ElementDescription', 1],
   ['hostSystemConnectionState', 'ElementDescription', 1],
   ['virtualMachinePowerState', 'ElementDescription', 1],
   ['entityStatus', 'ElementDescription', 1],
   ['action', 'TypeDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(expr stateOperator metricOperator hostSystemConnectionState virtualMachinePowerState entityStatus action)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmExpression;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAlarmExpression;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AlarmExpression', 'AlarmExpression', 1],
);

use Class::MethodMaker  [ scalar => [qw(AlarmExpression)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AndAlarmExpression;
our @ISA = qw(AlarmExpression);

our @property_list = (
   ['expression', 'AlarmExpression', 1],
);

use Class::MethodMaker  [ scalar => [qw(expression)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OrAlarmExpression;
our @ISA = qw(AlarmExpression);

our @property_list = (
   ['expression', 'AlarmExpression', 1],
);

use Class::MethodMaker  [ scalar => [qw(expression)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package StateAlarmExpression;
our @ISA = qw(AlarmExpression);

our @property_list = (
   ['operator', 'StateAlarmOperator', undef],
   ['type', undef, undef],
   ['statePath', undef, undef],
   ['yellow', undef, undef],
   ['red', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(operator type statePath yellow red)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MetricAlarmExpression;
our @ISA = qw(AlarmExpression);

our @property_list = (
   ['operator', 'MetricAlarmOperator', undef],
   ['type', undef, undef],
   ['metric', 'PerfMetricId', undef],
   ['yellow', undef, undef],
   ['red', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(operator type metric yellow red)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmInfo;
our @ISA = qw(AlarmSpec);

our @property_list = (
   ['key', undef, undef],
   ['alarm', 'ManagedObjectReference', undef],
   ['entity', 'ManagedObjectReference', undef],
   ['lastModifiedTime', undef, undef],
   ['lastModifiedUser', undef, undef],
   ['creationEventId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key alarm entity lastModifiedTime lastModifiedUser creationEventId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmSetting;
our @ISA = qw(DynamicData);

our @property_list = (
   ['toleranceRange', undef, undef],
   ['reportingFrequency', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(toleranceRange reportingFrequency)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['description', undef, undef],
   ['enabled', undef, undef],
   ['expression', 'AlarmExpression', undef],
   ['action', 'AlarmAction', undef],
   ['setting', 'AlarmSetting', undef],
);

use Class::MethodMaker  [ scalar => [qw(name description enabled expression action setting)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmState;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['entity', 'ManagedObjectReference', undef],
   ['alarm', 'ManagedObjectReference', undef],
   ['overallStatus', 'ManagedEntityStatus', undef],
   ['time', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key entity alarm overallStatus time)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAlarmState;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AlarmState', 'AlarmState', 1],
);

use Class::MethodMaker  [ scalar => [qw(AlarmState)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dasConfig', 'ClusterDasConfigInfo', undef],
   ['dasVmConfig', 'ClusterDasVmConfigInfo', 1],
   ['drsConfig', 'ClusterDrsConfigInfo', undef],
   ['drsVmConfig', 'ClusterDrsVmConfigInfo', 1],
   ['rule', 'ClusterRuleInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(dasConfig dasVmConfig drsConfig drsVmConfig rule)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDrsConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['enabled', undef, undef],
   ['defaultVmBehavior', 'DrsBehavior', undef],
   ['vmotionRate', undef, undef],
   ['option', 'OptionValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(enabled defaultVmBehavior vmotionRate option)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDrsVmConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', 'ManagedObjectReference', undef],
   ['enabled', undef, undef],
   ['behavior', 'DrsBehavior', undef],
);

use Class::MethodMaker  [ scalar => [qw(key enabled behavior)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDrsVmConfigInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDrsVmConfigInfo', 'ClusterDrsVmConfigInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDrsVmConfigInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterConfigSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dasConfig', 'ClusterDasConfigInfo', undef],
   ['dasVmConfigSpec', 'ClusterDasVmConfigSpec', 1],
   ['drsConfig', 'ClusterDrsConfigInfo', undef],
   ['drsVmConfigSpec', 'ClusterDrsVmConfigSpec', 1],
   ['rulesSpec', 'ClusterRuleSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(dasConfig dasVmConfigSpec drsConfig drsVmConfigSpec rulesSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDasVmConfigSpec;
our @ISA = qw(ArrayUpdateSpec);

our @property_list = (
   ['info', 'ClusterDasVmConfigInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDasVmConfigSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDasVmConfigSpec', 'ClusterDasVmConfigSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDasVmConfigSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDrsVmConfigSpec;
our @ISA = qw(ArrayUpdateSpec);

our @property_list = (
   ['info', 'ClusterDrsVmConfigInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDrsVmConfigSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDrsVmConfigSpec', 'ClusterDrsVmConfigSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDrsVmConfigSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterRuleSpec;
our @ISA = qw(ArrayUpdateSpec);

our @property_list = (
   ['info', 'ClusterRuleInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterRuleSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterRuleSpec', 'ClusterRuleSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterRuleSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDasConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['enabled', undef, undef],
   ['failoverLevel', undef, undef],
   ['admissionControlEnabled', undef, undef],
   ['option', 'OptionValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(enabled failoverLevel admissionControlEnabled option)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDasVmConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', 'ManagedObjectReference', undef],
   ['restartPriority', 'DasVmPriority', undef],
   ['powerOffOnIsolation', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key restartPriority powerOffOnIsolation)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDasVmConfigInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDasVmConfigInfo', 'ClusterDasVmConfigInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDasVmConfigInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDrsMigration;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['time', undef, undef],
   ['vm', 'ManagedObjectReference', undef],
   ['cpuLoad', undef, undef],
   ['memoryLoad', undef, undef],
   ['source', 'ManagedObjectReference', undef],
   ['sourceCpuLoad', undef, undef],
   ['sourceMemoryLoad', undef, undef],
   ['destination', 'ManagedObjectReference', undef],
   ['destinationCpuLoad', undef, undef],
   ['destinationMemoryLoad', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key time vm cpuLoad memoryLoad source sourceCpuLoad sourceMemoryLoad destination destinationCpuLoad destinationMemoryLoad)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDrsMigration;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDrsMigration', 'ClusterDrsMigration', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDrsMigration)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDrsRecommendation;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['rating', undef, undef],
   ['reason', undef, undef],
   ['reasonText', undef, undef],
   ['migrationList', 'ClusterDrsMigration', 1],
);

use Class::MethodMaker  [ scalar => [qw(key rating reason reasonText migrationList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterDrsRecommendation;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterDrsRecommendation', 'ClusterDrsRecommendation', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterDrsRecommendation)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterHostRecommendation;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
   ['rating', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(host rating)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterHostRecommendation;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterHostRecommendation', 'ClusterHostRecommendation', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterHostRecommendation)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterRuleInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['status', 'ManagedEntityStatus', undef],
   ['enabled', undef, undef],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key status enabled name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfClusterRuleInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ClusterRuleInfo', 'ClusterRuleInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(ClusterRuleInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterAffinityRuleSpec;
our @ISA = qw(ClusterRuleInfo);

our @property_list = (
   ['vm', 'ManagedObjectReference', 1],
);

use Class::MethodMaker  [ scalar => [qw(vm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterAntiAffinityRuleSpec;
our @ISA = qw(ClusterRuleInfo);

our @property_list = (
   ['vm', 'ManagedObjectReference', 1],
);

use Class::MethodMaker  [ scalar => [qw(vm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Event;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['chainId', undef, undef],
   ['createdTime', undef, undef],
   ['userName', undef, undef],
   ['datacenter', 'DatacenterEventArgument', undef],
   ['computeResource', 'ComputeResourceEventArgument', undef],
   ['host', 'HostEventArgument', undef],
   ['vm', 'VmEventArgument', undef],
   ['fullFormattedMessage', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key chainId createdTime userName datacenter computeResource host vm fullFormattedMessage)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfEvent;
our @ISA = qw(ComplexType);

our @property_list = (
   ['Event', 'Event', 1],
);

use Class::MethodMaker  [ scalar => [qw(Event)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralEvent;
our @ISA = qw(Event);

our @property_list = (
   ['message', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(message)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralHostInfoEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralHostWarningEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralHostErrorEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralVmInfoEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralVmWarningEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralVmErrorEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GeneralUserEvent;
our @ISA = qw(GeneralEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SessionEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ServerStartedSessionEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserLoginSessionEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
   ['ipAddress', undef, undef],
   ['locale', undef, undef],
   ['sessionId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipAddress locale sessionId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserLogoutSessionEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package BadUsernameSessionEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
   ['ipAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlreadyAuthenticatedSessionEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoAccessUserEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
   ['ipAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SessionTerminatedEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
   ['sessionId', undef, undef],
   ['terminatedUsername', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(sessionId terminatedUsername)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GlobalMessageChangedEvent;
our @ISA = qw(SessionEvent);

our @property_list = (
   ['message', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(message)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UpgradeEvent;
our @ISA = qw(Event);

our @property_list = (
   ['message', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(message)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InfoUpgradeEvent;
our @ISA = qw(UpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package WarningUpgradeEvent;
our @ISA = qw(UpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ErrorUpgradeEvent;
our @ISA = qw(UpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserUpgradeEvent;
our @ISA = qw(UpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDisconnectedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectionLostEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostReconnectionFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedNoConnectionEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedBadUsernameEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedBadVersionEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedAlreadyManagedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['serverName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(serverName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedNoLicenseEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedNetworkErrorEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostRemovedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedCcagentUpgradeEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedBadCcagentEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedAccountFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedNoAccessEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostShutdownEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['reason', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedNotFoundEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCnxFailedTimeoutEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostUpgradeFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EnteringMaintenanceModeEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EnteredMaintenanceModeEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ExitMaintenanceModeEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CanceledHostOperationEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TimedOutHostOperationEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasEnabledEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasDisabledEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasEnablingEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasDisablingEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasErrorEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDasOkEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VcAgentUpgradedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VcAgentUpgradeFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostAddedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostAddFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['hostname', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hostname)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AccountCreatedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['spec', 'HostAccountSpec', undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(spec group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AccountRemovedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['account', undef, undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(account group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserPasswordChanged;
our @ISA = qw(HostEvent);

our @property_list = (
   ['userLogin', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(userLogin)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AccountUpdatedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['spec', 'HostAccountSpec', undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(spec group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserAssignedToGroup;
our @ISA = qw(HostEvent);

our @property_list = (
   ['userLogin', undef, undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(userLogin group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserUnassignedFromGroup;
our @ISA = qw(HostEvent);

our @property_list = (
   ['userLogin', undef, undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(userLogin group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastorePrincipalConfigured;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastorePrincipal', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastorePrincipal)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMFSDatastoreCreatedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NASDatastoreCreatedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LocalDatastoreCreatedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreRemovedOnHostEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreRenamedOnHostEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['oldName', undef, undef],
   ['newName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldName newName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreDiscoveredEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DrsResourceConfigureFailedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DrsResourceConfigureSyncedEvent;
our @ISA = qw(HostEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmEvent;
our @ISA = qw(Event);

our @property_list = (
   ['template', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(template)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmPoweredOffEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmPoweredOnEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmSuspendedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmStartingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmStoppingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmSuspendingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmResumingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDisconnectedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiscoveredEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmOrphanedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingCreatedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['configSpec', 'VirtualMachineConfigSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(configSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmCreatedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRegisteredEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmAutoRenameEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['oldName', undef, undef],
   ['newName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldName newName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingHotMigratedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmResettingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmStaticMacConflictEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['conflictedVm', 'VmEventArgument', undef],
   ['mac', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(conflictedVm mac)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmMacConflictEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['conflictedVm', 'VmEventArgument', undef],
   ['mac', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(conflictedVm mac)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingDeployedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['srcTemplate', 'VmEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(srcTemplate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDeployFailedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['destDatastore', 'EntityEventArgument', undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(destDatastore reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDeployedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['srcTemplate', 'VmEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(srcTemplate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmMacChangedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['adapter', undef, undef],
   ['oldMac', undef, undef],
   ['newMac', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(adapter oldMac newMac)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmMacAssignedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['adapter', undef, undef],
   ['mac', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(adapter mac)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUuidConflictEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['conflictedVm', 'VmEventArgument', undef],
   ['uuid', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(conflictedVm uuid)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingMigratedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedMigrateEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmMigratedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['sourceHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(sourceHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUnsupportedStartingEvent;
our @ISA = qw(VmStartingEvent);

our @property_list = (
   ['guestId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(guestId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DrsVmMigratedEvent;
our @ISA = qw(VmMigratedEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRelocateSpecEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingRelocatedEvent;
our @ISA = qw(VmRelocateSpecEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRelocatedEvent;
our @ISA = qw(VmRelocateSpecEvent);

our @property_list = (
   ['sourceHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(sourceHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRelocateFailedEvent;
our @ISA = qw(VmRelocateSpecEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmEmigratingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmCloneEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmBeingClonedEvent;
our @ISA = qw(VmCloneEvent);

our @property_list = (
   ['destFolder', 'FolderEventArgument', undef],
   ['destName', undef, undef],
   ['destHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(destFolder destName destHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmCloneFailedEvent;
our @ISA = qw(VmCloneEvent);

our @property_list = (
   ['destFolder', 'FolderEventArgument', undef],
   ['destName', undef, undef],
   ['destHost', 'HostEventArgument', undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(destFolder destName destHost reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmClonedEvent;
our @ISA = qw(VmCloneEvent);

our @property_list = (
   ['sourceVm', 'VmEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(sourceVm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmResourceReallocatedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRenamedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['oldName', undef, undef],
   ['newName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldName newName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDateRolledBackEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmNoNetworkAccessEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['destHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(destHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiskFailedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['disk', undef, undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(disk reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToPowerOnEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToPowerOffEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToSuspendEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToResetEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToShutdownGuestEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToRebootGuestEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedToStandbyGuestEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRemovedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmGuestShutdownEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmGuestRebootEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmGuestStandbyEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUpgradingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['version', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(version)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUpgradeCompleteEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['version', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(version)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUpgradeFailedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRestartedOnAlternateHostEvent;
our @ISA = qw(VmPoweredOnEvent);

our @property_list = (
   ['sourceHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(sourceHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmReconfiguredEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['configSpec', 'VirtualMachineConfigSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(configSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmMessageEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['message', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(message)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigMissingEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmPowerOffOnIsolationEvent;
our @ISA = qw(VmPoweredOffEvent);

our @property_list = (
   ['isolatedHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(isolatedHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailoverFailed;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotEnoughResourcesToStartVmEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUuidAssignedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['uuid', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(uuid)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmUuidChangedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['oldUuid', undef, undef],
   ['newUuid', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldUuid newUuid)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedRelayoutOnVmfs2DatastoreEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmFailedRelayoutEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRelayoutSuccessfulEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmRelayoutUpToDateEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConnectedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDasUpdateErrorEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoMaintenanceModeDrsRecommendationForVM;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDasUpdateOkEvent;
our @ISA = qw(VmEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskEvent;
our @ISA = qw(Event);

our @property_list = (
   ['scheduledTask', 'ScheduledTaskEventArgument', undef],
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(scheduledTask entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskCreatedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskStartedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskRemovedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskReconfiguredEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskCompletedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskFailedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskEmailCompletedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
   ['to', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(to)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskEmailFailedEvent;
our @ISA = qw(ScheduledTaskEvent);

our @property_list = (
   ['to', undef, undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(to reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmEvent;
our @ISA = qw(Event);

our @property_list = (
   ['alarm', 'AlarmEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(alarm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmCreatedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmStatusChangedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['source', 'ManagedEntityEventArgument', undef],
   ['entity', 'ManagedEntityEventArgument', undef],
   ['from', undef, undef],
   ['to', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(source entity from to)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmActionTriggeredEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['source', 'ManagedEntityEventArgument', undef],
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(source entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmEmailCompletedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['to', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity to)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmEmailFailedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['to', undef, undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity to reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmSnmpCompletedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmSnmpFailedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmScriptCompleteEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['script', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity script)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmScriptFailedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['script', undef, undef],
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity script reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmRemovedEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmReconfiguredEvent;
our @ISA = qw(AlarmEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldDefEvent;
our @ISA = qw(CustomFieldEvent);

our @property_list = (
   ['fieldKey', undef, undef],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(fieldKey name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldDefAddedEvent;
our @ISA = qw(CustomFieldDefEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldDefRemovedEvent;
our @ISA = qw(CustomFieldDefEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldDefRenamedEvent;
our @ISA = qw(CustomFieldDefEvent);

our @property_list = (
   ['newName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(newName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomFieldValueChangedEvent;
our @ISA = qw(CustomFieldEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['fieldKey', undef, undef],
   ['name', undef, undef],
   ['value', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity fieldKey name value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AuthorizationEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PermissionEvent;
our @ISA = qw(AuthorizationEvent);

our @property_list = (
   ['entity', 'ManagedEntityEventArgument', undef],
   ['principal', undef, undef],
   ['group', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(entity principal group)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PermissionAddedEvent;
our @ISA = qw(PermissionEvent);

our @property_list = (
   ['role', 'RoleEventArgument', undef],
   ['propagate', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(role propagate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PermissionUpdatedEvent;
our @ISA = qw(PermissionEvent);

our @property_list = (
   ['role', 'RoleEventArgument', undef],
   ['propagate', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(role propagate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PermissionRemovedEvent;
our @ISA = qw(PermissionEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RoleEvent;
our @ISA = qw(AuthorizationEvent);

our @property_list = (
   ['role', 'RoleEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(role)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RoleAddedEvent;
our @ISA = qw(RoleEvent);

our @property_list = (
   ['privilegeList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(privilegeList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RoleUpdatedEvent;
our @ISA = qw(RoleEvent);

our @property_list = (
   ['privilegeList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(privilegeList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RoleRemovedEvent;
our @ISA = qw(RoleEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreEvent;
our @ISA = qw(Event);

our @property_list = (
   ['datastore', 'DatastoreEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreDestroyedEvent;
our @ISA = qw(DatastoreEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreRenamedEvent;
our @ISA = qw(DatastoreEvent);

our @property_list = (
   ['oldName', undef, undef],
   ['newName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldName newName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreDuplicatedEvent;
our @ISA = qw(DatastoreEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskEvent;
our @ISA = qw(Event);

our @property_list = (
   ['info', 'TaskInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ServerLicenseExpiredEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
   ['product', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(product)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostLicenseExpiredEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionLicenseExpiredEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoLicenseEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
   ['feature', 'LicenseFeatureInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(feature)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseServerUnavailableEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
   ['licenseServer', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseServer)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseServerAvailableEvent;
our @ISA = qw(LicenseEvent);

our @property_list = (
   ['licenseServer', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseServer)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseExpiredEvent;
our @ISA = qw(Event);

our @property_list = (
   ['feature', 'LicenseFeatureInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(feature)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationWarningEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationErrorEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationHostWarningEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
   ['dstHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(dstHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationHostErrorEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
   ['dstHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(dstHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationResourceWarningEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
   ['dstPool', 'ResourcePoolEventArgument', undef],
   ['dstHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(dstPool dstHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationResourceErrorEvent;
our @ISA = qw(MigrationEvent);

our @property_list = (
   ['dstPool', 'ResourcePoolEventArgument', undef],
   ['dstHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(dstPool dstHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterEvent;
our @ISA = qw(Event);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasEnabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasDisabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasAdmissionControlDisabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasAdmissionControlEnabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasHostFailedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
   ['failedHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(failedHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasHostIsolatedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
   ['isolatedHost', 'HostEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(isolatedHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasAgentUnavailableEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasAgentFoundEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientFailoverResourcesEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FailoverLevelRestored;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterOvercommittedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterStatusChangedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
   ['oldStatus', undef, undef],
   ['newStatus', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(oldStatus newStatus)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterCreatedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
   ['parent', 'FolderEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(parent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterDestroyedEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DrsEnabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
   ['behavior', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(behavior)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DrsDisabledEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ClusterReconfiguredEvent;
our @ISA = qw(ClusterEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolEvent;
our @ISA = qw(Event);

our @property_list = (
   ['resourcePool', 'ResourcePoolEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(resourcePool)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolCreatedEvent;
our @ISA = qw(ResourcePoolEvent);

our @property_list = (
   ['parent', 'ResourcePoolEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(parent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolDestroyedEvent;
our @ISA = qw(ResourcePoolEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolMovedEvent;
our @ISA = qw(ResourcePoolEvent);

our @property_list = (
   ['oldParent', 'ResourcePoolEventArgument', undef],
   ['newParent', 'ResourcePoolEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(oldParent newParent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolReconfiguredEvent;
our @ISA = qw(ResourcePoolEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourceViolatedEvent;
our @ISA = qw(ResourcePoolEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmResourcePoolMovedEvent;
our @ISA = qw(VmEvent);

our @property_list = (
   ['oldParent', 'ResourcePoolEventArgument', undef],
   ['newParent', 'ResourcePoolEventArgument', undef],
);

use Class::MethodMaker  [ scalar => [qw(oldParent newParent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateUpgradeEvent;
our @ISA = qw(Event);

our @property_list = (
   ['legacyTemplate', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(legacyTemplate)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateBeingUpgradedEvent;
our @ISA = qw(TemplateUpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateUpgradeFailedEvent;
our @ISA = qw(TemplateUpgradeEvent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateUpgradedEvent;
our @ISA = qw(TemplateUpgradeEvent);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventArgument;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RoleEventArgument;
our @ISA = qw(EventArgument);

our @property_list = (
   ['roleId', undef, undef],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(roleId name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EntityEventArgument;
our @ISA = qw(EventArgument);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ManagedEntityEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FolderEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['folder', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(folder)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatacenterEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['datacenter', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(datacenter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ComputeResourceEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['computeResource', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(computeResource)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourcePoolEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['resourcePool', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(resourcePool)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(host)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['vm', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(vm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlarmEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['alarm', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(alarm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskEventArgument;
our @ISA = qw(EntityEventArgument);

our @property_list = (
   ['scheduledTask', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(scheduledTask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventDescriptionEventDetail;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['category', undef, undef],
   ['formatOnDatacenter', undef, undef],
   ['formatOnComputeResource', undef, undef],
   ['formatOnHost', undef, undef],
   ['formatOnVm', undef, undef],
   ['fullFormat', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key category formatOnDatacenter formatOnComputeResource formatOnHost formatOnVm fullFormat)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfEventDescriptionEventDetail;
our @ISA = qw(ComplexType);

our @property_list = (
   ['EventDescriptionEventDetail', 'EventDescriptionEventDetail', 1],
);

use Class::MethodMaker  [ scalar => [qw(EventDescriptionEventDetail)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['category', 'ElementDescription', 1],
   ['eventInfo', 'EventDescriptionEventDetail', 1],
);

use Class::MethodMaker  [ scalar => [qw(category eventInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventFilterSpecByEntity;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['recursion', 'EventFilterSpecRecursionOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity recursion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventFilterSpecByTime;
our @ISA = qw(DynamicData);

our @property_list = (
   ['beginTime', undef, undef],
   ['endTime', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(beginTime endTime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventFilterSpecByUsername;
our @ISA = qw(DynamicData);

our @property_list = (
   ['systemUser', undef, undef],
   ['userList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(systemUser userList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package EventFilterSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'EventFilterSpecByEntity', undef],
   ['time', 'EventFilterSpecByTime', undef],
   ['userName', 'EventFilterSpecByUsername', undef],
   ['eventChainId', undef, undef],
   ['alarm', 'ManagedObjectReference', undef],
   ['scheduledTask', 'ManagedObjectReference', undef],
   ['disableFullMessage', undef, undef],
   ['category', undef, 1],
   ['type', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(entity time userName eventChainId alarm scheduledTask disableFullMessage category type)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AffinityConfigured;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['configuredAffinity', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(configuredAffinity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AgentInstallFailed;
our @ISA = qw(HostConnectFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlreadyBeingManaged;
our @ISA = qw(HostConnectFault);

our @property_list = (
   ['ipAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlreadyConnected;
our @ISA = qw(HostConnectFault);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlreadyExists;
our @ISA = qw(VimFault);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AlreadyUpgraded;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ApplicationQuiesceFault;
our @ISA = qw(SnapshotFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AuthMinimumAdminPermission;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessFile;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessLocalSource;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessNetwork;
our @ISA = qw(CannotAccessVmDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessVmComponent;
our @ISA = qw(VmConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessVmConfig;
our @ISA = qw(CannotAccessVmComponent);

our @property_list = (
   ['reason', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessVmDevice;
our @ISA = qw(CannotAccessVmComponent);

our @property_list = (
   ['device', undef, undef],
   ['backing', undef, undef],
   ['connected', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device backing connected)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotAccessVmDisk;
our @ISA = qw(CannotAccessVmDevice);

our @property_list = (
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotDecryptPasswords;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotDeleteFile;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CannotModifyConfigCpuRequirements;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ConcurrentAccess;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CpuCompatibilityUnknown;
our @ISA = qw(CpuIncompatible);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CpuIncompatible;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
   ['level', undef, undef],
   ['registerName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(level registerName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DasConfigFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatabaseError;
our @ISA = qw(RuntimeFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatacenterMismatchArgument;
our @ISA = qw(DynamicData);

our @property_list = (
   ['entity', 'ManagedObjectReference', undef],
   ['inputDatacenter', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(entity inputDatacenter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfDatacenterMismatchArgument;
our @ISA = qw(ComplexType);

our @property_list = (
   ['DatacenterMismatchArgument', 'DatacenterMismatchArgument', 1],
);

use Class::MethodMaker  [ scalar => [qw(DatacenterMismatchArgument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatacenterMismatch;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['invalidArgument', 'DatacenterMismatchArgument', 1],
   ['expectedDatacenter', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(invalidArgument expectedDatacenter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreNotWritableOnHost;
our @ISA = qw(InvalidDatastore);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(host)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DestinationSwitchFull;
our @ISA = qw(CannotAccessNetwork);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DeviceNotFound;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DeviceNotSupported;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
   ['device', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DisallowedDiskModeChange;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DisallowedMigrationDeviceAttached;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DiskNotSupported;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
   ['disk', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(disk)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DuplicateName;
our @ISA = qw(VimFault);

our @property_list = (
   ['name', undef, undef],
   ['object', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(name object)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileAlreadyExists;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileFault;
our @ISA = qw(VimFault);

our @property_list = (
   ['file', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(file)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileLocked;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileNotFound;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileNotWritable;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FilesystemQuiesceFault;
our @ISA = qw(SnapshotFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GenericVmConfigFault;
our @ISA = qw(VmConfigFault);

our @property_list = (
   ['reason', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(reason)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConfigFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IDEDiskNotSupported;
our @ISA = qw(DiskNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InaccessibleDatastore;
our @ISA = qw(InvalidDatastore);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IncompatibleSetting;
our @ISA = qw(InvalidArgument);

our @property_list = (
   ['conflictingProperty', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(conflictingProperty)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IncorrectFileType;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientCpuResourcesFault;
our @ISA = qw(InsufficientResourcesFault);

our @property_list = (
   ['unreserved', undef, undef],
   ['requested', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(unreserved requested)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientFailoverResourcesFault;
our @ISA = qw(InsufficientResourcesFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientHostCapacityFault;
our @ISA = qw(InsufficientResourcesFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientMemoryResourcesFault;
our @ISA = qw(InsufficientResourcesFault);

our @property_list = (
   ['unreserved', undef, undef],
   ['requested', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(unreserved requested)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InsufficientResourcesFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidController;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
   ['controllerKey', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(controllerKey)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDatastore;
our @ISA = qw(VimFault);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDatastorePath;
our @ISA = qw(InvalidDatastore);

our @property_list = (
   ['datastorePath', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastorePath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDeviceBacking;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDeviceOperation;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
   ['badOp', 'VirtualDeviceConfigSpecOperation', undef],
   ['badFileOp', 'VirtualDeviceConfigSpecFileOperation', undef],
);

use Class::MethodMaker  [ scalar => [qw(badOp badFileOp)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDeviceSpec;
our @ISA = qw(InvalidVmConfig);

our @property_list = (
   ['deviceIndex', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(deviceIndex)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidDiskFormat;
our @ISA = qw(InvalidFormat);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidFolder;
our @ISA = qw(VimFault);

our @property_list = (
   ['target', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(target)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidFormat;
our @ISA = qw(VmConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidLicense;
our @ISA = qw(VimFault);

our @property_list = (
   ['licenseContent', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseContent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidLocale;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidLogin;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidName;
our @ISA = qw(VimFault);

our @property_list = (
   ['name', undef, undef],
   ['entity', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(name entity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidPowerState;
our @ISA = qw(InvalidState);

our @property_list = (
   ['requestedState', 'VirtualMachinePowerState', undef],
   ['existingState', 'VirtualMachinePowerState', undef],
);

use Class::MethodMaker  [ scalar => [qw(requestedState existingState)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidResourcePoolStructureFault;
our @ISA = qw(InsufficientResourcesFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidSnapshotFormat;
our @ISA = qw(InvalidFormat);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidState;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package InvalidVmConfig;
our @ISA = qw(VmConfigFault);

our @property_list = (
   ['property', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(property)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IpHostnameGeneratorError;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LegacyNetworkInterfaceInUse;
our @ISA = qw(CannotAccessNetwork);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LicenseServerUnavailable;
our @ISA = qw(VimFault);

our @property_list = (
   ['licenseServer', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(licenseServer)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LinuxVolumeNotClean;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LogBundlingFailed;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MemorySnapshotOnIndependentDisk;
our @ISA = qw(SnapshotFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MigrationFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MismatchedNetworkPolicies;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['device', undef, undef],
   ['backing', undef, undef],
   ['connected', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device backing connected)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MismatchedVMotionNetworkNames;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['sourceNetwork', undef, undef],
   ['destNetwork', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(sourceNetwork destNetwork)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MissingController;
our @ISA = qw(InvalidDeviceSpec);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MissingLinuxCustResources;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MissingWindowsCustResources;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MountError;
our @ISA = qw(CustomizationFault);

our @property_list = (
   ['vm', 'ManagedObjectReference', undef],
   ['diskIndex', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vm diskIndex)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MultipleSnapshotsNotSupported;
our @ISA = qw(SnapshotFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NetworkCopyFault;
our @ISA = qw(FileFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoActiveHostInCluster;
our @ISA = qw(InvalidState);

our @property_list = (
   ['computeResource', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(computeResource)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoDiskFound;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoDiskSpace;
our @ISA = qw(FileFault);

our @property_list = (
   ['datastore', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoDisksToCustomize;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoGateway;
our @ISA = qw(HostConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoGuestHeartbeat;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoHost;
our @ISA = qw(HostConnectFault);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoPermission;
our @ISA = qw(SecurityError);

our @property_list = (
   ['object', 'ManagedObjectReference', undef],
   ['privilegeId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(object privilegeId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoPermissionOnHost;
our @ISA = qw(HostConnectFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NoVirtualNic;
our @ISA = qw(HostConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotEnoughCpus;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
   ['numCpuDest', undef, undef],
   ['numCpuVm', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(numCpuDest numCpuVm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotEnoughLogicalCpus;
our @ISA = qw(NotEnoughCpus);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotFound;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NotSupportedHost;
our @ISA = qw(HostConnectFault);

our @property_list = (
   ['productName', undef, undef],
   ['productVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(productName productVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NumVirtualCpusNotSupported;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
   ['maxSupportedVcpusDest', undef, undef],
   ['numCpuVm', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(maxSupportedVcpusDest numCpuVm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OutOfBounds;
our @ISA = qw(VimFault);

our @property_list = (
   ['argumentName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(argumentName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysCompatRDMNotSupported;
our @ISA = qw(RDMNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PlatformConfigFault;
our @ISA = qw(HostConfigFault);

our @property_list = (
   ['text', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(text)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RDMNotPreserved;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['device', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RDMNotSupported;
our @ISA = qw(DeviceNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RDMPointsToInaccessibleDisk;
our @ISA = qw(CannotAccessVmDisk);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RawDiskNotSupported;
our @ISA = qw(DeviceNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ReadOnlyDisksWithLegacyDestination;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['roDiskCount', undef, undef],
   ['timeoutDanger', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(roDiskCount timeoutDanger)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RemoteDeviceNotSupported;
our @ISA = qw(DeviceNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RemoveFailed;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ResourceInUse;
our @ISA = qw(VimFault);

our @property_list = (
   ['type', undef, undef],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(type name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RuleViolation;
our @ISA = qw(VmConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SharedBusControllerNotSupported;
our @ISA = qw(DeviceNotSupported);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SnapshotCopyNotSupported;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SnapshotFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SnapshotIncompatibleDeviceInVm;
our @ISA = qw(SnapshotFault);

our @property_list = (
   ['fault', 'LocalizedMethodFault', undef],
);

use Class::MethodMaker  [ scalar => [qw(fault)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SnapshotRevertIssue;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['snapshotName', undef, undef],
   ['event', 'Event', 1],
   ['errors', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(snapshotName event errors)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package SuspendedRelocateNotSupported;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskInProgress;
our @ISA = qw(VimFault);

our @property_list = (
   ['task', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(task)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package Timedout;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TooManyDevices;
our @ISA = qw(InvalidVmConfig);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TooManyHosts;
our @ISA = qw(HostConnectFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TooManySnapshotLevels;
our @ISA = qw(SnapshotFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ToolsUnavailable;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UncommittedUndoableDisk;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UncustomizableGuest;
our @ISA = qw(CustomizationFault);

our @property_list = (
   ['uncustomizableGuestOS', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(uncustomizableGuestOS)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UnexpectedCustomizationFault;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UnsupportedDatastore;
our @ISA = qw(VmConfigFault);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UnsupportedGuest;
our @ISA = qw(InvalidVmConfig);

our @property_list = (
   ['unsupportedGuestOS', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(unsupportedGuestOS)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UnsupportedVmxLocation;
our @ISA = qw(VmConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package UserNotFound;
our @ISA = qw(VimFault);

our @property_list = (
   ['principal', undef, undef],
   ['unresolved', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(principal unresolved)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMOnVirtualIntranet;
our @ISA = qw(CannotAccessNetwork);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionInterfaceIssue;
our @ISA = qw(MigrationFault);

our @property_list = (
   ['atSourceHost', undef, undef],
   ['failedHost', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(atSourceHost failedHost)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionLinkCapacityLow;
our @ISA = qw(VMotionInterfaceIssue);

our @property_list = (
   ['network', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionLinkDown;
our @ISA = qw(VMotionInterfaceIssue);

our @property_list = (
   ['network', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionNotConfigured;
our @ISA = qw(VMotionInterfaceIssue);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionNotLicensed;
our @ISA = qw(VMotionInterfaceIssue);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionNotSupported;
our @ISA = qw(VMotionInterfaceIssue);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VMotionProtocolIncompatible;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VimFault;
our @ISA = qw(MethodFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualHardwareCompatibilityIssue;
our @ISA = qw(VmConfigFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualHardwareVersionNotSupported;
our @ISA = qw(VirtualHardwareCompatibilityIssue);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmLimitLicense;
our @ISA = qw(NotEnoughLicenses);

our @property_list = (
   ['limit', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(limit)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmToolsUpgradeFault;
our @ISA = qw(VimFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VolumeEditorError;
our @ISA = qw(CustomizationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package WillModifyConfigCpuRequirements;
our @ISA = qw(MigrationFault);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AutoStartDefaults;
our @ISA = qw(DynamicData);

our @property_list = (
   ['enabled', undef, undef],
   ['startDelay', undef, undef],
   ['stopDelay', undef, undef],
   ['waitForHeartbeat', undef, undef],
   ['stopAction', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(enabled startDelay stopDelay waitForHeartbeat stopAction)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AutoStartPowerInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', 'ManagedObjectReference', undef],
   ['startOrder', undef, undef],
   ['startDelay', undef, undef],
   ['waitForHeartbeat', 'AutoStartWaitHeartbeatSetting', undef],
   ['startAction', undef, undef],
   ['stopDelay', undef, undef],
   ['stopAction', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key startOrder startDelay waitForHeartbeat startAction stopDelay stopAction)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAutoStartPowerInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['AutoStartPowerInfo', 'AutoStartPowerInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(AutoStartPowerInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostAutoStartManagerConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['defaults', 'AutoStartDefaults', undef],
   ['powerInfo', 'AutoStartPowerInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(defaults powerInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCapability;
our @ISA = qw(DynamicData);

our @property_list = (
   ['recursiveResourcePoolsSupported', undef, undef],
   ['rebootSupported', undef, undef],
   ['shutdownSupported', undef, undef],
   ['vmotionSupported', undef, undef],
   ['maxSupportedVMs', undef, undef],
   ['maxRunningVMs', undef, undef],
   ['maxSupportedVcpus', undef, undef],
   ['datastorePrincipalSupported', undef, undef],
   ['sanSupported', undef, undef],
   ['nfsSupported', undef, undef],
   ['iscsiSupported', undef, undef],
   ['vlanTaggingSupported', undef, undef],
   ['nicTeamingSupported', undef, undef],
   ['highGuestMemSupported', undef, undef],
   ['maintenanceModeSupported', undef, undef],
   ['suspendedRelocateSupported', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(recursiveResourcePoolsSupported rebootSupported shutdownSupported vmotionSupported maxSupportedVMs maxRunningVMs maxSupportedVcpus datastorePrincipalSupported sanSupported nfsSupported iscsiSupported vlanTaggingSupported nicTeamingSupported highGuestMemSupported maintenanceModeSupported suspendedRelocateSupported)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConfigChange;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
   ['product', 'AboutInfo', undef],
   ['hyperThread', 'HostHyperThreadScheduleInfo', undef],
   ['consoleReservation', 'ServiceConsoleReservationInfo', undef],
   ['storageDevice', 'HostStorageDeviceInfo', undef],
   ['fileSystemVolume', 'HostFileSystemVolumeInfo', undef],
   ['network', 'HostNetworkInfo', undef],
   ['vmotion', 'HostVMotionInfo', undef],
   ['capabilities', 'HostNetCapabilities', undef],
   ['offloadCapabilities', 'HostNetOffloadCapabilities', undef],
   ['service', 'HostServiceInfo', undef],
   ['firewall', 'HostFirewallInfo', undef],
   ['autoStart', 'HostAutoStartManagerConfig', undef],
   ['activeDiagnosticPartition', 'HostDiagnosticPartition', undef],
   ['option', 'OptionValue', 1],
   ['optionDef', 'OptionDef', 1],
   ['datastorePrincipal', undef, undef],
   ['systemResources', 'HostSystemResourceInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(host product hyperThread consoleReservation storageDevice fileSystemVolume network vmotion capabilities offloadCapabilities service firewall autoStart activeDiagnosticPartition option optionDef datastorePrincipal systemResources)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConfigManager;
our @ISA = qw(DynamicData);

our @property_list = (
   ['cpuScheduler', 'ManagedObjectReference', undef],
   ['datastoreSystem', 'ManagedObjectReference', undef],
   ['memoryManager', 'ManagedObjectReference', undef],
   ['storageSystem', 'ManagedObjectReference', undef],
   ['networkSystem', 'ManagedObjectReference', undef],
   ['vmotionSystem', 'ManagedObjectReference', undef],
   ['serviceSystem', 'ManagedObjectReference', undef],
   ['firewallSystem', 'ManagedObjectReference', undef],
   ['advancedOption', 'ManagedObjectReference', undef],
   ['diagnosticSystem', 'ManagedObjectReference', undef],
   ['autoStartManager', 'ManagedObjectReference', undef],
   ['snmpSystem', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(cpuScheduler datastoreSystem memoryManager storageSystem networkSystem vmotionSystem serviceSystem firewallSystem advancedOption diagnosticSystem autoStartManager snmpSystem)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectInfoNetworkInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['summary', 'NetworkSummary', undef],
);

use Class::MethodMaker  [ scalar => [qw(summary)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostConnectInfoNetworkInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostConnectInfoNetworkInfo', 'HostConnectInfoNetworkInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostConnectInfoNetworkInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNewNetworkConnectInfo;
our @ISA = qw(HostConnectInfoNetworkInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDatastoreConnectInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['summary', 'DatastoreSummary', undef],
);

use Class::MethodMaker  [ scalar => [qw(summary)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDatastoreConnectInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDatastoreConnectInfo', 'HostDatastoreConnectInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDatastoreConnectInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDatastoreExistsConnectInfo;
our @ISA = qw(HostDatastoreConnectInfo);

our @property_list = (
   ['newDatastoreName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(newDatastoreName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDatastoreNameConflictConnectInfo;
our @ISA = qw(HostDatastoreConnectInfo);

our @property_list = (
   ['newDatastoreName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(newDatastoreName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['serverIp', undef, undef],
   ['host', 'HostListSummary', undef],
   ['vm', 'VirtualMachineSummary', 1],
   ['vimAccountNameRequired', undef, undef],
   ['clusterSupported', undef, undef],
   ['network', 'HostConnectInfoNetworkInfo', 1],
   ['datastore', 'HostDatastoreConnectInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(serverIp host vm vimAccountNameRequired clusterSupported network datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConnectSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['hostName', undef, undef],
   ['port', undef, undef],
   ['userName', undef, undef],
   ['password', undef, undef],
   ['vmFolder', 'ManagedObjectReference', undef],
   ['force', undef, undef],
   ['vimAccountName', undef, undef],
   ['vimAccountPassword', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hostName port userName password vmFolder force vimAccountName vimAccountPassword)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCpuIdInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['level', undef, undef],
   ['vendor', undef, undef],
   ['eax', undef, undef],
   ['ebx', undef, undef],
   ['ecx', undef, undef],
   ['edx', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(level vendor eax ebx ecx edx)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostCpuIdInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostCpuIdInfo', 'HostCpuIdInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostCpuIdInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostHyperThreadScheduleInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['available', undef, undef],
   ['active', undef, undef],
   ['config', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(available active config)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileQueryFlags;
our @ISA = qw(DynamicData);

our @property_list = (
   ['fileType', undef, undef],
   ['fileSize', undef, undef],
   ['modification', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(fileType fileSize modification)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['path', undef, undef],
   ['fileSize', undef, undef],
   ['modification', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(path fileSize modification)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfFileInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['FileInfo', 'FileInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(FileInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FileQuery;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfFileQuery;
our @ISA = qw(ComplexType);

our @property_list = (
   ['FileQuery', 'FileQuery', 1],
);

use Class::MethodMaker  [ scalar => [qw(FileQuery)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigFileQueryFilter;
our @ISA = qw(DynamicData);

our @property_list = (
   ['matchConfigVersion', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(matchConfigVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigFileQueryFlags;
our @ISA = qw(DynamicData);

our @property_list = (
   ['configVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(configVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
   ['filter', 'VmConfigFileQueryFilter', undef],
   ['details', 'VmConfigFileQueryFlags', undef],
);

use Class::MethodMaker  [ scalar => [qw(filter details)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateConfigFileQuery;
our @ISA = qw(VmConfigFileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiskFileQueryFilter;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskType', undef, 1],
   ['matchHardwareVersion', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(diskType matchHardwareVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiskFileQueryFlags;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskType', undef, undef],
   ['capacityKb', undef, undef],
   ['hardwareVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskType capacityKb hardwareVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiskFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
   ['filter', 'VmDiskFileQueryFilter', undef],
   ['details', 'VmDiskFileQueryFlags', undef],
);

use Class::MethodMaker  [ scalar => [qw(filter details)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FolderFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmSnapshotFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IsoImageFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FloppyImageFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmNvramFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmLogFileQuery;
our @ISA = qw(FileQuery);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmConfigFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
   ['configVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(configVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TemplateConfigFileInfo;
our @ISA = qw(VmConfigFileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmDiskFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
   ['diskType', undef, undef],
   ['capacityKb', undef, undef],
   ['hardwareVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskType capacityKb hardwareVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FolderFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmSnapshotFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IsoImageFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FloppyImageFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmNvramFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmLogFileInfo;
our @ISA = qw(FileInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDatastoreBrowserSearchSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['query', 'FileQuery', 1],
   ['details', 'FileQueryFlags', undef],
   ['searchCaseInsensitive', undef, undef],
   ['matchPattern', undef, 1],
   ['sortFoldersFirst', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(query details searchCaseInsensitive matchPattern sortFoldersFirst)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDatastoreBrowserSearchResults;
our @ISA = qw(DynamicData);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
   ['folderPath', undef, undef],
   ['file', 'FileInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(datastore folderPath file)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDatastoreBrowserSearchResults;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDatastoreBrowserSearchResults', 'HostDatastoreBrowserSearchResults', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDatastoreBrowserSearchResults)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreInfo;
our @ISA = qw(DatastoreInfo);

our @property_list = (
   ['vmfs', 'HostVmfsVolume', undef],
);

use Class::MethodMaker  [ scalar => [qw(vmfs)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package NasDatastoreInfo;
our @ISA = qw(DatastoreInfo);

our @property_list = (
   ['nas', 'HostNasVolume', undef],
);

use Class::MethodMaker  [ scalar => [qw(nas)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LocalDatastoreInfo;
our @ISA = qw(DatastoreInfo);

our @property_list = (
   ['path', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(path)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskUuid', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskUuid)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreCreateSpec;
our @ISA = qw(VmfsDatastoreSpec);

our @property_list = (
   ['partition', 'HostDiskPartitionSpec', undef],
   ['vmfs', 'HostVmfsSpec', undef],
   ['extent', 'HostScsiDiskPartition', 1],
);

use Class::MethodMaker  [ scalar => [qw(partition vmfs extent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreExtendSpec;
our @ISA = qw(VmfsDatastoreSpec);

our @property_list = (
   ['partition', 'HostDiskPartitionSpec', undef],
   ['extent', 'HostScsiDiskPartition', 1],
);

use Class::MethodMaker  [ scalar => [qw(partition extent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreBaseOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['layout', 'HostDiskPartitionLayout', undef],
);

use Class::MethodMaker  [ scalar => [qw(layout)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreSingleExtentOption;
our @ISA = qw(VmfsDatastoreBaseOption);

our @property_list = (
   ['vmfsExtent', 'HostDiskPartitionBlockRange', undef],
);

use Class::MethodMaker  [ scalar => [qw(vmfsExtent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreAllExtentOption;
our @ISA = qw(VmfsDatastoreSingleExtentOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreMultipleExtentOption;
our @ISA = qw(VmfsDatastoreBaseOption);

our @property_list = (
   ['vmfsExtent', 'HostDiskPartitionBlockRange', 1],
);

use Class::MethodMaker  [ scalar => [qw(vmfsExtent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VmfsDatastoreOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['info', 'VmfsDatastoreBaseOption', undef],
   ['spec', 'VmfsDatastoreSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(info spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVmfsDatastoreOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VmfsDatastoreOption', 'VmfsDatastoreOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(VmfsDatastoreOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDevice;
our @ISA = qw(DynamicData);

our @property_list = (
   ['deviceName', undef, undef],
   ['deviceType', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(deviceName deviceType)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiagnosticPartitionCreateOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['storageType', undef, undef],
   ['diagnosticType', undef, undef],
   ['disk', 'HostScsiDisk', undef],
);

use Class::MethodMaker  [ scalar => [qw(storageType diagnosticType disk)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiagnosticPartitionCreateOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiagnosticPartitionCreateOption', 'HostDiagnosticPartitionCreateOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiagnosticPartitionCreateOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiagnosticPartitionCreateSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['storageType', undef, undef],
   ['diagnosticType', undef, undef],
   ['id', 'HostScsiDiskPartition', undef],
   ['partition', 'HostDiskPartitionSpec', undef],
   ['active', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(storageType diagnosticType id partition active)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiagnosticPartitionCreateDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['layout', 'HostDiskPartitionLayout', undef],
   ['diskUuid', undef, undef],
   ['spec', 'HostDiagnosticPartitionCreateSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(layout diskUuid spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiagnosticPartition;
our @ISA = qw(DynamicData);

our @property_list = (
   ['storageType', undef, undef],
   ['diagnosticType', undef, undef],
   ['slots', undef, undef],
   ['id', 'HostScsiDiskPartition', undef],
);

use Class::MethodMaker  [ scalar => [qw(storageType diagnosticType slots id)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiagnosticPartition;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiagnosticPartition', 'HostDiagnosticPartition', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiagnosticPartition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskBlockInfoExtent;
our @ISA = qw(DynamicData);

our @property_list = (
   ['logicalStart', undef, undef],
   ['physicalStart', undef, undef],
   ['length', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(logicalStart physicalStart length)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskBlockInfoExtent;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskBlockInfoExtent', 'HostDiskBlockInfoExtent', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskBlockInfoExtent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskBlockInfoMapping;
our @ISA = qw(DynamicData);

our @property_list = (
   ['element', undef, undef],
   ['extent', 'HostDiskBlockInfoExtent', 1],
);

use Class::MethodMaker  [ scalar => [qw(element extent)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskBlockInfoMapping;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskBlockInfoMapping', 'HostDiskBlockInfoMapping', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskBlockInfoMapping)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskBlockInfoScsiMapping;
our @ISA = qw(HostDiskBlockInfoMapping);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskBlockInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['size', undef, undef],
   ['granularity', undef, undef],
   ['minBlockSize', undef, undef],
   ['map', 'HostDiskBlockInfoMapping', 1],
);

use Class::MethodMaker  [ scalar => [qw(size granularity minBlockSize map)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskDimensionsChs;
our @ISA = qw(DynamicData);

our @property_list = (
   ['cylinder', undef, undef],
   ['head', undef, undef],
   ['sector', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(cylinder head sector)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskDimensionsLba;
our @ISA = qw(DynamicData);

our @property_list = (
   ['blockSize', undef, undef],
   ['block', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(blockSize block)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskDimensions;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskManagerLeaseInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['lease', 'ManagedObjectReference', undef],
   ['ddbOption', 'OptionValue', 1],
   ['blockInfo', 'HostDiskBlockInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(lease ddbOption blockInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskPartitionAttributes;
our @ISA = qw(DynamicData);

our @property_list = (
   ['partition', undef, undef],
   ['startSector', undef, undef],
   ['endSector', undef, undef],
   ['type', undef, undef],
   ['logical', undef, undef],
   ['attributes', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(partition startSector endSector type logical attributes)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskPartitionAttributes;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskPartitionAttributes', 'HostDiskPartitionAttributes', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskPartitionAttributes)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskPartitionBlockRange;
our @ISA = qw(DynamicData);

our @property_list = (
   ['partition', undef, undef],
   ['type', undef, undef],
   ['start', 'HostDiskDimensionsLba', undef],
   ['end', 'HostDiskDimensionsLba', undef],
);

use Class::MethodMaker  [ scalar => [qw(partition type start end)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskPartitionBlockRange;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskPartitionBlockRange', 'HostDiskPartitionBlockRange', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskPartitionBlockRange)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskPartitionSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['chs', 'HostDiskDimensionsChs', undef],
   ['totalSectors', undef, undef],
   ['partition', 'HostDiskPartitionAttributes', 1],
);

use Class::MethodMaker  [ scalar => [qw(chs totalSectors partition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskPartitionLayout;
our @ISA = qw(DynamicData);

our @property_list = (
   ['total', 'HostDiskDimensionsLba', undef],
   ['partition', 'HostDiskPartitionBlockRange', 1],
);

use Class::MethodMaker  [ scalar => [qw(total partition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskPartitionInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['deviceName', undef, undef],
   ['spec', 'HostDiskPartitionSpec', undef],
   ['layout', 'HostDiskPartitionLayout', undef],
);

use Class::MethodMaker  [ scalar => [qw(deviceName spec layout)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskPartitionInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskPartitionInfo', 'HostDiskPartitionInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskPartitionInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDnsConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dhcp', undef, undef],
   ['virtualNicDevice', undef, undef],
   ['hostName', undef, undef],
   ['domainName', undef, undef],
   ['address', undef, 1],
   ['searchDomain', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(dhcp virtualNicDevice hostName domainName address searchDomain)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ModeInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['browse', undef, undef],
   ['read', undef, undef],
   ['modify', undef, undef],
   ['use', undef, undef],
   ['admin', undef, undef],
   ['full', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(browse read modify use admin full)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFileAccess;
our @ISA = qw(DynamicData);

our @property_list = (
   ['who', undef, undef],
   ['what', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(who what)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFileSystemVolumeInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['volumeTypeList', undef, 1],
   ['mountInfo', 'HostFileSystemMountInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(volumeTypeList mountInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFileSystemMountInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['mountInfo', 'HostMountInfo', undef],
   ['volume', 'HostFileSystemVolume', undef],
);

use Class::MethodMaker  [ scalar => [qw(mountInfo volume)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostFileSystemMountInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostFileSystemMountInfo', 'HostFileSystemMountInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostFileSystemMountInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFileSystemVolume;
our @ISA = qw(DynamicData);

our @property_list = (
   ['type', undef, undef],
   ['name', undef, undef],
   ['capacity', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(type name capacity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNasVolumeSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['remoteHost', undef, undef],
   ['remotePath', undef, undef],
   ['localPath', undef, undef],
   ['accessMode', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(remoteHost remotePath localPath accessMode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNasVolume;
our @ISA = qw(HostFileSystemVolume);

our @property_list = (
   ['remoteHost', undef, undef],
   ['remotePath', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(remoteHost remotePath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostLocalFileSystemVolumeSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['device', undef, undef],
   ['localPath', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device localPath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostLocalFileSystemVolume;
our @ISA = qw(HostFileSystemVolume);

our @property_list = (
   ['device', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFirewallDefaultPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['incomingBlocked', undef, undef],
   ['outgoingBlocked', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(incomingBlocked outgoingBlocked)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFirewallInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['defaultPolicy', 'HostFirewallDefaultPolicy', undef],
   ['ruleset', 'HostFirewallRuleset', 1],
);

use Class::MethodMaker  [ scalar => [qw(defaultPolicy ruleset)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostHardwareInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['systemInfo', 'HostSystemInfo', undef],
   ['cpuInfo', 'HostCpuInfo', undef],
   ['cpuPkg', 'HostCpuPackage', 1],
   ['memorySize', undef, undef],
   ['numaInfo', 'HostNumaInfo', undef],
   ['pciDevice', 'HostPciDevice', 1],
   ['cpuFeature', 'HostCpuIdInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(systemInfo cpuInfo cpuPkg memorySize numaInfo pciDevice cpuFeature)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostSystemInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vendor', undef, undef],
   ['model', undef, undef],
   ['uuid', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vendor model uuid)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCpuInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['numCpuPackages', undef, undef],
   ['numCpuCores', undef, undef],
   ['numCpuThreads', undef, undef],
   ['hz', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(numCpuPackages numCpuCores numCpuThreads hz)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostCpuPackage;
our @ISA = qw(DynamicData);

our @property_list = (
   ['index', undef, undef],
   ['vendor', undef, undef],
   ['hz', undef, undef],
   ['busHz', undef, undef],
   ['description', undef, undef],
   ['threadId', undef, 1],
   ['cpuFeature', 'HostCpuIdInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(index vendor hz busHz description threadId cpuFeature)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostCpuPackage;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostCpuPackage', 'HostCpuPackage', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostCpuPackage)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNumaInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['type', undef, undef],
   ['numNodes', undef, undef],
   ['numaNode', 'HostNumaNode', 1],
);

use Class::MethodMaker  [ scalar => [qw(type numNodes numaNode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNumaNode;
our @ISA = qw(DynamicData);

our @property_list = (
   ['typeId', undef, undef],
   ['cpuID', undef, 1],
   ['memoryRangeBegin', undef, undef],
   ['memoryRangeLength', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(typeId cpuID memoryRangeBegin memoryRangeLength)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostNumaNode;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostNumaNode', 'HostNumaNode', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostNumaNode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostHostBusAdapter;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['device', undef, undef],
   ['bus', undef, undef],
   ['status', undef, undef],
   ['model', undef, undef],
   ['driver', undef, undef],
   ['pci', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key device bus status model driver pci)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostHostBusAdapter;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostHostBusAdapter', 'HostHostBusAdapter', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostHostBusAdapter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostParallelScsiHba;
our @ISA = qw(HostHostBusAdapter);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostBlockHba;
our @ISA = qw(HostHostBusAdapter);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFibreChannelHba;
our @ISA = qw(HostHostBusAdapter);

our @property_list = (
   ['portWorldWideName', undef, undef],
   ['nodeWorldWideName', undef, undef],
   ['portType', 'FibreChannelPortType', undef],
   ['speed', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(portWorldWideName nodeWorldWideName portType speed)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaDiscoveryCapabilities;
our @ISA = qw(DynamicData);

our @property_list = (
   ['iSnsDiscoverySettable', undef, undef],
   ['slpDiscoverySettable', undef, undef],
   ['staticTargetDiscoverySettable', undef, undef],
   ['sendTargetsDiscoverySettable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(iSnsDiscoverySettable slpDiscoverySettable staticTargetDiscoverySettable sendTargetsDiscoverySettable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaDiscoveryProperties;
our @ISA = qw(DynamicData);

our @property_list = (
   ['iSnsDiscoveryEnabled', undef, undef],
   ['iSnsDiscoveryMethod', undef, undef],
   ['iSnsHost', undef, undef],
   ['slpDiscoveryEnabled', undef, undef],
   ['slpDiscoveryMethod', undef, undef],
   ['slpHost', undef, undef],
   ['staticTargetDiscoveryEnabled', undef, undef],
   ['sendTargetsDiscoveryEnabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(iSnsDiscoveryEnabled iSnsDiscoveryMethod iSnsHost slpDiscoveryEnabled slpDiscoveryMethod slpHost staticTargetDiscoveryEnabled sendTargetsDiscoveryEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaAuthenticationCapabilities;
our @ISA = qw(DynamicData);

our @property_list = (
   ['chapAuthSettable', undef, undef],
   ['krb5AuthSettable', undef, undef],
   ['srpAuthSettable', undef, undef],
   ['spkmAuthSettable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(chapAuthSettable krb5AuthSettable srpAuthSettable spkmAuthSettable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaAuthenticationProperties;
our @ISA = qw(DynamicData);

our @property_list = (
   ['chapAuthEnabled', undef, undef],
   ['chapName', undef, undef],
   ['chapSecret', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(chapAuthEnabled chapName chapSecret)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaIPCapabilities;
our @ISA = qw(DynamicData);

our @property_list = (
   ['addressSettable', undef, undef],
   ['ipConfigurationMethodSettable', undef, undef],
   ['subnetMaskSettable', undef, undef],
   ['defaultGatewaySettable', undef, undef],
   ['primaryDnsServerAddressSettable', undef, undef],
   ['alternateDnsServerAddressSettable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(addressSettable ipConfigurationMethodSettable subnetMaskSettable defaultGatewaySettable primaryDnsServerAddressSettable alternateDnsServerAddressSettable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaIPProperties;
our @ISA = qw(DynamicData);

our @property_list = (
   ['mac', undef, undef],
   ['address', undef, undef],
   ['dhcpConfigurationEnabled', undef, undef],
   ['subnetMask', undef, undef],
   ['defaultGateway', undef, undef],
   ['primaryDnsServerAddress', undef, undef],
   ['alternateDnsServerAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(mac address dhcpConfigurationEnabled subnetMask defaultGateway primaryDnsServerAddress alternateDnsServerAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaSendTarget;
our @ISA = qw(DynamicData);

our @property_list = (
   ['address', undef, undef],
   ['port', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(address port)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostInternetScsiHbaSendTarget;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostInternetScsiHbaSendTarget', 'HostInternetScsiHbaSendTarget', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostInternetScsiHbaSendTarget)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHbaStaticTarget;
our @ISA = qw(DynamicData);

our @property_list = (
   ['address', undef, undef],
   ['port', undef, undef],
   ['iScsiName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(address port iScsiName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostInternetScsiHbaStaticTarget;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostInternetScsiHbaStaticTarget', 'HostInternetScsiHbaStaticTarget', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostInternetScsiHbaStaticTarget)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiHba;
our @ISA = qw(HostHostBusAdapter);

our @property_list = (
   ['isSoftwareBased', undef, undef],
   ['discoveryCapabilities', 'HostInternetScsiHbaDiscoveryCapabilities', undef],
   ['discoveryProperties', 'HostInternetScsiHbaDiscoveryProperties', undef],
   ['authenticationCapabilities', 'HostInternetScsiHbaAuthenticationCapabilities', undef],
   ['authenticationProperties', 'HostInternetScsiHbaAuthenticationProperties', undef],
   ['ipCapabilities', 'HostInternetScsiHbaIPCapabilities', undef],
   ['ipProperties', 'HostInternetScsiHbaIPProperties', undef],
   ['iScsiName', undef, undef],
   ['iScsiAlias', undef, undef],
   ['configuredSendTarget', 'HostInternetScsiHbaSendTarget', 1],
   ['configuredStaticTarget', 'HostInternetScsiHbaStaticTarget', 1],
   ['maxSpeedMb', undef, undef],
   ['currentSpeedMb', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(isSoftwareBased discoveryCapabilities discoveryProperties authenticationCapabilities authenticationProperties ipCapabilities ipProperties iScsiName iScsiAlias configuredSendTarget configuredStaticTarget maxSpeedMb currentSpeedMb)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostIpConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dhcp', undef, undef],
   ['ipAddress', undef, undef],
   ['subnetMask', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(dhcp ipAddress subnetMask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostIpRouteConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['defaultGateway', undef, undef],
   ['gatewayDevice', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(defaultGateway gatewayDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostAccountSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', undef, undef],
   ['password', undef, undef],
   ['description', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(id password description)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPosixAccountSpec;
our @ISA = qw(HostAccountSpec);

our @property_list = (
   ['posixId', undef, undef],
   ['shellAccess', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(posixId shellAccess)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ServiceConsoleReservationInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['serviceConsoleReservedCfg', undef, undef],
   ['serviceConsoleReserved', undef, undef],
   ['unreserved', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(serviceConsoleReservedCfg serviceConsoleReserved unreserved)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMountInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['path', undef, undef],
   ['accessMode', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(path accessMode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMultipathInfoLogicalUnitPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['policy', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(policy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMultipathInfoFixedLogicalUnitPolicy;
our @ISA = qw(HostMultipathInfoLogicalUnitPolicy);

our @property_list = (
   ['prefer', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(prefer)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMultipathInfoLogicalUnit;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['id', undef, undef],
   ['lun', undef, undef],
   ['path', 'HostMultipathInfoPath', 1],
   ['policy', 'HostMultipathInfoLogicalUnitPolicy', undef],
);

use Class::MethodMaker  [ scalar => [qw(key id lun path policy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostMultipathInfoLogicalUnit;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostMultipathInfoLogicalUnit', 'HostMultipathInfoLogicalUnit', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostMultipathInfoLogicalUnit)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMultipathInfoPath;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['name', undef, undef],
   ['pathState', undef, undef],
   ['adapter', undef, undef],
   ['lun', undef, undef],
   ['transport', 'HostTargetTransport', undef],
);

use Class::MethodMaker  [ scalar => [qw(key name pathState adapter lun transport)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostMultipathInfoPath;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostMultipathInfoPath', 'HostMultipathInfoPath', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostMultipathInfoPath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostMultipathInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['lun', 'HostMultipathInfoLogicalUnit', 1],
);

use Class::MethodMaker  [ scalar => [qw(lun)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetCapabilities;
our @ISA = qw(DynamicData);

our @property_list = (
   ['canSetPhysicalNicLinkSpeed', undef, undef],
   ['supportsNicTeaming', undef, undef],
   ['nicTeamingPolicy', undef, 1],
   ['supportsVlan', undef, undef],
   ['usesServiceConsoleNic', undef, undef],
   ['supportsNetworkHints', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(canSetPhysicalNicLinkSpeed supportsNicTeaming nicTeamingPolicy supportsVlan usesServiceConsoleNic supportsNetworkHints)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetOffloadCapabilities;
our @ISA = qw(DynamicData);

our @property_list = (
   ['csumOffload', undef, undef],
   ['tcpSegmentation', undef, undef],
   ['zeroCopyXmit', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(csumOffload tcpSegmentation zeroCopyXmit)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkConfigResult;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vnicDevice', undef, 1],
   ['consoleVnicDevice', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(vnicDevice consoleVnicDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vswitch', 'HostVirtualSwitchConfig', 1],
   ['portgroup', 'HostPortGroupConfig', 1],
   ['pnic', 'PhysicalNicConfig', 1],
   ['vnic', 'HostVirtualNicConfig', 1],
   ['consoleVnic', 'HostVirtualNicConfig', 1],
   ['dnsConfig', 'HostDnsConfig', undef],
   ['ipRouteConfig', 'HostIpRouteConfig', undef],
   ['consoleIpRouteConfig', 'HostIpRouteConfig', undef],
);

use Class::MethodMaker  [ scalar => [qw(vswitch portgroup pnic vnic consoleVnic dnsConfig ipRouteConfig consoleIpRouteConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vswitch', 'HostVirtualSwitch', 1],
   ['portgroup', 'HostPortGroup', 1],
   ['pnic', 'PhysicalNic', 1],
   ['vnic', 'HostVirtualNic', 1],
   ['consoleVnic', 'HostVirtualNic', 1],
   ['dnsConfig', 'HostDnsConfig', undef],
   ['ipRouteConfig', 'HostIpRouteConfig', undef],
   ['consoleIpRouteConfig', 'HostIpRouteConfig', undef],
);

use Class::MethodMaker  [ scalar => [qw(vswitch portgroup pnic vnic consoleVnic dnsConfig ipRouteConfig consoleIpRouteConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkSecurityPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['allowPromiscuous', undef, undef],
   ['macChanges', undef, undef],
   ['forgedTransmits', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(allowPromiscuous macChanges forgedTransmits)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkTrafficShapingPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['enabled', undef, undef],
   ['averageBandwidth', undef, undef],
   ['peakBandwidth', undef, undef],
   ['burstSize', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(enabled averageBandwidth peakBandwidth burstSize)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNicFailureCriteria;
our @ISA = qw(DynamicData);

our @property_list = (
   ['checkSpeed', undef, undef],
   ['speed', undef, undef],
   ['checkDuplex', undef, undef],
   ['fullDuplex', undef, undef],
   ['checkErrorPercent', undef, undef],
   ['percentage', undef, undef],
   ['checkBeacon', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(checkSpeed speed checkDuplex fullDuplex checkErrorPercent percentage checkBeacon)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNicOrderPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['activeNic', undef, 1],
   ['standbyNic', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(activeNic standbyNic)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNicTeamingPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['policy', undef, undef],
   ['reversePolicy', undef, undef],
   ['notifySwitches', undef, undef],
   ['rollingOrder', undef, undef],
   ['failureCriteria', 'HostNicFailureCriteria', undef],
   ['nicOrder', 'HostNicOrderPolicy', undef],
);

use Class::MethodMaker  [ scalar => [qw(policy reversePolicy notifySwitches rollingOrder failureCriteria nicOrder)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostNetworkPolicy;
our @ISA = qw(DynamicData);

our @property_list = (
   ['security', 'HostNetworkSecurityPolicy', undef],
   ['nicTeaming', 'HostNicTeamingPolicy', undef],
   ['offloadPolicy', 'HostNetOffloadCapabilities', undef],
   ['shapingPolicy', 'HostNetworkTrafficShapingPolicy', undef],
);

use Class::MethodMaker  [ scalar => [qw(security nicTeaming offloadPolicy shapingPolicy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPciDevice;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', undef, undef],
   ['classId', undef, undef],
   ['bus', undef, undef],
   ['slot', undef, undef],
   ['function', undef, undef],
   ['vendorId', undef, undef],
   ['subVendorId', undef, undef],
   ['vendorName', undef, undef],
   ['deviceId', undef, undef],
   ['subDeviceId', undef, undef],
   ['deviceName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(id classId bus slot function vendorId subVendorId vendorName deviceId subDeviceId deviceName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostPciDevice;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostPciDevice', 'HostPciDevice', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostPciDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['ip', 'HostIpConfig', undef],
   ['linkSpeed', 'PhysicalNicLinkInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(ip linkSpeed)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['device', undef, undef],
   ['spec', 'PhysicalNicSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(device spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNicConfig;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNicConfig', 'PhysicalNicConfig', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNicConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicLinkInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['speedMb', undef, undef],
   ['duplex', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(speedMb duplex)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNicLinkInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNicLinkInfo', 'PhysicalNicLinkInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNicLinkInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicHint;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vlanId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vlanId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicIpHint;
our @ISA = qw(PhysicalNicHint);

our @property_list = (
   ['ipSubnet', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipSubnet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNicIpHint;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNicIpHint', 'PhysicalNicIpHint', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNicIpHint)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicNameHint;
our @ISA = qw(PhysicalNicHint);

our @property_list = (
   ['network', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNicNameHint;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNicNameHint', 'PhysicalNicNameHint', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNicNameHint)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNicHintInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['device', undef, undef],
   ['subnet', 'PhysicalNicIpHint', 1],
   ['network', 'PhysicalNicNameHint', 1],
);

use Class::MethodMaker  [ scalar => [qw(device subnet network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNicHintInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNicHintInfo', 'PhysicalNicHintInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNicHintInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package PhysicalNic;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['device', undef, undef],
   ['pci', undef, undef],
   ['driver', undef, undef],
   ['linkSpeed', 'PhysicalNicLinkInfo', undef],
   ['validLinkSpecification', 'PhysicalNicLinkInfo', 1],
   ['spec', 'PhysicalNicSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(key device pci driver linkSpeed validLinkSpecification spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfPhysicalNic;
our @ISA = qw(ComplexType);

our @property_list = (
   ['PhysicalNic', 'PhysicalNic', 1],
);

use Class::MethodMaker  [ scalar => [qw(PhysicalNic)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPortGroupSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['vlanId', undef, undef],
   ['vswitchName', undef, undef],
   ['policy', 'HostNetworkPolicy', undef],
);

use Class::MethodMaker  [ scalar => [qw(name vlanId vswitchName policy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPortGroupConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['changeOperation', undef, undef],
   ['spec', 'HostPortGroupSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(changeOperation spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostPortGroupConfig;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostPortGroupConfig', 'HostPortGroupConfig', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostPortGroupConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPortGroupPort;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['mac', undef, 1],
   ['type', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key mac type)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostPortGroupPort;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostPortGroupPort', 'HostPortGroupPort', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostPortGroupPort)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostPortGroup;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['port', 'HostPortGroupPort', 1],
   ['vswitch', undef, undef],
   ['computedPolicy', 'HostNetworkPolicy', undef],
   ['spec', 'HostPortGroupSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(key port vswitch computedPolicy spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostPortGroup;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostPortGroup', 'HostPortGroup', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostPortGroup)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFirewallRule;
our @ISA = qw(DynamicData);

our @property_list = (
   ['port', undef, undef],
   ['endPort', undef, undef],
   ['direction', 'HostFirewallRuleDirection', undef],
   ['protocol', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(port endPort direction protocol)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostFirewallRule;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostFirewallRule', 'HostFirewallRule', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostFirewallRule)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFirewallRuleset;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['label', undef, undef],
   ['required', undef, undef],
   ['rule', 'HostFirewallRule', 1],
   ['service', undef, undef],
   ['enabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key label required rule service enabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostFirewallRuleset;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostFirewallRuleset', 'HostFirewallRuleset', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostFirewallRuleset)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostRuntimeInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['connectionState', 'HostSystemConnectionState', undef],
   ['inMaintenanceMode', undef, undef],
   ['bootTime', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(connectionState inMaintenanceMode bootTime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiDiskPartition;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskName', undef, undef],
   ['partition', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskName partition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostScsiDiskPartition;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostScsiDiskPartition', 'HostScsiDiskPartition', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostScsiDiskPartition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiDisk;
our @ISA = qw(ScsiLun);

our @property_list = (
   ['capacity', 'HostDiskDimensionsLba', undef],
   ['devicePath', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(capacity devicePath)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostScsiDisk;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostScsiDisk', 'HostScsiDisk', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostScsiDisk)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScsiLunDurableName;
our @ISA = qw(DynamicData);

our @property_list = (
   ['namespace', undef, undef],
   ['namespaceId', undef, undef],
   ['data', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(namespace namespaceId data)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScsiLun;
our @ISA = qw(HostDevice);

our @property_list = (
   ['key', undef, undef],
   ['uuid', undef, undef],
   ['canonicalName', undef, undef],
   ['lunType', undef, undef],
   ['vendor', undef, undef],
   ['model', undef, undef],
   ['revision', undef, undef],
   ['scsiLevel', undef, undef],
   ['serialNumber', undef, undef],
   ['durableName', 'ScsiLunDurableName', undef],
   ['queueDepth', undef, undef],
   ['operationalState', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(key uuid canonicalName lunType vendor model revision scsiLevel serialNumber durableName queueDepth operationalState)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfScsiLun;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ScsiLun', 'ScsiLun', 1],
);

use Class::MethodMaker  [ scalar => [qw(ScsiLun)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiTopologyInterface;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['adapter', undef, undef],
   ['target', 'HostScsiTopologyTarget', 1],
);

use Class::MethodMaker  [ scalar => [qw(key adapter target)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostScsiTopologyInterface;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostScsiTopologyInterface', 'HostScsiTopologyInterface', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostScsiTopologyInterface)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiTopologyTarget;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['target', undef, undef],
   ['lun', 'HostScsiTopologyLun', 1],
   ['transport', 'HostTargetTransport', undef],
);

use Class::MethodMaker  [ scalar => [qw(key target lun transport)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostScsiTopologyTarget;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostScsiTopologyTarget', 'HostScsiTopologyTarget', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostScsiTopologyTarget)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiTopologyLun;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['lun', undef, undef],
   ['scsiLun', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key lun scsiLun)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostScsiTopologyLun;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostScsiTopologyLun', 'HostScsiTopologyLun', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostScsiTopologyLun)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostScsiTopology;
our @ISA = qw(DynamicData);

our @property_list = (
   ['adapter', 'HostScsiTopologyInterface', 1],
);

use Class::MethodMaker  [ scalar => [qw(adapter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostService;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['label', undef, undef],
   ['required', undef, undef],
   ['uninstallable', undef, undef],
   ['running', undef, undef],
   ['ruleset', undef, 1],
   ['policy', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key label required uninstallable running ruleset policy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostService;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostService', 'HostService', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostService)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostServiceInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['service', 'HostService', 1],
);

use Class::MethodMaker  [ scalar => [qw(service)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostSnmpConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['autoStartMasterSnmpAgentEnabled', undef, undef],
   ['startupScript', undef, undef],
   ['configFile', undef, undef],
   ['vmwareSubagentEnabled', undef, undef],
   ['vmwareTrapsEnabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(autoStartMasterSnmpAgentEnabled startupScript configFile vmwareSubagentEnabled vmwareTrapsEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostStorageDeviceInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['hostBusAdapter', 'HostHostBusAdapter', 1],
   ['scsiLun', 'ScsiLun', 1],
   ['scsiTopology', 'HostScsiTopology', undef],
   ['multipathInfo', 'HostMultipathInfo', undef],
   ['softwareInternetScsiEnabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hostBusAdapter scsiLun scsiTopology multipathInfo softwareInternetScsiEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostHardwareSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vendor', undef, undef],
   ['model', undef, undef],
   ['uuid', undef, undef],
   ['memorySize', undef, undef],
   ['cpuModel', undef, undef],
   ['cpuMhz', undef, undef],
   ['numCpuPkgs', undef, undef],
   ['numCpuCores', undef, undef],
   ['numCpuThreads', undef, undef],
   ['numNics', undef, undef],
   ['numHBAs', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vendor model uuid memorySize cpuModel cpuMhz numCpuPkgs numCpuCores numCpuThreads numNics numHBAs)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostListSummaryQuickStats;
our @ISA = qw(DynamicData);

our @property_list = (
   ['overallCpuUsage', undef, undef],
   ['overallMemoryUsage', undef, undef],
   ['distributedCpuFairness', undef, undef],
   ['distributedMemoryFairness', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(overallCpuUsage overallMemoryUsage distributedCpuFairness distributedMemoryFairness)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostConfigSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['port', undef, undef],
   ['product', 'AboutInfo', undef],
   ['vmotionEnabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name port product vmotionEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostListSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
   ['hardware', 'HostHardwareSummary', undef],
   ['runtime', 'HostRuntimeInfo', undef],
   ['config', 'HostConfigSummary', undef],
   ['quickStats', 'HostListSummaryQuickStats', undef],
   ['overallStatus', 'ManagedEntityStatus', undef],
   ['rebootRequired', undef, undef],
   ['customValue', 'CustomFieldValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(host hardware runtime config quickStats overallStatus rebootRequired customValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostSystemResourceInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['config', 'ResourceConfigSpec', undef],
   ['child', 'HostSystemResourceInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(key config child)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostSystemResourceInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostSystemResourceInfo', 'HostSystemResourceInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostSystemResourceInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostTargetTransport;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostParallelScsiTargetTransport;
our @ISA = qw(HostTargetTransport);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostBlockAdapterTargetTransport;
our @ISA = qw(HostTargetTransport);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostFibreChannelTargetTransport;
our @ISA = qw(HostTargetTransport);

our @property_list = (
   ['portWorldWideName', undef, undef],
   ['nodeWorldWideName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(portWorldWideName nodeWorldWideName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostInternetScsiTargetTransport;
our @ISA = qw(HostTargetTransport);

our @property_list = (
   ['iScsiName', undef, undef],
   ['iScsiAlias', undef, undef],
   ['address', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(iScsiName iScsiAlias address)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vmotionNicKey', undef, undef],
   ['enabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vmotionNicKey enabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['netConfig', 'HostVMotionNetConfig', undef],
   ['ipConfig', 'HostIpConfig', undef],
);

use Class::MethodMaker  [ scalar => [qw(netConfig ipConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionManagerSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['migrationId', undef, undef],
   ['srcIp', undef, undef],
   ['dstIp', undef, undef],
   ['srcUuid', undef, undef],
   ['dstUuid', undef, undef],
   ['priority', 'VirtualMachineMovePriority', undef],
);

use Class::MethodMaker  [ scalar => [qw(migrationId srcIp dstIp srcUuid dstUuid priority)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionManagerDestinationState;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dstId', undef, undef],
   ['dstTask', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(dstId dstTask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionManagerReparentSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['busNumber', undef, undef],
   ['unitNumber', undef, undef],
   ['filename', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(busNumber unitNumber filename)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVMotionManagerReparentSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVMotionManagerReparentSpec', 'HostVMotionManagerReparentSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVMotionManagerReparentSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVMotionNetConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['candidateVnic', 'HostVirtualNic', 1],
   ['selectedVnic', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(candidateVnic selectedVnic)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualNicSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['ip', 'HostIpConfig', undef],
   ['mac', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ip mac)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualNicConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['changeOperation', undef, undef],
   ['device', undef, undef],
   ['portgroup', undef, undef],
   ['spec', 'HostVirtualNicSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(changeOperation device portgroup spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVirtualNicConfig;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVirtualNicConfig', 'HostVirtualNicConfig', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVirtualNicConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualNic;
our @ISA = qw(DynamicData);

our @property_list = (
   ['device', undef, undef],
   ['key', undef, undef],
   ['portgroup', undef, undef],
   ['spec', 'HostVirtualNicSpec', undef],
   ['port', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(device key portgroup spec port)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVirtualNic;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVirtualNic', 'HostVirtualNic', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVirtualNic)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchBridge;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchAutoBridge;
our @ISA = qw(HostVirtualSwitchBridge);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchSimpleBridge;
our @ISA = qw(HostVirtualSwitchBridge);

our @property_list = (
   ['nicDevice', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(nicDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchBondBridge;
our @ISA = qw(HostVirtualSwitchBridge);

our @property_list = (
   ['nicDevice', undef, 1],
   ['beacon', 'HostVirtualSwitchBeaconConfig', undef],
);

use Class::MethodMaker  [ scalar => [qw(nicDevice beacon)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchBeaconConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['interval', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(interval)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['numPorts', undef, undef],
   ['bridge', 'HostVirtualSwitchBridge', undef],
   ['policy', 'HostNetworkPolicy', undef],
);

use Class::MethodMaker  [ scalar => [qw(numPorts bridge policy)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitchConfig;
our @ISA = qw(DynamicData);

our @property_list = (
   ['changeOperation', undef, undef],
   ['name', undef, undef],
   ['spec', 'HostVirtualSwitchSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(changeOperation name spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVirtualSwitchConfig;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVirtualSwitchConfig', 'HostVirtualSwitchConfig', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVirtualSwitchConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVirtualSwitch;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['key', undef, undef],
   ['numPorts', undef, undef],
   ['numPortsAvailable', undef, undef],
   ['portgroup', undef, 1],
   ['pnic', undef, 1],
   ['spec', 'HostVirtualSwitchSpec', undef],
);

use Class::MethodMaker  [ scalar => [qw(name key numPorts numPortsAvailable portgroup pnic spec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostVirtualSwitch;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostVirtualSwitch', 'HostVirtualSwitch', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostVirtualSwitch)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVmfsSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['extent', 'HostScsiDiskPartition', undef],
   ['blockSizeMb', undef, undef],
   ['majorVersion', undef, undef],
   ['volumeName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(extent blockSizeMb majorVersion volumeName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostVmfsVolume;
our @ISA = qw(HostFileSystemVolume);

our @property_list = (
   ['blockSizeMb', undef, undef],
   ['maxBlocks', undef, undef],
   ['majorVersion', undef, undef],
   ['version', undef, undef],
   ['uuid', undef, undef],
   ['extent', 'HostScsiDiskPartition', 1],
   ['vmfsUpgradable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(blockSizeMb maxBlocks majorVersion version uuid extent vmfsUpgradable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayUpdateSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['operation', 'ArrayUpdateOperation', undef],
   ['removeKey', 'anyType', undef],
);

use Class::MethodMaker  [ scalar => [qw(operation removeKey)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package BoolOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['supported', undef, undef],
   ['defaultValue', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(supported defaultValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ChoiceOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['choiceInfo', 'ElementDescription', 1],
   ['defaultIndex', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(choiceInfo defaultIndex)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package FloatOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['min', undef, undef],
   ['max', undef, undef],
   ['defaultValue', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(min max defaultValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package IntOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['min', undef, undef],
   ['max', undef, undef],
   ['defaultValue', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(min max defaultValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package LongOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['min', undef, undef],
   ['max', undef, undef],
   ['defaultValue', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(min max defaultValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OptionDef;
our @ISA = qw(ElementDescription);

our @property_list = (
   ['optionType', 'OptionType', undef],
);

use Class::MethodMaker  [ scalar => [qw(optionType)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfOptionDef;
our @ISA = qw(ComplexType);

our @property_list = (
   ['OptionDef', 'OptionDef', 1],
);

use Class::MethodMaker  [ scalar => [qw(OptionDef)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OptionType;
our @ISA = qw(DynamicData);

our @property_list = (
   ['valueIsReadonly', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(valueIsReadonly)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OptionValue;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['value', 'anyType', undef],
);

use Class::MethodMaker  [ scalar => [qw(key value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfOptionValue;
our @ISA = qw(ComplexType);

our @property_list = (
   ['OptionValue', 'OptionValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(OptionValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package StringOption;
our @ISA = qw(OptionType);

our @property_list = (
   ['defaultValue', undef, undef],
   ['validCharacters', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(defaultValue validCharacters)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskDetail;
our @ISA = qw(TypeDescription);

our @property_list = (
   ['frequency', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(frequency)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfScheduledTaskDetail;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ScheduledTaskDetail', 'ScheduledTaskDetail', 1],
);

use Class::MethodMaker  [ scalar => [qw(ScheduledTaskDetail)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskDescription;
our @ISA = qw(DynamicData);

our @property_list = (
   ['action', 'TypeDescription', 1],
   ['schedulerInfo', 'ScheduledTaskDetail', 1],
   ['state', 'ElementDescription', 1],
   ['dayOfWeek', 'ElementDescription', 1],
   ['weekOfMonth', 'ElementDescription', 1],
);

use Class::MethodMaker  [ scalar => [qw(action schedulerInfo state dayOfWeek weekOfMonth)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskInfo;
our @ISA = qw(ScheduledTaskSpec);

our @property_list = (
   ['scheduledTask', 'ManagedObjectReference', undef],
   ['entity', 'ManagedObjectReference', undef],
   ['lastModifiedTime', undef, undef],
   ['lastModifiedUser', undef, undef],
   ['nextRunTime', undef, undef],
   ['prevRunTime', undef, undef],
   ['state', 'TaskInfoState', undef],
   ['error', 'LocalizedMethodFault', undef],
   ['result', 'anyType', undef],
   ['progress', undef, undef],
   ['activeTask', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(scheduledTask entity lastModifiedTime lastModifiedUser nextRunTime prevRunTime state error result progress activeTask)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package TaskScheduler;
our @ISA = qw(DynamicData);

our @property_list = (
   ['activeTime', undef, undef],
   ['expireTime', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(activeTime expireTime)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package AfterStartupTaskScheduler;
our @ISA = qw(TaskScheduler);

our @property_list = (
   ['minute', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(minute)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package OnceTaskScheduler;
our @ISA = qw(TaskScheduler);

our @property_list = (
   ['runAt', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(runAt)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package RecurrentTaskScheduler;
our @ISA = qw(TaskScheduler);

our @property_list = (
   ['interval', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(interval)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HourlyTaskScheduler;
our @ISA = qw(RecurrentTaskScheduler);

our @property_list = (
   ['minute', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(minute)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DailyTaskScheduler;
our @ISA = qw(HourlyTaskScheduler);

our @property_list = (
   ['hour', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hour)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package WeeklyTaskScheduler;
our @ISA = qw(DailyTaskScheduler);

our @property_list = (
   ['sunday', undef, undef],
   ['monday', undef, undef],
   ['tuesday', undef, undef],
   ['wednesday', undef, undef],
   ['thursday', undef, undef],
   ['friday', undef, undef],
   ['saturday', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(sunday monday tuesday wednesday thursday friday saturday)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MonthlyTaskScheduler;
our @ISA = qw(DailyTaskScheduler);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MonthlyByDayTaskScheduler;
our @ISA = qw(MonthlyTaskScheduler);

our @property_list = (
   ['day', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(day)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package MonthlyByWeekdayTaskScheduler;
our @ISA = qw(MonthlyTaskScheduler);

our @property_list = (
   ['offset', 'WeekOfMonth', undef],
   ['weekday', 'DayOfWeek', undef],
);

use Class::MethodMaker  [ scalar => [qw(offset weekday)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ScheduledTaskSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['description', undef, undef],
   ['enabled', undef, undef],
   ['scheduler', 'TaskScheduler', undef],
   ['action', 'Action', undef],
   ['notification', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name description enabled scheduler action notification)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineAffinityInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['affinitySet', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(affinitySet)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineCapability;
our @ISA = qw(DynamicData);

our @property_list = (
   ['snapshotOperationsSupported', undef, undef],
   ['multipleSnapshotsSupported', undef, undef],
   ['snapshotConfigSupported', undef, undef],
   ['poweredOffSnapshotsSupported', undef, undef],
   ['memorySnapshotsSupported', undef, undef],
   ['revertToSnapshotSupported', undef, undef],
   ['quiescedSnapshotsSupported', undef, undef],
   ['consolePreferencesSupported', undef, undef],
   ['cpuFeatureMaskSupported', undef, undef],
   ['s1AcpiManagementSupported', undef, undef],
   ['settingScreenResolutionSupported', undef, undef],
   ['toolsAutoUpdateSupported', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(snapshotOperationsSupported multipleSnapshotsSupported snapshotConfigSupported poweredOffSnapshotsSupported memorySnapshotsSupported revertToSnapshotSupported quiescedSnapshotsSupported consolePreferencesSupported cpuFeatureMaskSupported s1AcpiManagementSupported settingScreenResolutionSupported toolsAutoUpdateSupported)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineCdromInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineCdromInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineCdromInfo', 'VirtualMachineCdromInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineCdromInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineCloneSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['location', 'VirtualMachineRelocateSpec', undef],
   ['template', undef, undef],
   ['config', 'VirtualMachineConfigSpec', undef],
   ['customization', 'CustomizationSpec', undef],
   ['powerOn', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(location template config customization powerOn)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigInfoDatastoreUrlPair;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['url', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name url)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineConfigInfoDatastoreUrlPair;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineConfigInfoDatastoreUrlPair', 'VirtualMachineConfigInfoDatastoreUrlPair', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineConfigInfoDatastoreUrlPair)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['changeVersion', undef, undef],
   ['modified', undef, undef],
   ['name', undef, undef],
   ['guestFullName', undef, undef],
   ['version', undef, undef],
   ['uuid', undef, undef],
   ['locationId', undef, undef],
   ['template', undef, undef],
   ['guestId', undef, undef],
   ['annotation', undef, undef],
   ['files', 'VirtualMachineFileInfo', undef],
   ['tools', 'ToolsConfigInfo', undef],
   ['flags', 'VirtualMachineFlagInfo', undef],
   ['consolePreferences', 'VirtualMachineConsolePreferences', undef],
   ['defaultPowerOps', 'VirtualMachineDefaultPowerOpInfo', undef],
   ['hardware', 'VirtualHardware', undef],
   ['cpuAllocation', 'ResourceAllocationInfo', undef],
   ['memoryAllocation', 'ResourceAllocationInfo', undef],
   ['cpuAffinity', 'VirtualMachineAffinityInfo', undef],
   ['memoryAffinity', 'VirtualMachineAffinityInfo', undef],
   ['networkShaper', 'VirtualMachineNetworkShaperInfo', undef],
   ['extraConfig', 'OptionValue', 1],
   ['cpuFeatureMask', 'HostCpuIdInfo', 1],
   ['datastoreUrl', 'VirtualMachineConfigInfoDatastoreUrlPair', 1],
);

use Class::MethodMaker  [ scalar => [qw(changeVersion modified name guestFullName version uuid locationId template guestId annotation files tools flags consolePreferences defaultPowerOps hardware cpuAllocation memoryAllocation cpuAffinity memoryAffinity networkShaper extraConfig cpuFeatureMask datastoreUrl)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['version', undef, undef],
   ['description', undef, undef],
   ['guestOSDescriptor', 'GuestOsDescriptor', 1],
   ['guestOSDefaultIndex', undef, undef],
   ['hardwareOptions', 'VirtualHardwareOption', undef],
   ['capabilities', 'VirtualMachineCapability', undef],
   ['datastore', 'DatastoreOption', undef],
   ['defaultDevice', 'VirtualDevice', 1],
);

use Class::MethodMaker  [ scalar => [qw(version description guestOSDescriptor guestOSDefaultIndex hardwareOptions capabilities datastore defaultDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigOptionDescriptor;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['description', undef, undef],
   ['host', 'ManagedObjectReference', 1],
);

use Class::MethodMaker  [ scalar => [qw(key description host)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineConfigOptionDescriptor;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineConfigOptionDescriptor', 'VirtualMachineConfigOptionDescriptor', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineConfigOptionDescriptor)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineCpuIdInfoSpec;
our @ISA = qw(ArrayUpdateSpec);

our @property_list = (
   ['info', 'HostCpuIdInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(info)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineCpuIdInfoSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineCpuIdInfoSpec', 'VirtualMachineCpuIdInfoSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineCpuIdInfoSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['changeVersion', undef, undef],
   ['name', undef, undef],
   ['version', undef, undef],
   ['uuid', undef, undef],
   ['locationId', undef, undef],
   ['guestId', undef, undef],
   ['annotation', undef, undef],
   ['files', 'VirtualMachineFileInfo', undef],
   ['tools', 'ToolsConfigInfo', undef],
   ['flags', 'VirtualMachineFlagInfo', undef],
   ['consolePreferences', 'VirtualMachineConsolePreferences', undef],
   ['powerOpInfo', 'VirtualMachineDefaultPowerOpInfo', undef],
   ['numCPUs', undef, undef],
   ['memoryMB', undef, undef],
   ['deviceChange', 'VirtualDeviceConfigSpec', 1],
   ['cpuAllocation', 'ResourceAllocationInfo', undef],
   ['memoryAllocation', 'ResourceAllocationInfo', undef],
   ['cpuAffinity', 'VirtualMachineAffinityInfo', undef],
   ['memoryAffinity', 'VirtualMachineAffinityInfo', undef],
   ['networkShaper', 'VirtualMachineNetworkShaperInfo', undef],
   ['cpuFeatureMask', 'VirtualMachineCpuIdInfoSpec', 1],
   ['extraConfig', 'OptionValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(changeVersion name version uuid locationId guestId annotation files tools flags consolePreferences powerOpInfo numCPUs memoryMB deviceChange cpuAllocation memoryAllocation cpuAffinity memoryAffinity networkShaper cpuFeatureMask extraConfig)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ConfigTarget;
our @ISA = qw(DynamicData);

our @property_list = (
   ['numCpus', undef, undef],
   ['numCpuCores', undef, undef],
   ['numNumaNodes', undef, undef],
   ['datastore', 'VirtualMachineDatastoreInfo', 1],
   ['network', 'VirtualMachineNetworkInfo', 1],
   ['cdRom', 'VirtualMachineCdromInfo', 1],
   ['serial', 'VirtualMachineSerialInfo', 1],
   ['parallel', 'VirtualMachineParallelInfo', 1],
   ['floppy', 'VirtualMachineFloppyInfo', 1],
   ['legacyNetworkInfo', 'VirtualMachineLegacyNetworkSwitchInfo', 1],
   ['scsiPassthrough', 'VirtualMachineScsiPassthroughInfo', 1],
   ['scsiDisk', 'VirtualMachineScsiDiskDeviceInfo', 1],
   ['ideDisk', 'VirtualMachineIdeDiskDeviceInfo', 1],
   ['maxMemMBOptimalPerf', undef, undef],
   ['resourcePool', 'ResourcePoolRuntimeInfo', undef],
   ['autoVmotion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(numCpus numCpuCores numNumaNodes datastore network cdRom serial parallel floppy legacyNetworkInfo scsiPassthrough scsiDisk ideDisk maxMemMBOptimalPerf resourcePool autoVmotion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConsolePreferences;
our @ISA = qw(DynamicData);

our @property_list = (
   ['powerOnWhenOpened', undef, undef],
   ['enterFullScreenOnPowerOn', undef, undef],
   ['closeOnPowerOffOrSuspend', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(powerOnWhenOpened enterFullScreenOnPowerOn closeOnPowerOffOrSuspend)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineDatastoreInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
   ['datastore', 'DatastoreSummary', undef],
   ['capability', 'DatastoreCapability', undef],
   ['maxFileSize', undef, undef],
   ['mode', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore capability maxFileSize mode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineDatastoreInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineDatastoreInfo', 'VirtualMachineDatastoreInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineDatastoreInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineDatastoreVolumeOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['fileSystemType', undef, undef],
   ['majorVersion', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(fileSystemType majorVersion)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineDatastoreVolumeOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineDatastoreVolumeOption', 'VirtualMachineDatastoreVolumeOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineDatastoreVolumeOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package DatastoreOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['unsupportedVolumes', 'VirtualMachineDatastoreVolumeOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(unsupportedVolumes)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineDefaultPowerOpInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['powerOffType', undef, undef],
   ['suspendType', undef, undef],
   ['resetType', undef, undef],
   ['defaultPowerOffType', undef, undef],
   ['defaultSuspendType', undef, undef],
   ['defaultResetType', undef, undef],
   ['standbyAction', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(powerOffType suspendType resetType defaultPowerOffType defaultSuspendType defaultResetType standbyAction)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineDiskDeviceInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
   ['capacity', undef, undef],
   ['vm', 'ManagedObjectReference', 1],
);

use Class::MethodMaker  [ scalar => [qw(capacity vm)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFileInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vmPathName', undef, undef],
   ['snapshotDirectory', undef, undef],
   ['suspendDirectory', undef, undef],
   ['logDirectory', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(vmPathName snapshotDirectory suspendDirectory logDirectory)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFileLayoutDiskLayout;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['diskFile', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(key diskFile)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineFileLayoutDiskLayout;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineFileLayoutDiskLayout', 'VirtualMachineFileLayoutDiskLayout', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineFileLayoutDiskLayout)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFileLayoutSnapshotLayout;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', 'ManagedObjectReference', undef],
   ['snapshotFile', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(key snapshotFile)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineFileLayoutSnapshotLayout;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineFileLayoutSnapshotLayout', 'VirtualMachineFileLayoutSnapshotLayout', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineFileLayoutSnapshotLayout)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFileLayout;
our @ISA = qw(DynamicData);

our @property_list = (
   ['configFile', undef, 1],
   ['logFile', undef, 1],
   ['disk', 'VirtualMachineFileLayoutDiskLayout', 1],
   ['snapshot', 'VirtualMachineFileLayoutSnapshotLayout', 1],
   ['swapFile', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(configFile logFile disk snapshot swapFile)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFlagInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['disableAcceleration', undef, undef],
   ['enableLogging', undef, undef],
   ['useToe', undef, undef],
   ['runWithDebugInfo', undef, undef],
   ['htSharing', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(disableAcceleration enableLogging useToe runWithDebugInfo htSharing)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineFloppyInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineFloppyInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineFloppyInfo', 'VirtualMachineFloppyInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineFloppyInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GuestDiskInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskPath', undef, undef],
   ['capacity', undef, undef],
   ['freeSpace', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskPath capacity freeSpace)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfGuestDiskInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['GuestDiskInfo', 'GuestDiskInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(GuestDiskInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GuestNicInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['network', undef, undef],
   ['ipAddress', undef, 1],
   ['macAddress', undef, undef],
   ['connected', undef, undef],
   ['deviceConfigId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(network ipAddress macAddress connected deviceConfigId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfGuestNicInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['GuestNicInfo', 'GuestNicInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(GuestNicInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GuestScreenInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['width', undef, undef],
   ['height', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(width height)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GuestInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['toolsStatus', 'VirtualMachineToolsStatus', undef],
   ['toolsVersion', undef, undef],
   ['guestId', undef, undef],
   ['guestFamily', undef, undef],
   ['guestFullName', undef, undef],
   ['hostName', undef, undef],
   ['ipAddress', undef, undef],
   ['net', 'GuestNicInfo', 1],
   ['disk', 'GuestDiskInfo', 1],
   ['screen', 'GuestScreenInfo', undef],
   ['guestState', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(toolsStatus toolsVersion guestId guestFamily guestFullName hostName ipAddress net disk screen guestState)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package GuestOsDescriptor;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', undef, undef],
   ['family', undef, undef],
   ['fullName', undef, undef],
   ['supportedMaxCPUs', undef, undef],
   ['supportedMinMemMB', undef, undef],
   ['supportedMaxMemMB', undef, undef],
   ['recommendedMemMB', undef, undef],
   ['recommendedColorDepth', undef, undef],
   ['supportedDiskControllerList', undef, 1],
   ['recommendedSCSIController', undef, undef],
   ['recommendedDiskController', undef, undef],
   ['supportedNumDisks', undef, undef],
   ['recommendedDiskSizeMB', undef, undef],
   ['supportedEthernetCard', undef, 1],
   ['recommendedEthernetCard', undef, undef],
   ['supportsSlaveDisk', undef, undef],
   ['cpuFeatureMask', 'HostCpuIdInfo', 1],
   ['supportsWakeOnLan', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(id family fullName supportedMaxCPUs supportedMinMemMB supportedMaxMemMB recommendedMemMB recommendedColorDepth supportedDiskControllerList recommendedSCSIController recommendedDiskController supportedNumDisks recommendedDiskSizeMB supportedEthernetCard recommendedEthernetCard supportsSlaveDisk cpuFeatureMask supportsWakeOnLan)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfGuestOsDescriptor;
our @ISA = qw(ComplexType);

our @property_list = (
   ['GuestOsDescriptor', 'GuestOsDescriptor', 1],
);

use Class::MethodMaker  [ scalar => [qw(GuestOsDescriptor)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineIdeDiskDevicePartitionInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', undef, undef],
   ['capacity', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(id capacity)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineIdeDiskDevicePartitionInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineIdeDiskDevicePartitionInfo', 'VirtualMachineIdeDiskDevicePartitionInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineIdeDiskDevicePartitionInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineIdeDiskDeviceInfo;
our @ISA = qw(VirtualMachineDiskDeviceInfo);

our @property_list = (
   ['partitionTable', 'VirtualMachineIdeDiskDevicePartitionInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(partitionTable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineIdeDiskDeviceInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineIdeDiskDeviceInfo', 'VirtualMachineIdeDiskDeviceInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineIdeDiskDeviceInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineLegacyNetworkSwitchInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineLegacyNetworkSwitchInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineLegacyNetworkSwitchInfo', 'VirtualMachineLegacyNetworkSwitchInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineLegacyNetworkSwitchInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineNetworkInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
   ['network', 'NetworkSummary', undef],
);

use Class::MethodMaker  [ scalar => [qw(network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineNetworkInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineNetworkInfo', 'VirtualMachineNetworkInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineNetworkInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineNetworkShaperInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['enabled', undef, undef],
   ['peakBps', undef, undef],
   ['averageBps', undef, undef],
   ['burstSize', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(enabled peakBps averageBps burstSize)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineParallelInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineParallelInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineParallelInfo', 'VirtualMachineParallelInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineParallelInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineQuestionInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['id', undef, undef],
   ['text', undef, undef],
   ['choice', 'ChoiceOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(id text choice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineRelocateSpecDiskLocator;
our @ISA = qw(DynamicData);

our @property_list = (
   ['diskId', undef, undef],
   ['datastore', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(diskId datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineRelocateSpecDiskLocator;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineRelocateSpecDiskLocator', 'VirtualMachineRelocateSpecDiskLocator', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineRelocateSpecDiskLocator)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineRelocateSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['datastore', 'ManagedObjectReference', undef],
   ['pool', 'ManagedObjectReference', undef],
   ['host', 'ManagedObjectReference', undef],
   ['disk', 'VirtualMachineRelocateSpecDiskLocator', 1],
   ['transform', 'VirtualMachineRelocateTransformation', undef],
);

use Class::MethodMaker  [ scalar => [qw(datastore pool host disk transform)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineRuntimeInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['host', 'ManagedObjectReference', undef],
   ['connectionState', 'VirtualMachineConnectionState', undef],
   ['powerState', 'VirtualMachinePowerState', undef],
   ['toolsInstallerMounted', undef, undef],
   ['suspendTime', undef, undef],
   ['bootTime', undef, undef],
   ['suspendInterval', undef, undef],
   ['question', 'VirtualMachineQuestionInfo', undef],
   ['memoryOverhead', undef, undef],
   ['maxCpuUsage', undef, undef],
   ['maxMemoryUsage', undef, undef],
   ['numMksConnections', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(host connectionState powerState toolsInstallerMounted suspendTime bootTime suspendInterval question memoryOverhead maxCpuUsage maxMemoryUsage numMksConnections)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineScsiDiskDeviceInfo;
our @ISA = qw(VirtualMachineDiskDeviceInfo);

our @property_list = (
   ['disk', 'HostScsiDisk', undef],
);

use Class::MethodMaker  [ scalar => [qw(disk)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineScsiDiskDeviceInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineScsiDiskDeviceInfo', 'VirtualMachineScsiDiskDeviceInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineScsiDiskDeviceInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineScsiPassthroughInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
   ['scsiClass', undef, undef],
   ['vendor', undef, undef],
   ['physicalUnitNumber', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(scsiClass vendor physicalUnitNumber)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineScsiPassthroughInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineScsiPassthroughInfo', 'VirtualMachineScsiPassthroughInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineScsiPassthroughInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineSerialInfo;
our @ISA = qw(VirtualMachineTargetInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineSerialInfo;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineSerialInfo', 'VirtualMachineSerialInfo', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineSerialInfo)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineSnapshotInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['currentSnapshot', 'ManagedObjectReference', undef],
   ['rootSnapshotList', 'VirtualMachineSnapshotTree', 1],
);

use Class::MethodMaker  [ scalar => [qw(currentSnapshot rootSnapshotList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineSnapshotTree;
our @ISA = qw(DynamicData);

our @property_list = (
   ['snapshot', 'ManagedObjectReference', undef],
   ['vm', 'ManagedObjectReference', undef],
   ['name', undef, undef],
   ['description', undef, undef],
   ['createTime', undef, undef],
   ['state', 'VirtualMachinePowerState', undef],
   ['quiesced', undef, undef],
   ['childSnapshotList', 'VirtualMachineSnapshotTree', 1],
);

use Class::MethodMaker  [ scalar => [qw(snapshot vm name description createTime state quiesced childSnapshotList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineSnapshotTree;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineSnapshotTree', 'VirtualMachineSnapshotTree', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineSnapshotTree)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineConfigSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['template', undef, undef],
   ['vmPathName', undef, undef],
   ['memorySizeMB', undef, undef],
   ['cpuReservation', undef, undef],
   ['memoryReservation', undef, undef],
   ['numCpu', undef, undef],
   ['numEthernetCards', undef, undef],
   ['numVirtualDisks', undef, undef],
   ['uuid', undef, undef],
   ['guestId', undef, undef],
   ['guestFullName', undef, undef],
   ['annotation', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name template vmPathName memorySizeMB cpuReservation memoryReservation numCpu numEthernetCards numVirtualDisks uuid guestId guestFullName annotation)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineQuickStats;
our @ISA = qw(DynamicData);

our @property_list = (
   ['overallCpuUsage', undef, undef],
   ['guestMemoryUsage', undef, undef],
   ['hostMemoryUsage', undef, undef],
   ['guestHeartbeatStatus', 'ManagedEntityStatus', undef],
   ['distributedCpuEntitlement', undef, undef],
   ['distributedMemoryEntitlement', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(overallCpuUsage guestMemoryUsage hostMemoryUsage guestHeartbeatStatus distributedCpuEntitlement distributedMemoryEntitlement)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineGuestSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['guestId', undef, undef],
   ['guestFullName', undef, undef],
   ['toolsStatus', 'VirtualMachineToolsStatus', undef],
   ['hostName', undef, undef],
   ['ipAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(guestId guestFullName toolsStatus hostName ipAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineSummary;
our @ISA = qw(DynamicData);

our @property_list = (
   ['vm', 'ManagedObjectReference', undef],
   ['runtime', 'VirtualMachineRuntimeInfo', undef],
   ['guest', 'VirtualMachineGuestSummary', undef],
   ['config', 'VirtualMachineConfigSummary', undef],
   ['quickStats', 'VirtualMachineQuickStats', undef],
   ['overallStatus', 'ManagedEntityStatus', undef],
   ['customValue', 'CustomFieldValue', 1],
);

use Class::MethodMaker  [ scalar => [qw(vm runtime guest config quickStats overallStatus customValue)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualMachineSummary;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualMachineSummary', 'VirtualMachineSummary', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualMachineSummary)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineTargetInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['configurationTag', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(name configurationTag)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ToolsConfigInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['toolsVersion', undef, undef],
   ['afterPowerOn', undef, undef],
   ['afterResume', undef, undef],
   ['beforeGuestStandby', undef, undef],
   ['beforeGuestShutdown', undef, undef],
   ['beforeGuestReboot', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(toolsVersion afterPowerOn afterResume beforeGuestStandby beforeGuestShutdown beforeGuestReboot)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualHardware;
our @ISA = qw(DynamicData);

our @property_list = (
   ['numCPU', undef, undef],
   ['memoryMB', undef, undef],
   ['device', 'VirtualDevice', 1],
);

use Class::MethodMaker  [ scalar => [qw(numCPU memoryMB device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualHardwareOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['hwVersion', undef, undef],
   ['virtualDeviceOption', 'VirtualDeviceOption', 1],
   ['deviceListReadonly', undef, undef],
   ['numCPU', undef, 1],
   ['numCpuReadonly', undef, undef],
   ['memoryMB', 'LongOption', undef],
   ['numPCIControllers', 'IntOption', undef],
   ['numIDEControllers', 'IntOption', undef],
   ['numUSBControllers', 'IntOption', undef],
   ['numSIOControllers', 'IntOption', undef],
   ['numPS2Controllers', 'IntOption', undef],
   ['licensingLimit', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(hwVersion virtualDeviceOption deviceListReadonly numCPU numCpuReadonly memoryMB numPCIControllers numIDEControllers numUSBControllers numSIOControllers numPS2Controllers licensingLimit)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['options', 'CustomizationOptions', undef],
   ['identity', 'CustomizationIdentitySettings', undef],
   ['globalIPSettings', 'CustomizationGlobalIPSettings', undef],
   ['nicSettingMap', 'CustomizationAdapterMapping', 1],
   ['encryptionKey', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(options identity globalIPSettings nicSettingMap encryptionKey)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationName;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationFixedName;
our @ISA = qw(CustomizationName);

our @property_list = (
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationPrefixName;
our @ISA = qw(CustomizationName);

our @property_list = (
   ['base', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(base)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationVirtualMachineName;
our @ISA = qw(CustomizationName);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationUnknownName;
our @ISA = qw(CustomizationName);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationCustomName;
our @ISA = qw(CustomizationName);

our @property_list = (
   ['argument', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(argument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationPassword;
our @ISA = qw(DynamicData);

our @property_list = (
   ['value', undef, undef],
   ['plainText', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(value plainText)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationOptions;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationWinOptions;
our @ISA = qw(CustomizationOptions);

our @property_list = (
   ['changeSID', undef, undef],
   ['deleteAccounts', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(changeSID deleteAccounts)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationLinuxOptions;
our @ISA = qw(CustomizationOptions);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationGuiUnattended;
our @ISA = qw(DynamicData);

our @property_list = (
   ['password', 'CustomizationPassword', undef],
   ['timeZone', undef, undef],
   ['autoLogon', undef, undef],
   ['autoLogonCount', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(password timeZone autoLogon autoLogonCount)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationUserData;
our @ISA = qw(DynamicData);

our @property_list = (
   ['fullName', undef, undef],
   ['orgName', undef, undef],
   ['computerName', 'CustomizationName', undef],
   ['productId', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(fullName orgName computerName productId)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationGuiRunOnce;
our @ISA = qw(DynamicData);

our @property_list = (
   ['commandList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(commandList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationIdentification;
our @ISA = qw(DynamicData);

our @property_list = (
   ['joinWorkgroup', undef, undef],
   ['joinDomain', undef, undef],
   ['domainAdmin', undef, undef],
   ['domainAdminPassword', 'CustomizationPassword', undef],
);

use Class::MethodMaker  [ scalar => [qw(joinWorkgroup joinDomain domainAdmin domainAdminPassword)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationLicenseFilePrintData;
our @ISA = qw(DynamicData);

our @property_list = (
   ['autoMode', 'CustomizationLicenseDataMode', undef],
   ['autoUsers', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(autoMode autoUsers)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationIdentitySettings;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationSysprepText;
our @ISA = qw(CustomizationIdentitySettings);

our @property_list = (
   ['value', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(value)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationSysprep;
our @ISA = qw(CustomizationIdentitySettings);

our @property_list = (
   ['guiUnattended', 'CustomizationGuiUnattended', undef],
   ['userData', 'CustomizationUserData', undef],
   ['guiRunOnce', 'CustomizationGuiRunOnce', undef],
   ['identification', 'CustomizationIdentification', undef],
   ['licenseFilePrintData', 'CustomizationLicenseFilePrintData', undef],
);

use Class::MethodMaker  [ scalar => [qw(guiUnattended userData guiRunOnce identification licenseFilePrintData)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationLinuxPrep;
our @ISA = qw(CustomizationIdentitySettings);

our @property_list = (
   ['hostName', 'CustomizationName', undef],
   ['domain', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hostName domain)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationGlobalIPSettings;
our @ISA = qw(DynamicData);

our @property_list = (
   ['dnsSuffixList', undef, 1],
   ['dnsServerList', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(dnsSuffixList dnsServerList)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationIPSettings;
our @ISA = qw(DynamicData);

our @property_list = (
   ['ip', 'CustomizationIpGenerator', undef],
   ['subnetMask', undef, undef],
   ['gateway', undef, 1],
   ['dnsServerList', undef, 1],
   ['dnsDomain', undef, undef],
   ['primaryWINS', undef, undef],
   ['secondaryWINS', undef, undef],
   ['netBIOS', 'CustomizationNetBIOSMode', undef],
);

use Class::MethodMaker  [ scalar => [qw(ip subnetMask gateway dnsServerList dnsDomain primaryWINS secondaryWINS netBIOS)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationIpGenerator;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationDhcpIpGenerator;
our @ISA = qw(CustomizationIpGenerator);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationFixedIp;
our @ISA = qw(CustomizationIpGenerator);

our @property_list = (
   ['ipAddress', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(ipAddress)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationUnknownIpGenerator;
our @ISA = qw(CustomizationIpGenerator);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationCustomIpGenerator;
our @ISA = qw(CustomizationIpGenerator);

our @property_list = (
   ['argument', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(argument)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package CustomizationAdapterMapping;
our @ISA = qw(DynamicData);

our @property_list = (
   ['macAddress', undef, undef],
   ['adapter', 'CustomizationIPSettings', undef],
);

use Class::MethodMaker  [ scalar => [qw(macAddress adapter)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfCustomizationAdapterMapping;
our @ISA = qw(ComplexType);

our @property_list = (
   ['CustomizationAdapterMapping', 'CustomizationAdapterMapping', 1],
);

use Class::MethodMaker  [ scalar => [qw(CustomizationAdapterMapping)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskMappingPartitionInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['fileSystem', undef, undef],
   ['capacityInKb', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name fileSystem capacityInKb)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskMappingInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['physicalPartition', 'HostDiskMappingPartitionInfo', undef],
   ['name', undef, undef],
   ['exclusive', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(physicalPartition name exclusive)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskMappingPartitionOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['name', undef, undef],
   ['fileSystem', undef, undef],
   ['capacityInKb', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(name fileSystem capacityInKb)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfHostDiskMappingPartitionOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['HostDiskMappingPartitionOption', 'HostDiskMappingPartitionOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(HostDiskMappingPartitionOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package HostDiskMappingOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['physicalPartition', 'HostDiskMappingPartitionOption', 1],
   ['name', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(physicalPartition name)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualBusLogicController;
our @ISA = qw(VirtualSCSIController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualBusLogicControllerOption;
our @ISA = qw(VirtualSCSIControllerOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromIsoBackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromPassthroughBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
   ['exclusive', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(exclusive)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromRemotePassthroughBackingInfo;
our @ISA = qw(VirtualDeviceRemoteDeviceBackingInfo);

our @property_list = (
   ['exclusive', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(exclusive)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromAtapiBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromRemoteAtapiBackingInfo;
our @ISA = qw(VirtualDeviceRemoteDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdrom;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromIsoBackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromPassthroughBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
   ['exclusive', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(exclusive)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromRemotePassthroughBackingOption;
our @ISA = qw(VirtualDeviceRemoteDeviceBackingOption);

our @property_list = (
   ['exclusive', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(exclusive)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromAtapiBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromRemoteAtapiBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualCdromOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualController;
our @ISA = qw(VirtualDevice);

our @property_list = (
   ['busNumber', undef, undef],
   ['device', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(busNumber device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualControllerOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
   ['devices', 'IntOption', undef],
   ['supportedDevice', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(devices supportedDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceBackingInfo;
our @ISA = qw(DynamicData);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceFileBackingInfo;
our @ISA = qw(VirtualDeviceBackingInfo);

our @property_list = (
   ['fileName', undef, undef],
   ['datastore', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(fileName datastore)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceDeviceBackingInfo;
our @ISA = qw(VirtualDeviceBackingInfo);

our @property_list = (
   ['deviceName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(deviceName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceRemoteDeviceBackingInfo;
our @ISA = qw(VirtualDeviceBackingInfo);

our @property_list = (
   ['deviceName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(deviceName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDevicePipeBackingInfo;
our @ISA = qw(VirtualDeviceBackingInfo);

our @property_list = (
   ['pipeName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(pipeName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceConnectInfo;
our @ISA = qw(DynamicData);

our @property_list = (
   ['startConnected', undef, undef],
   ['allowGuestControl', undef, undef],
   ['connected', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(startConnected allowGuestControl connected)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDevice;
our @ISA = qw(DynamicData);

our @property_list = (
   ['key', undef, undef],
   ['deviceInfo', 'Description', undef],
   ['backing', 'VirtualDeviceBackingInfo', undef],
   ['connectable', 'VirtualDeviceConnectInfo', undef],
   ['controllerKey', undef, undef],
   ['unitNumber', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(key deviceInfo backing connectable controllerKey unitNumber)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualDevice;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualDevice', 'VirtualDevice', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceBackingOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['type', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(type)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualDeviceBackingOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualDeviceBackingOption', 'VirtualDeviceBackingOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualDeviceBackingOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceFileBackingOption;
our @ISA = qw(VirtualDeviceBackingOption);

our @property_list = (
   ['fileNameExtensions', 'ChoiceOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(fileNameExtensions)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceDeviceBackingOption;
our @ISA = qw(VirtualDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceRemoteDeviceBackingOption;
our @ISA = qw(VirtualDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDevicePipeBackingOption;
our @ISA = qw(VirtualDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceConnectOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['startConnected', 'BoolOption', undef],
   ['allowGuestControl', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(startConnected allowGuestControl)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceOption;
our @ISA = qw(DynamicData);

our @property_list = (
   ['type', undef, undef],
   ['connectOption', 'VirtualDeviceConnectOption', undef],
   ['controllerType', undef, undef],
   ['autoAssignController', 'BoolOption', undef],
   ['backingOption', 'VirtualDeviceBackingOption', 1],
   ['defaultBackingOptionIndex', undef, undef],
   ['licensingLimit', undef, 1],
   ['deprecated', undef, undef],
   ['plugAndPlay', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(type connectOption controllerType autoAssignController backingOption defaultBackingOptionIndex licensingLimit deprecated plugAndPlay)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualDeviceOption;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualDeviceOption', 'VirtualDeviceOption', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualDeviceOption)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDeviceConfigSpec;
our @ISA = qw(DynamicData);

our @property_list = (
   ['operation', 'VirtualDeviceConfigSpecOperation', undef],
   ['fileOperation', 'VirtualDeviceConfigSpecFileOperation', undef],
   ['device', 'VirtualDevice', undef],
);

use Class::MethodMaker  [ scalar => [qw(operation fileOperation device)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualDeviceConfigSpec;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualDeviceConfigSpec', 'VirtualDeviceConfigSpec', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualDeviceConfigSpec)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskSparseVer1BackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
   ['diskMode', undef, undef],
   ['split', undef, undef],
   ['writeThrough', undef, undef],
   ['spaceUsedInKB', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough spaceUsedInKB)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskSparseVer2BackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
   ['diskMode', undef, undef],
   ['split', undef, undef],
   ['writeThrough', undef, undef],
   ['spaceUsedInKB', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough spaceUsedInKB)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskFlatVer1BackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
   ['diskMode', undef, undef],
   ['split', undef, undef],
   ['writeThrough', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskFlatVer2BackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
   ['diskMode', undef, undef],
   ['split', undef, undef],
   ['writeThrough', undef, undef],
   ['thinProvisioned', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough thinProvisioned)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskRawDiskVer2BackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
   ['descriptorFileName', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(descriptorFileName)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskPartitionedRawDiskVer2BackingInfo;
our @ISA = qw(VirtualDiskRawDiskVer2BackingInfo);

our @property_list = (
   ['partition', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(partition)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskRawDiskMappingVer1BackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
   ['lunUuid', undef, undef],
   ['deviceName', undef, undef],
   ['compatibilityMode', undef, undef],
   ['diskMode', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(lunUuid deviceName compatibilityMode diskMode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDisk;
our @ISA = qw(VirtualDevice);

our @property_list = (
   ['capacityInKB', undef, undef],
   ['shares', 'SharesInfo', undef],
);

use Class::MethodMaker  [ scalar => [qw(capacityInKB shares)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskSparseVer1BackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
   ['diskModes', 'ChoiceOption', undef],
   ['split', 'BoolOption', undef],
   ['writeThrough', 'BoolOption', undef],
   ['growable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskModes split writeThrough growable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskSparseVer2BackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
   ['diskMode', 'ChoiceOption', undef],
   ['split', 'BoolOption', undef],
   ['writeThrough', 'BoolOption', undef],
   ['growable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough growable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskFlatVer1BackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
   ['diskMode', 'ChoiceOption', undef],
   ['split', 'BoolOption', undef],
   ['writeThrough', 'BoolOption', undef],
   ['growable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough growable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskFlatVer2BackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
   ['diskMode', 'ChoiceOption', undef],
   ['split', 'BoolOption', undef],
   ['writeThrough', 'BoolOption', undef],
   ['growable', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(diskMode split writeThrough growable)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskRawDiskVer2BackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
   ['descriptorFileNameExtensions', 'ChoiceOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(descriptorFileNameExtensions)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskPartitionedRawDiskVer2BackingOption;
our @ISA = qw(VirtualDiskRawDiskVer2BackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskRawDiskMappingVer1BackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
   ['descriptorFileNameExtensions', 'ChoiceOption', undef],
   ['compatibilityMode', 'ChoiceOption', undef],
   ['diskMode', 'ChoiceOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(descriptorFileNameExtensions compatibilityMode diskMode)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualDiskOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
   ['capacityInKB', 'LongOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(capacityInKB)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualE1000;
our @ISA = qw(VirtualEthernetCard);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualE1000Option;
our @ISA = qw(VirtualEthernetCardOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEnsoniq1371;
our @ISA = qw(VirtualSoundCard);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEnsoniq1371Option;
our @ISA = qw(VirtualSoundCardOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCardNetworkBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
   ['network', 'ManagedObjectReference', undef],
);

use Class::MethodMaker  [ scalar => [qw(network)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCardLegacyNetworkBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCard;
our @ISA = qw(VirtualDevice);

our @property_list = (
   ['addressType', undef, undef],
   ['macAddress', undef, undef],
   ['wakeOnLanEnabled', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(addressType macAddress wakeOnLanEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCardNetworkBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCardLegacyNetworkBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualEthernetCardOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
   ['supportedOUI', 'ChoiceOption', undef],
   ['macType', 'ChoiceOption', undef],
   ['wakeOnLanEnabled', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(supportedOUI macType wakeOnLanEnabled)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyImageBackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyRemoteDeviceBackingInfo;
our @ISA = qw(VirtualDeviceRemoteDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppy;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyImageBackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyRemoteDeviceBackingOption;
our @ISA = qw(VirtualDeviceRemoteDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualFloppyOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualIDEController;
our @ISA = qw(VirtualController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualIDEControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['numIDEDisks', 'IntOption', undef],
   ['numIDECdroms', 'IntOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(numIDEDisks numIDECdroms)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualKeyboard;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualKeyboardOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualLsiLogicController;
our @ISA = qw(VirtualSCSIController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualLsiLogicControllerOption;
our @ISA = qw(VirtualSCSIControllerOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPCIController;
our @ISA = qw(VirtualController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPCIControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['numSCSIControllers', 'IntOption', undef],
   ['numEthernetCards', 'IntOption', undef],
   ['numVideoCards', 'IntOption', undef],
   ['numSoundCards', 'IntOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(numSCSIControllers numEthernetCards numVideoCards numSoundCards)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPCNet32;
our @ISA = qw(VirtualEthernetCard);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPCNet32Option;
our @ISA = qw(VirtualEthernetCardOption);

our @property_list = (
   ['supportsMorphing', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(supportsMorphing)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPS2Controller;
our @ISA = qw(VirtualController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPS2ControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['numKeyboards', 'IntOption', undef],
   ['numPointingDevices', 'IntOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(numKeyboards numPointingDevices)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPortFileBackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPortDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPort;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPortFileBackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPortDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualParallelPortOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPointingDeviceDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
   ['hostPointingDevice', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hostPointingDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPointingDevice;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPointingDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
   ['hostPointingDevice', 'ChoiceOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(hostPointingDevice)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualPointingDeviceOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfVirtualSCSISharing;
our @ISA = qw(ComplexType);

our @property_list = (
   ['VirtualSCSISharing', 'VirtualSCSISharing', 1],
);

use Class::MethodMaker  [ scalar => [qw(VirtualSCSISharing)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIController;
our @ISA = qw(VirtualController);

our @property_list = (
   ['hotAddRemove', undef, undef],
   ['sharedBus', 'VirtualSCSISharing', undef],
   ['scsiCtlrUnitNumber', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(hotAddRemove sharedBus scsiCtlrUnitNumber)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['numSCSIDisks', 'IntOption', undef],
   ['numSCSICdroms', 'IntOption', undef],
   ['numSCSIPassthrough', 'IntOption', undef],
   ['sharing', 'VirtualSCSISharing', 1],
   ['defaultSharedIndex', undef, undef],
   ['hotAddRemove', 'BoolOption', undef],
   ['scsiCtlrUnitNumber', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(numSCSIDisks numSCSICdroms numSCSIPassthrough sharing defaultSharedIndex hotAddRemove scsiCtlrUnitNumber)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIPassthroughDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIPassthrough;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIPassthroughDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSCSIPassthroughOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSIOController;
our @ISA = qw(VirtualController);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSIOControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['numFloppyDrives', 'IntOption', undef],
   ['numSerialPorts', 'IntOption', undef],
   ['numParallelPorts', 'IntOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(numFloppyDrives numSerialPorts numParallelPorts)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortFileBackingInfo;
our @ISA = qw(VirtualDeviceFileBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortPipeBackingInfo;
our @ISA = qw(VirtualDevicePipeBackingInfo);

our @property_list = (
   ['endpoint', undef, undef],
   ['noRxLoss', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(endpoint noRxLoss)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPort;
our @ISA = qw(VirtualDevice);

our @property_list = (
   ['yieldOnPoll', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(yieldOnPoll)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortFileBackingOption;
our @ISA = qw(VirtualDeviceFileBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortPipeBackingOption;
our @ISA = qw(VirtualDevicePipeBackingOption);

our @property_list = (
   ['endpoint', 'ChoiceOption', undef],
   ['noRxLoss', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(endpoint noRxLoss)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSerialPortOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
   ['yieldOnPoll', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(yieldOnPoll)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundBlaster16;
our @ISA = qw(VirtualSoundCard);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundBlaster16Option;
our @ISA = qw(VirtualSoundCardOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundCardDeviceBackingInfo;
our @ISA = qw(VirtualDeviceDeviceBackingInfo);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundCard;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundCardDeviceBackingOption;
our @ISA = qw(VirtualDeviceDeviceBackingOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualSoundCardOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualUSB;
our @ISA = qw(VirtualDevice);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualUSBController;
our @ISA = qw(VirtualController);

our @property_list = (
   ['autoConnectDevices', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(autoConnectDevices)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualUSBControllerOption;
our @ISA = qw(VirtualControllerOption);

our @property_list = (
   ['autoConnectDevices', 'BoolOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(autoConnectDevices)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualUSBOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualMachineVideoCard;
our @ISA = qw(VirtualDevice);

our @property_list = (
   ['videoRamSizeInKB', undef, undef],
);

use Class::MethodMaker  [ scalar => [qw(videoRamSizeInKB)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualVideoCardOption;
our @ISA = qw(VirtualDeviceOption);

our @property_list = (
   ['videoRamSizeInKB', 'LongOption', undef],
);

use Class::MethodMaker  [ scalar => [qw(videoRamSizeInKB)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualVmxnet;
our @ISA = qw(VirtualEthernetCard);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package VirtualVmxnetOption;
our @ISA = qw(VirtualEthernetCardOption);

our @property_list = (
);


sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfString;
our @ISA = qw(ComplexType);

our @property_list = (
   ['string', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(string)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfAnyType;
our @ISA = qw(ComplexType);

our @property_list = (
   ['anyType', 'anyType', 1],
);

use Class::MethodMaker  [ scalar => [qw(anyType)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfManagedObjectReference;
our @ISA = qw(ComplexType);

our @property_list = (
   ['ManagedObjectReference', 'ManagedObjectReference', 1],
);

use Class::MethodMaker  [ scalar => [qw(ManagedObjectReference)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfInt;
our @ISA = qw(ComplexType);

our @property_list = (
   ['int', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(int)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfByte;
our @ISA = qw(ComplexType);

our @property_list = (
   ['byte', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(byte)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfShort;
our @ISA = qw(ComplexType);

our @property_list = (
   ['short', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(short)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ArrayOfLong;
our @ISA = qw(ComplexType);

our @property_list = (
   ['long', undef, 1],
);

use Class::MethodMaker  [ scalar => [qw(long)] ];

sub get_property_list {
   my $class = shift;
   my @super_list = $class->SUPER::get_property_list();
   return (@super_list, @property_list);   
}

1;
##################################################################################




##################################################################################
package ObjectUpdateKind;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PropertyChangeOp;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DiagnosticManagerLogCreator;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DiagnosticManagerLogFormat;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostSystemConnectionState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package LicenseManagerLicenseKey;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package LicenseFeatureInfoUnit;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package LicenseFeatureInfoState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package LicenseReservationInfoState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ManagedEntityStatus;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PerfFormat;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PerfSummaryType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PerfStatsType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PerformanceManagerUnit;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ValidateMigrationTestType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VMotionCompatibilityType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package SharesLevel;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package TaskFilterSpecRecursionOption;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package TaskFilterSpecTimeOption;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package TaskInfoState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachinePowerState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineConnectionState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineMovePriority;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ActionParameter;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package StateAlarmOperator;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package MetricAlarmOperator;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DrsBehavior;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DasVmPriority;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DrsRecommendationReasonCode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package EventCategory;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package EventFilterSpecRecursionOption;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package AffinityType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package AutoStartAction;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package AutoStartWaitHeartbeatSetting;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostConfigChangeMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostConfigChangeOperation;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DiagnosticPartitionStorageType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DiagnosticPartitionType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostDiskPartitionInfoType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostCpuPackageVendor;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package FibreChannelPortType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package InternetScsiSnsDiscoveryMethod;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package SlpDiscoveryMethod;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostMountMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package MultipathState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package PortGroupConnecteeType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostFirewallRuleDirection;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostFirewallRuleProtocol;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ScsiLunType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ScsiLunState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package HostServicePolicy;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package ArrayUpdateOperation;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package DayOfWeek;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package WeekOfMonth;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachinePowerOpType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineStandbyActionType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineHtSharing;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineToolsStatus;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineGuestState;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineGuestOsFamily;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineGuestOsIdentifier;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineRelocateTransformation;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineScsiPassthroughType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualMachineTargetInfoConfigurationTag;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package CustomizationLicenseDataMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package CustomizationNetBIOSMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualDeviceFileExtension;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualDeviceConfigSpecOperation;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualDeviceConfigSpecFileOperation;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualDiskMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualDiskCompatibilityMode;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualEthernetCardLegacyNetworkDeviceName;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualEthernetCardMacType;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualPointingDeviceHostChoice;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualSCSISharing;
our @ISA = qw(SimpleType);

1;
##################################################################################




##################################################################################
package VirtualSerialPortEndPoint;
our @ISA = qw(SimpleType);

1;
##################################################################################



###################################################################
package VimService;

sub new {
   my ($class, $url) = @_;
   my $self = {};
   my $vim_soap = SoapClient->new($url);
   $self->{vim_soap} = $vim_soap;
   bless $self, $class;
}

sub save_session {
   my ($self, $file) = @_;
   my $vim_soap = $self->{vim_soap};
   $vim_soap->save_session($file);
}

sub load_session {
   my ($self, $file) = @_;
   my $vim_soap = $self->{vim_soap};
   $vim_soap->load_session($file);
}


sub deserialize_response {
   my ($result, $fault, $class_name, $isarray) = @_;
   my $response = SoapResponse->new;
   if ($fault) {
      my $soap_faut = new SoapFault($fault);      
      $response->fault($soap_faut);      
   } elsif ($result) {
      if ($isarray) {
         my @return_array;
         foreach (@$result) {
            if ($class_name) {
               my $obj = $class_name->deserialize($_);
               push @return_array, $obj;
            } else {
               if ($_) {
                  push @return_array, $_->textContent;
               }
            }
         }
         $response->result(\@return_array);
      } else {
         if ($class_name) {
            $response->result($class_name->deserialize(shift @$result));     
         } else {
            my $node = shift @$result;
            if ($node) {
               $response->result($node->textContent);
            }
         }
      } 
   } else {
      # void return      
   }
   return $response;
}

sub get_arg_string {   
    my ($arg, $arg_name, $expected_type) = @_;
    my $arg_string = "";

    if ($expected_type) {
        # complex type                  
        my $arg_type = ref $arg;                  
        if ($arg_type &&
            $arg_type->isa("ViewBase") &&
            $expected_type eq 'ManagedObjectReference') {
            # views can be passed off as MoRef
            $arg_type = 'ManagedObjectReference';
        }
        if (! $arg_type || ! $arg_type->isa($expected_type)) {
            Carp::confess("Expected $expected_type for '$arg_name' argument.");
        }                  
        if ($arg_type ne $expected_type) {
            #
            # $arg must be of derived type of $expected_type, better emit type then.
            #
            $arg_string = $arg->serialize($arg_name, $arg_type);
        } else {
            $arg_string = $arg->serialize($arg_name);
        }
    } else {
        # primitive
        $arg_string = "<$arg_name>" . XmlUtil::escape_xml_string($arg) . "</$arg_name>";
    }

    return $arg_string;
}

sub build_arg_string {   
   my ($arg_list, $arg_hash) = @_;
   my $arg_string;
   foreach (@$arg_list) {
      my ($arg_name, $type_name) = @$_;
      if (exists($arg_hash->{$arg_name})) {
         my $arg_value = ($arg_hash->{$arg_name});
         my $refName = ref $arg_value;         
         if ($refName eq 'ARRAY') {
            foreach (@$arg_value) {
               $arg_string .= get_arg_string($_, $arg_name, $type_name);
            }
         } elsif (defined($arg_value)) {
            $arg_string .= get_arg_string($arg_value, $arg_name, $type_name);
         }
         delete $arg_hash->{$arg_name};
      }
   }
   my @leftover = keys %$arg_hash;
   if (@leftover > 0) {
      Carp::confess("Unexpected arguments: @leftover");
   }
   return $arg_string;
}

sub DestroyPropertyFilter {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DestroyPropertyFilter', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateFilter {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'PropertyFilterSpec'],['partialUpdates', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateFilter', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RetrieveProperties {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['specSet', 'PropertyFilterSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveProperties', $arg_string);
   return deserialize_response($result, $fault, 'ObjectContent', 1);
}

sub CheckForUpdates {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['version', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CheckForUpdates', $arg_string);
   return deserialize_response($result, $fault, 'UpdateSet', 0);
}

sub WaitForUpdates {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['version', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('WaitForUpdates', $arg_string);
   return deserialize_response($result, $fault, 'UpdateSet', 0);
}

sub CancelWaitForUpdates {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CancelWaitForUpdates', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddAuthorizationRole {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['privIds', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddAuthorizationRole', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveAuthorizationRole {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['roleId', undef],['failIfUsed', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveAuthorizationRole', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateAuthorizationRole {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['roleId', undef],['newName', undef],['privIds', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateAuthorizationRole', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub MergePermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['srcRoleId', undef],['dstRoleId', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MergePermissions', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RetrieveRolePermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['roleId', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveRolePermissions', $arg_string);
   return deserialize_response($result, $fault, 'Permission', 1);
}

sub RetrieveEntityPermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['inherited', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveEntityPermissions', $arg_string);
   return deserialize_response($result, $fault, 'Permission', 1);
}

sub RetrieveAllPermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveAllPermissions', $arg_string);
   return deserialize_response($result, $fault, 'Permission', 1);
}

sub SetEntityPermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['permission', 'Permission'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetEntityPermissions', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ResetEntityPermissions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['permission', 'Permission'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ResetEntityPermissions', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveEntityPermission {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['user', undef],['isGroup', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveEntityPermission', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReconfigureCluster_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'ClusterConfigSpec'],['modify', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureCluster_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ApplyRecommendation {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['key', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ApplyRecommendation', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RecommendHostsForVm {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vm', 'ManagedObjectReference'],['pool', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RecommendHostsForVm', $arg_string);
   return deserialize_response($result, $fault, 'ClusterHostRecommendation', 1);
}

sub AddHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'HostConnectSpec'],['asConnected', undef],['resourcePool', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub MoveInto_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MoveInto_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub MoveHostInto_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['resourcePool', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MoveHostInto_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub AddCustomFieldDef {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddCustomFieldDef', $arg_string);
   return deserialize_response($result, $fault, 'CustomFieldDef', 0);
}

sub RemoveCustomFieldDef {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['key', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveCustomFieldDef', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RenameCustomFieldDef {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['key', undef],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RenameCustomFieldDef', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub SetField {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['key', undef],['value', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetField', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DoesCustomizationSpecExist {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DoesCustomizationSpecExist', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub GetCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('GetCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, 'CustomizationSpecItem', 0);
}

sub CreateCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['item', 'CustomizationSpecItem'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub OverwriteCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['item', 'CustomizationSpecItem'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('OverwriteCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DeleteCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DeleteCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DuplicateCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['newName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DuplicateCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RenameCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['newName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RenameCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CustomizationSpecItemToXml {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['item', 'CustomizationSpecItem'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CustomizationSpecItemToXml', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub XmlToCustomizationSpecItem {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['specItemXml', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('XmlToCustomizationSpecItem', $arg_string);
   return deserialize_response($result, $fault, 'CustomizationSpecItem', 0);
}

sub CheckCustomizationResources {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['guestOs', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CheckCustomizationResources', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryConnectionInfo {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['hostname', undef],['port', undef],['username', undef],['password', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryConnectionInfo', $arg_string);
   return deserialize_response($result, $fault, 'HostConnectInfo', 0);
}

sub RenameDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['newName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RenameDatastore', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RefreshDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RefreshDatastore', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DestroyDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DestroyDatastore', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryDescriptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryDescriptions', $arg_string);
   return deserialize_response($result, $fault, 'DiagnosticManagerLogDescriptor', 1);
}

sub BrowseDiagnosticLog {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['key', undef],['start', undef],['lines', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('BrowseDiagnosticLog', $arg_string);
   return deserialize_response($result, $fault, 'DiagnosticManagerLogHeader', 0);
}

sub GenerateLogBundles_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['includeDefault', undef],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('GenerateLogBundles_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub QueryConfigOptionDescriptor {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryConfigOptionDescriptor', $arg_string);
   return deserialize_response($result, $fault, 'VirtualMachineConfigOptionDescriptor', 1);
}

sub QueryConfigOption {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['key', undef],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryConfigOption', $arg_string);
   return deserialize_response($result, $fault, 'VirtualMachineConfigOption', 0);
}

sub QueryConfigTarget {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryConfigTarget', $arg_string);
   return deserialize_response($result, $fault, 'ConfigTarget', 0);
}

sub CreateFolder {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateFolder', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub MoveIntoFolder_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['list', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MoveIntoFolder_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CreateVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'VirtualMachineConfigSpec'],['pool', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RegisterVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['path', undef],['name', undef],['asTemplate', undef],['pool', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RegisterVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CreateCluster {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['spec', 'ClusterConfigSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateCluster', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub AddStandaloneHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'HostConnectSpec'],['addConnected', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddStandaloneHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CreateDatacenter {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateDatacenter', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub UnregisterAndDestroy_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UnregisterAndDestroy_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub SetCollectorPageSize {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['maxCount', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetCollectorPageSize', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RewindCollector {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RewindCollector', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ResetCollector {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ResetCollector', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DestroyCollector {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DestroyCollector', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryHostConnectionInfo {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryHostConnectionInfo', $arg_string);
   return deserialize_response($result, $fault, 'HostConnectInfo', 0);
}

sub UpdateSystemResources {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['resourceInfo', 'HostSystemResourceInfo'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateSystemResources', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReconnectHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['cnxSpec', 'HostConnectSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconnectHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub DisconnectHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DisconnectHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub EnterMaintenanceMode_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['timeout', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('EnterMaintenanceMode_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ExitMaintenanceMode_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['timeout', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ExitMaintenanceMode_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RebootHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['force', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RebootHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ShutdownHost_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['force', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ShutdownHost_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub QueryMemoryOverhead {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['memorySize', undef],['videoRamSize', undef],['numVcpus', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryMemoryOverhead', $arg_string);
   return deserialize_response($result, $fault, 'long', 0);
}

sub ReconfigureHostForDAS_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureHostForDAS_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub QueryLicenseSourceAvailability {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryLicenseSourceAvailability', $arg_string);
   return deserialize_response($result, $fault, 'LicenseAvailabilityInfo', 1);
}

sub QueryLicenseUsage {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryLicenseUsage', $arg_string);
   return deserialize_response($result, $fault, 'LicenseUsageInfo', 0);
}

sub SetLicenseEdition {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['featureKey', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetLicenseEdition', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CheckLicenseFeature {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['featureKey', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CheckLicenseFeature', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub EnableFeature {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['featureKey', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('EnableFeature', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DisableFeature {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['featureKey', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DisableFeature', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ConfigureLicenseSource {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['licenseSource', 'LicenseSource'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ConfigureLicenseSource', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub Reload {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('Reload', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub Rename_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['newName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('Rename_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub Destroy_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('Destroy_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub DestroyNetwork {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DestroyNetwork', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryPerfProviderSummary {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPerfProviderSummary', $arg_string);
   return deserialize_response($result, $fault, 'PerfProviderSummary', 0);
}

sub QueryAvailablePerfMetric {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['beginTime', undef],['endTime', undef],['intervalId', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryAvailablePerfMetric', $arg_string);
   return deserialize_response($result, $fault, 'PerfMetricId', 1);
}

sub QueryPerfCounter {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['counterId', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPerfCounter', $arg_string);
   return deserialize_response($result, $fault, 'PerfCounterInfo', 1);
}

sub QueryPerf {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['querySpec', 'PerfQuerySpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPerf', $arg_string);
   return deserialize_response($result, $fault, 'PerfEntityMetricBase', 1);
}

sub QueryPerfComposite {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['querySpec', 'PerfQuerySpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPerfComposite', $arg_string);
   return deserialize_response($result, $fault, 'PerfCompositeMetric', 0);
}

sub CreatePerfInterval {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['intervalId', 'PerfInterval'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreatePerfInterval', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemovePerfInterval {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['samplePeriod', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemovePerfInterval', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdatePerfInterval {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['interval', 'PerfInterval'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdatePerfInterval', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['config', 'ResourceConfigSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub MoveIntoResourcePool {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['list', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MoveIntoResourcePool', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateChildResourceConfiguration {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'ResourceConfigSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateChildResourceConfiguration', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateResourcePool {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['spec', 'ResourceConfigSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateResourcePool', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub DestroyChildren {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DestroyChildren', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub FindByUuid {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datacenter', 'ManagedObjectReference'],['uuid', undef],['vmSearch', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindByUuid', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub FindByDatastorePath {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datacenter', 'ManagedObjectReference'],['path', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindByDatastorePath', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub FindByDnsName {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datacenter', 'ManagedObjectReference'],['dnsName', undef],['vmSearch', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindByDnsName', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub FindByIp {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datacenter', 'ManagedObjectReference'],['ip', undef],['vmSearch', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindByIp', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub FindByInventoryPath {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['inventoryPath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindByInventoryPath', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub FindChild {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FindChild', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CurrentTime {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CurrentTime', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RetrieveServiceContent {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveServiceContent', $arg_string);
   return deserialize_response($result, $fault, 'ServiceContent', 0);
}

sub ValidateMigration {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vm', 'ManagedObjectReference'],['state', 'VirtualMachinePowerState'],['testType', undef],['pool', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ValidateMigration', $arg_string);
   return deserialize_response($result, $fault, 'Event', 1);
}

sub QueryVMotionCompatibility {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vm', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['compatibility', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryVMotionCompatibility', $arg_string);
   return deserialize_response($result, $fault, 'HostVMotionCompatibility', 1);
}

sub UpdateServiceMessage {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['message', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateServiceMessage', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub Login {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['userName', undef],['password', undef],['locale', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('Login', $arg_string);
   return deserialize_response($result, $fault, 'UserSession', 0);
}

sub Logout {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('Logout', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AcquireLocalTicket {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['userName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AcquireLocalTicket', $arg_string);
   return deserialize_response($result, $fault, 'SessionManagerLocalTicket', 0);
}

sub TerminateSession {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['sessionId', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('TerminateSession', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub SetLocale {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['locale', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetLocale', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CancelTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CancelTask', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReadNextTasks {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['maxCount', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReadNextTasks', $arg_string);
   return deserialize_response($result, $fault, 'TaskInfo', 1);
}

sub ReadPreviousTasks {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['maxCount', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReadPreviousTasks', $arg_string);
   return deserialize_response($result, $fault, 'TaskInfo', 1);
}

sub CreateCollectorForTasks {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['filter', 'TaskFilterSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateCollectorForTasks', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RetrieveUserGroups {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['domain', undef],['searchStr', undef],['belongsToGroup', undef],['belongsToUser', undef],['exactMatch', undef],['findUsers', undef],['findGroups', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveUserGroups', $arg_string);
   return deserialize_response($result, $fault, 'UserSearchResult', 1);
}

sub CreateSnapshot_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['description', undef],['memory', undef],['quiesce', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateSnapshot_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RevertToCurrentSnapshot_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RevertToCurrentSnapshot_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RemoveAllSnapshots_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveAllSnapshots_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ReconfigVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'VirtualMachineConfigSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub UpgradeVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['version', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpgradeVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub PowerOnVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('PowerOnVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub PowerOffVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('PowerOffVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub SuspendVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SuspendVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ResetVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ResetVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub ShutdownGuest {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ShutdownGuest', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RebootGuest {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RebootGuest', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub StandbyGuest {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('StandbyGuest', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AnswerVM {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['questionId', undef],['answerChoice', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AnswerVM', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CustomizeVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'CustomizationSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CustomizeVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CheckCustomizationSpec {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'CustomizationSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CheckCustomizationSpec', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub MigrateVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pool', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],['priority', 'VirtualMachineMovePriority'],['state', 'VirtualMachinePowerState'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MigrateVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RelocateVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'VirtualMachineRelocateSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RelocateVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CloneVM_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['folder', 'ManagedObjectReference'],['name', undef],['spec', 'VirtualMachineCloneSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CloneVM_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub MarkAsTemplate {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MarkAsTemplate', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub MarkAsVirtualMachine {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pool', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MarkAsVirtualMachine', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UnregisterVM {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UnregisterVM', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ResetGuestInformation {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ResetGuestInformation', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub MountToolsInstaller {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('MountToolsInstaller', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UnmountToolsInstaller {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UnmountToolsInstaller', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpgradeTools_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['installerOptions', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpgradeTools_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub AcquireMksTicket {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AcquireMksTicket', $arg_string);
   return deserialize_response($result, $fault, 'VirtualMachineMksTicket', 0);
}

sub SetScreenResolution {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['width', undef],['height', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetScreenResolution', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveAlarm {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveAlarm', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReconfigureAlarm {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'AlarmSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureAlarm', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateAlarm {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['spec', 'AlarmSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateAlarm', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub GetAlarm {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('GetAlarm', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 1);
}

sub GetAlarmState {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('GetAlarmState', $arg_string);
   return deserialize_response($result, $fault, 'AlarmState', 1);
}

sub ReadNextEvents {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['maxCount', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReadNextEvents', $arg_string);
   return deserialize_response($result, $fault, 'Event', 1);
}

sub ReadPreviousEvents {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['maxCount', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReadPreviousEvents', $arg_string);
   return deserialize_response($result, $fault, 'Event', 1);
}

sub CreateCollectorForEvents {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['filter', 'EventFilterSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateCollectorForEvents', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub LogUserEvent {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['msg', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('LogUserEvent', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryEvents {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['filter', 'EventFilterSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryEvents', $arg_string);
   return deserialize_response($result, $fault, 'Event', 1);
}

sub ReconfigureAutostart {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'HostAutoStartManagerConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureAutostart', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AutoStartPowerOn {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AutoStartPowerOn', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AutoStartPowerOff {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AutoStartPowerOff', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub EnableHyperThreading {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('EnableHyperThreading', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DisableHyperThreading {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DisableHyperThreading', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub SearchDatastore_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastorePath', undef],['searchSpec', 'HostDatastoreBrowserSearchSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SearchDatastore_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub SearchDatastoreSubFolders_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastorePath', undef],['searchSpec', 'HostDatastoreBrowserSearchSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SearchDatastoreSubFolders_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub DeleteFile {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastorePath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DeleteFile', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryAvailableDisksForVmfs {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastore', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryAvailableDisksForVmfs', $arg_string);
   return deserialize_response($result, $fault, 'HostScsiDisk', 1);
}

sub QueryVmfsDatastoreCreateOptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['devicePath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryVmfsDatastoreCreateOptions', $arg_string);
   return deserialize_response($result, $fault, 'VmfsDatastoreOption', 1);
}

sub CreateVmfsDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'VmfsDatastoreCreateSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateVmfsDatastore', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub QueryVmfsDatastoreExtendOptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastore', 'ManagedObjectReference'],['devicePath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryVmfsDatastoreExtendOptions', $arg_string);
   return deserialize_response($result, $fault, 'VmfsDatastoreOption', 1);
}

sub ExtendVmfsDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastore', 'ManagedObjectReference'],['spec', 'VmfsDatastoreExtendSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ExtendVmfsDatastore', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CreateNasDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'HostNasVolumeSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateNasDatastore', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub CreateLocalDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['path', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateLocalDatastore', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RemoveDatastore {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['datastore', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveDatastore', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ConfigureDatastorePrincipal {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['userName', undef],['password', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ConfigureDatastorePrincipal', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryAvailablePartition {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryAvailablePartition', $arg_string);
   return deserialize_response($result, $fault, 'HostDiagnosticPartition', 1);
}

sub SelectActivePartition {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['partition', 'HostScsiDiskPartition'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SelectActivePartition', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryPartitionCreateOptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['storageType', undef],['diagnosticType', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPartitionCreateOptions', $arg_string);
   return deserialize_response($result, $fault, 'HostDiagnosticPartitionCreateOption', 1);
}

sub QueryPartitionCreateDesc {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['diskUuid', undef],['diagnosticType', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryPartitionCreateDesc', $arg_string);
   return deserialize_response($result, $fault, 'HostDiagnosticPartitionCreateDescription', 0);
}

sub CreateDiagnosticPartition {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'HostDiagnosticPartitionCreateSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateDiagnosticPartition', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RenewLease {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RenewLease', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReleaseLease {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReleaseLease', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateDefaultPolicy {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['defaultPolicy', 'HostFirewallDefaultPolicy'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateDefaultPolicy', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub EnableRuleset {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('EnableRuleset', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DisableRuleset {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DisableRuleset', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RefreshFirewall {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RefreshFirewall', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateUser {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['user', 'HostAccountSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateUser', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateUser {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['user', 'HostAccountSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateUser', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['group', 'HostAccountSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveUser {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['userName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveUser', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['groupName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AssignUserToGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['user', undef],['group', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AssignUserToGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UnassignUserFromGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['user', undef],['group', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UnassignUserFromGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReconfigureServiceConsoleReservation {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['cfgBytes', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureServiceConsoleReservation', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateNetworkConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'HostNetworkConfig'],['changeMode', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateNetworkConfig', $arg_string);
   return deserialize_response($result, $fault, 'HostNetworkConfigResult', 0);
}

sub UpdateDnsConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'HostDnsConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateDnsConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateIpRouteConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'HostIpRouteConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateIpRouteConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateConsoleIpRouteConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'HostIpRouteConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateConsoleIpRouteConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddVirtualSwitch {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vswitchName', undef],['spec', 'HostVirtualSwitchSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddVirtualSwitch', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveVirtualSwitch {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vswitchName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveVirtualSwitch', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateVirtualSwitch {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vswitchName', undef],['spec', 'HostVirtualSwitchSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateVirtualSwitch', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddPortGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['portgrp', 'HostPortGroupSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddPortGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemovePortGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pgName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemovePortGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdatePortGroup {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pgName', undef],['portgrp', 'HostPortGroupSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdatePortGroup', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdatePhysicalNicLinkSpeed {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],['linkSpeed', 'PhysicalNicLinkInfo'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdatePhysicalNicLinkSpeed', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryNetworkHint {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryNetworkHint', $arg_string);
   return deserialize_response($result, $fault, 'PhysicalNicHintInfo', 1);
}

sub AddVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['portgroup', undef],['nic', 'HostVirtualNicSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],['nic', 'HostVirtualNicSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['portgroup', undef],['nic', 'HostVirtualNicSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddServiceConsoleVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveServiceConsoleVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],['nic', 'HostVirtualNicSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateServiceConsoleVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RestartServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RestartServiceConsoleVirtualNic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RefreshNetworkSystem {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RefreshNetworkSystem', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateServicePolicy {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],['policy', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateServicePolicy', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub StartService {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('StartService', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub StopService {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('StopService', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RestartService {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RestartService', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UninstallService {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['id', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UninstallService', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RefreshServices {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RefreshServices', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CheckIfMasterSnmpAgentRunning {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CheckIfMasterSnmpAgentRunning', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateSnmpConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['config', 'HostSnmpConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateSnmpConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RestartMasterSnmpAgent {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RestartMasterSnmpAgent', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub StopMasterSnmpAgent {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('StopMasterSnmpAgent', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RetrieveDiskPartitionInfo {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['devicePath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveDiskPartitionInfo', $arg_string);
   return deserialize_response($result, $fault, 'HostDiskPartitionInfo', 1);
}

sub ComputeDiskPartitionInfo {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['devicePath', undef],['layout', 'HostDiskPartitionLayout'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ComputeDiskPartitionInfo', $arg_string);
   return deserialize_response($result, $fault, 'HostDiskPartitionInfo', 0);
}

sub UpdateDiskPartitions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['devicePath', undef],['spec', 'HostDiskPartitionSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateDiskPartitions', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub FormatVmfs {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['createSpec', 'HostVmfsSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('FormatVmfs', $arg_string);
   return deserialize_response($result, $fault, 'HostVmfsVolume', 0);
}

sub RescanVmfs {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RescanVmfs', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AttachVmfsExtent {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vmfsPath', undef],['extent', 'HostScsiDiskPartition'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AttachVmfsExtent', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpgradeVmfs {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['vmfsPath', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpgradeVmfs', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpgradeVmLayout {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpgradeVmLayout', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RescanHba {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['hbaDevice', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RescanHba', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RescanAllHba {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RescanAllHba', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateSoftwareInternetScsiEnabled {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['enabled', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateSoftwareInternetScsiEnabled', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateInternetScsiDiscoveryProperties {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['discoveryProperties', 'HostInternetScsiHbaDiscoveryProperties'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateInternetScsiDiscoveryProperties', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateInternetScsiAuthenticationProperties {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['authenticationProperties', 'HostInternetScsiHbaAuthenticationProperties'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateInternetScsiAuthenticationProperties', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateInternetScsiIPProperties {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['ipProperties', 'HostInternetScsiHbaIPProperties'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateInternetScsiIPProperties', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateInternetScsiName {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['iScsiName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateInternetScsiName', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateInternetScsiAlias {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['iScsiAlias', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateInternetScsiAlias', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddInternetScsiSendTargets {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['targets', 'HostInternetScsiHbaSendTarget'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddInternetScsiSendTargets', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveInternetScsiSendTargets {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['targets', 'HostInternetScsiHbaSendTarget'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveInternetScsiSendTargets', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub AddInternetScsiStaticTargets {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['targets', 'HostInternetScsiHbaStaticTarget'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('AddInternetScsiStaticTargets', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveInternetScsiStaticTargets {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['iScsiHbaDevice', undef],['targets', 'HostInternetScsiHbaStaticTarget'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveInternetScsiStaticTargets', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub EnableMultipathPath {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pathName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('EnableMultipathPath', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DisableMultipathPath {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['pathName', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DisableMultipathPath', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub SetMultipathLunPolicy {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['lunId', undef],['policy', 'HostMultipathInfoLogicalUnitPolicy'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SetMultipathLunPolicy', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RefreshStorageSystem {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RefreshStorageSystem', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub UpdateIpConfig {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['ipConfig', 'HostIpConfig'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateIpConfig', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub SelectVnic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['device', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('SelectVnic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub DeselectVnic {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('DeselectVnic', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub QueryOptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('QueryOptions', $arg_string);
   return deserialize_response($result, $fault, 'OptionValue', 1);
}

sub UpdateOptions {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['changedValue', 'OptionValue'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('UpdateOptions', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RemoveScheduledTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveScheduledTask', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub ReconfigureScheduledTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['spec', 'ScheduledTaskSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('ReconfigureScheduledTask', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub RunScheduledTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RunScheduledTask', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}

sub CreateScheduledTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],['spec', 'ScheduledTaskSpec'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('CreateScheduledTask', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RetrieveEntityScheduledTask {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['entity', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RetrieveEntityScheduledTask', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 1);
}

sub RevertToSnapshot_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['host', 'ManagedObjectReference'],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RevertToSnapshot_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RemoveSnapshot_Task {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['removeChildren', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RemoveSnapshot_Task', $arg_string);
   return deserialize_response($result, $fault, 'ManagedObjectReference', 0);
}

sub RenameSnapshot {
   my ($self, %args) = @_;
   my $vim_soap = $self->{vim_soap};
   my @arg_list = (['_this', 'ManagedObjectReference'],['name', undef],['description', undef],);
   my $arg_string = build_arg_string(\@arg_list, \%args);
   my ($result, $fault) = $vim_soap->request('RenameSnapshot', $arg_string);
   return deserialize_response($result, $fault, undef, 0);
}



1;
###################################################################


__END__
=head1 NAME

VMware::VIStub - Perl binding for VMware Infrastructure API

=head1 SYNOPSIS

  use VMware::VIStub;

  # service object
  my $vim_service = VimService->new('https://<host>/sdk');

  # get service content
  my $mo = ManagedObjectReference->new(type => 'ServiceInstance', value => 'ServiceInstance');
  my $service_content = $vim_service->RetrieveServiceContent(_this => $mo)->result;
  

=head1 DESCRIPTION

This module provides Perl binding for VMware Infrastructure API.  It provides type
and operation definitions as specified by the VMware Infrastructure API.
For detailed documentation, refer to reference guide in VI SDK distribution
downloadable at <http://www.vmware.com/download/sdk/>


=head1 SEE ALSO

VI Perl Toolkit Guide is available at ./doc/guide.html in module package.

VI API Programming guide and reference guide is available for download at
<http://www.vmware.com/download/sdk/>


=head1 COPYRIGHT AND LICENSE


The Original Software is licensed under the CDDL v. 1.0 only and cannot 
be distributed or otherwise made available under any subsequent version 
of the license.  This License hall be governed by and construed in 
accordance with the laws of the State of California, excluding its 
conflict-of-law provisions.  Any litigation relating to this License 
will be brought solely in the federal court in the Northern District 
of California or the state court in the County of Santa Clara.  

A copy of the CDDL license is included in this distribution.


Copyright (c) 2006, VMware, Inc.  All rights not expressly granted herein 
are reserved. 

=cut

