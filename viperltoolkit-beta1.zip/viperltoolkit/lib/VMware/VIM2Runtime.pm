#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use 5.006001;
use strict;
use warnings;

use VMware::VIM2Stub;
use Carp qw(confess);


##################################################################################
package Util;

sub check_fault {
   my $result = shift;
   if ($result->fault) {
      die $result->fault;
   }   
   return $result->result;
}

1;
##################################################################################


##################################################################################
package Vim;
use Data::Dumper;

our $vim_global = undef;

sub new {
   my ($class, %args) = @_;
   my $self = {};
   bless $self, $class;
   if (! defined $args{service_url}) {
      Carp::confess("service_url argument missing");
   }
   $self->{service_url} = $args{service_url};
   return $self;
}

sub login {
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      # object reference 
      my ($self, %args) = @_;
      my $service_url = $self->{service_url};
      my $user_name = $args{user_name};
      my $password = $args{password};
      my $si_moref = ManagedObjectReference->new(type => 'ServiceInstance',
                                                 value => 'ServiceInstance');
      $self->{vim_service} = VimService->new($service_url);
      my $sc = Util::check_fault($self->{vim_service}->RetrieveServiceContent(_this => $si_moref));
      Util::check_fault($self->{vim_service}->Login(_this => $sc->sessionManager,
                                                    userName => $user_name,
                                                   password => $password));
      $self->{service_content} = $sc;
   } else {
      my %args = @_;
      my $service_url = $args{service_url};
      $vim_global = Vim->new(service_url => $service_url);      
      my $user_name = $args{user_name};
      my $password = $args{password};
      $vim_global->login(user_name => $user_name, password => $password);
   }      
}

sub save_session {
   my $self;
   my %args;
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $self = $vim_global;
   }
   $self->{vim_service}->save_session($args{session_file});  
}

sub load_session {
   my $self;
   my %args;   
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $vim_global = Vim->new(service_url => $args{service_url});
      $self = $vim_global;
   }

   my $si_moref = ManagedObjectReference->new(type => 'ServiceInstance',
                                              value => 'ServiceInstance');
   $self->{vim_service} = VimService->new($self->{service_url});
   $self->{vim_service}->load_session($args{session_file});
   my $sc = Util::check_fault($self->{vim_service}->RetrieveServiceContent(_this => $si_moref));
   $self->{service_content} = $sc;   
}

sub get_vim_service {
   my $self;
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      $self = shift;
   } else {
      $self = $vim_global;
   }
   if (defined $self->{vim_service}) {
      return $self->{vim_service};
   } else {
      Carp::confess("Vim uninitialized");
   }
   
}

sub get_service_content {
   my $self;
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      $self = shift;
   } else {
      $self = $vim_global;
   }
   if (defined $self->{service_content}) {
      return $self->{service_content};
   } else {
      Carp::confess("Vim uninitialized");
   }
}

sub find_entity_view {
   my $self = undef;
   my $sc;
   my $service;
   my %args;
 
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $self = $vim_global;
   }
   $service = $self->{vim_service};
   $sc = $self->{service_content};


   if (! exists($args{view_type})) {
      Carp::confess('view_type argument is required');
   }
   my $view_type = $args{view_type};
   delete $args{view_type};
   if (! $view_type->isa('EntityViewBase')) {
      Carp::confess("$view_type is not a ManagedEntity");
   }
   my $properties = "";
   if (exists ($args{properties})) {
      if (defined($args{properties})) {
         $properties = $args{properties};
      }
      delete $args{properties};
   }
   my $begin_entity = $sc->rootFolder;
   if (exists ($args{begin_entity})) {
      $begin_entity = $args{begin_entity};
      delete $args{begin_entity};
   }   
   my $filter = {};
   if (exists ($args{filter})) {
      $filter = $args{filter};
      delete $args{filter};
   }
   my @remaining = keys %args;
   if (@remaining > 0) {
      Carp::confess("Unexpected argument @remaining");
   }
   my $property_spec = PropertySpec->new(all => 0,
                                         type => $view_type->get_backing_type(),
                                         pathSet => [keys %$filter]);
   my $property_filter_spec = 
      $view_type->get_search_filter_spec($begin_entity, [$property_spec]);
   my $obj_contents =
      $service->RetrieveProperties(_this => $sc->propertyCollector,
                                   specSet => $property_filter_spec);   
   my $result = Util::check_fault($obj_contents);   
   my $filtered_obj;
   foreach (@$result) {
      my $obj_content = $_;
      if (keys %$filter == 0) {
         $filtered_obj = $obj_content->obj;
         last;
      }

      my %prop_hash;    
      my $prop_set = $obj_content->propSet;
      if (! $prop_set) {
         next;
      }
      foreach (@$prop_set) {
         $prop_hash{$_->name} = $_->val;
      }
      my $matched = 1;
      foreach (keys %$filter) {
         if (exists ($prop_hash{$_})) {         
            my $regex = $filter->{$_};
            my $val;
            if (ref $prop_hash{$_}) {
               $val = Dumper $prop_hash{$_};
            } else {
               $val = $prop_hash{$_};
            }
            if ($val !~ /$regex/) {
               $matched = 0;
               last;
            }
         }
      }
      if ($matched) {
         $filtered_obj = $obj_content->obj;
      }
   }
   if (! $filtered_obj) {
      return undef;
   } else {
      return $self->get_view(mo_ref => $filtered_obj,
                             view_type => $view_type,
                             properties => $properties);
   }
}

sub find_entity_views {
   my $self = undef;
   my $sc;
   my $service;
   my %args;
    
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $self = $vim_global;
   }
   $service = $self->{vim_service};
   $sc = $self->{service_content};   
   
   if (! exists($args{view_type})) {
      Carp::confess('view_type argument is required');
   }
   my $view_type = $args{view_type};
   delete $args{view_type};
   if (! $view_type->isa('EntityViewBase')) {
      Carp::confess("$view_type is not a ManagedEntity");
   }
   my $begin_entity = $sc->rootFolder;
   if (exists ($args{begin_entity})) {
      $begin_entity = $args{begin_entity};
      delete $args{begin_entity};
   }
   my $filter = {};
   if (exists ($args{filter})) {
      $filter = $args{filter};
      delete $args{filter};
   }
   my $properties = "";
   if (exists ($args{properties})) {
      if (defined($args{properties})) {
         $properties = $args{properties};
      }
      delete $args{properties};
   }
   my @remaining = keys %args;
   if (@remaining > 0) {
      Carp::confess("Unexpected argument @remaining");
   }   
   my $property_spec = PropertySpec->new(all => 0,
                                         type => $view_type->get_backing_type(),
                                         pathSet => [keys %$filter]);
   my $property_filter_spec = 
      $view_type->get_search_filter_spec($begin_entity, [$property_spec]);
   my $obj_contents =
      $service->RetrieveProperties(_this => $sc->propertyCollector,
                                   specSet => $property_filter_spec);   
   my $result = Util::check_fault($obj_contents);   
   my @filtered_objs;
   foreach (@$result) {
      my $obj_content = $_;
      if (keys %$filter == 0) {
         push @filtered_objs, $obj_content->obj;
         next;
      }

      my %prop_hash;    
      my $prop_set = $obj_content->propSet;
      if (! $prop_set) {
         next;
      }
      foreach (@$prop_set) {
         $prop_hash{$_->name} = $_->val;
      }
      my $matched = 1;
      foreach (keys %$filter) {
         if (exists ($prop_hash{$_})) {         
            my $regex = $filter->{$_};
            my $val;
            if (ref $prop_hash{$_}) {
               my $class = ref $prop_hash{$_};
               if ($class->isa("SimpleType")) {
                  $val = $prop_hash{$_}->val();
               } else {
                  $val = Dumper $prop_hash{$_};
               }
            } else {
               $val = $prop_hash{$_};
            }
            if ($val !~ /$regex/) {
               $matched = 0;
               last;
            }
         }
      }
      if ($matched) {
         push @filtered_objs, $obj_content->obj;
      }
   }
   if (! @filtered_objs) {
      return [];
   } else {
      return $self->get_views(mo_ref_array => \@filtered_objs,
                              view_type => $view_type,
                              properties => $properties);
   }   
}

sub get_view {
   my %args;   
   my $self = undef;
   my $service;
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $self = $vim_global;
   }
   $service = $self->{vim_service};
   
   if (! exists($args{mo_ref})) {
      Carp::confess("mo_ref argument is required");
   }
   my $moref = $args{mo_ref};
   my $view_type = $moref->type;
   if (exists ($args{view_type})) {
      $view_type = $args{view_type};
   }
   my $properties = "";
   if (exists($args{properties}) && 
       defined($args{properties}) && 
       $args{properties} ne "") {
      $properties = $args{properties};
   }
   my $view = $view_type->new($moref, $self);
   $view->update_view_data($properties);
   return $view;
}


sub get_views {
   my %args;   
   my $self = undef;
   my $service;
   my $sc;
   my ($first_arg) = @_;
   if ($first_arg && ref $first_arg eq 'Vim') {
      ($self, %args) = @_;
   } else {
      %args = @_;
      $self = $vim_global;
   }
   $service = $self->{vim_service};
   $sc = $self->{service_content};

   if (! exists($args{mo_ref_array})) {
      Carp::confess("mo_ref_array argument is required");
   }
   my $morefs = $args{mo_ref_array};
   if (!defined($morefs) ||(@$morefs == 0)) {
      # Map an empty list of morefs to an empty list of views
      return [];
   }
   my $moref = @$morefs[0];
   my $view_type = $moref->type;
   if (exists ($args{view_type})) {
      $view_type = $args{view_type};
   }
     
   my $property_spec = $view_type->get_property_spec();
   my @object_specs;
   foreach (@$morefs) {
      push @object_specs, ObjectSpec->new(obj => $_);
   }
   my $prop_filter_spec = PropertyFilterSpec->new(propSet => $property_spec,
                                                  objectSet => \@object_specs);

   my $propertyCollector = $sc->propertyCollector;

   my $properties = "";
   if (exists($args{properties}) && 
       defined($args{properties}) && 
       $args{properties} ne "") {
      $properties = $args{properties};
      my $ptr = $prop_filter_spec->propSet;
      my $obj = $$ptr[0];
      $obj->all(0);  
      $obj->pathSet ($args{properties});
   }

   my $obj_contents =
      $service->RetrieveProperties(_this => $propertyCollector,
                                   specSet => $prop_filter_spec);
   Util::check_fault($obj_contents);
   my @views;
   foreach (@{$obj_contents->result}) {
      my $view = $view_type->new($_->obj, $self);
      $view->set_view_data($_, $properties);
      push @views, $view;
   }
   return \@views;
}


sub logout {
   my ($first_arg) = @_;
   my $self;
   if ($first_arg && ref $first_arg eq 'Vim') {
      $self = $first_arg;
   } else {
      $self = $vim_global;
   }   
   $self->{vim_service}->Logout(_this => $self->{service_content}->sessionManager);
}

1;
##################################################################################



##################################################################################
package ViewBase;

sub new {
   my ($class, $moref, $vim) = @_;
   if (! $moref) {
      Carp::confess("Missing required mo_ref argument");
   }
   my $self = { mo_ref => $moref,
                vim => $vim };
   bless $self, $class;
}

sub serialize {
   my ($self, $tag) = @_;
   my $moref = $self->{mo_ref};
   return $moref->serialize($tag);   
}

sub get_backing_type {
   my $class = shift;
   return $class;
}

sub get_property_spec {
   my $class = shift;
   return [PropertySpec->new(all => 1,
                             type => $class)];
}

sub get_property_filter_spec {
   my ($class, $moref) = @_;
   my $property_spec = $class->get_property_spec();
   my $object_spec = ObjectSpec->new(obj => $moref);
   return PropertyFilterSpec->new(propSet => $property_spec,
                                  objectSet => [ $object_spec ]);   
}

sub update_view_data {
   my $self = shift;
   my $properties = shift;
   my $service = $self->{vim}->get_vim_service();
   my $property_filter_spec = (ref $self)->get_property_filter_spec($self->{mo_ref});
   my $propertyCollector = $self->{vim}->get_service_content()->propertyCollector;
   if ($properties ne "") {
      my $ptr = $property_filter_spec->propSet;
      my $obj = $$ptr[0];
      $obj->all(0);  
      $obj->pathSet ($properties);
   }
   my $obj_contents =
      $service->RetrieveProperties(_this => $propertyCollector,
                                   specSet => $property_filter_spec);
   Util::check_fault($obj_contents);
   foreach (@{$obj_contents->result}) {
      $self->set_view_data($_, $properties);
   }
}

sub set_view_data {
   my ($self, $obj_content, $properties) = @_;
   my $prop_set = $obj_content->propSet;
   foreach (@$prop_set) {
      my $name = $_->name;
      if ($properties eq "") {
         my @path_elements = split /\./, $name;
         $name = pop @path_elements;
      }
      $self->{$name} = $_->val;
   }
}


sub invoke {
   my ($self, $method, %args) = @_;
   my $runtime = $self->{vim}->get_vim_service();
   my $moref = $self->{mo_ref};
   if (! $moref) {
      Carp::confess("Required mo_ref argument not found");
   }
   $runtime->$method(_this => $moref, %args);
}

sub get_property {
   my ($self, $path) = @_;
   my @subpaths = ();
   my $val;
   while ($path) {
      if (exists $self->{$path}) {
         $val = $self->{$path};
         last;
      } elsif ($path =~ /^(.+)\.([^.]+)$/) {
         $path = $1;
         unshift @subpaths, $2;
      }
   }
   if (defined($val)) {
      foreach (@subpaths) {
         $val = $val->{$_};
      }
   }
   return $val;
}

sub waitForTask {
   my ($self, $task_ref) = @_;
   my $task_view = $self->{vim}->get_view(mo_ref => $task_ref);
   while (1) {
      my $info = $task_view->info;
      if ($info->state->val eq 'success') {
         return $info->result;
      } elsif ($info->state->val eq 'error') {
         my $soap_fault = SoapFault->new;
         $soap_fault->detail($info->error->fault);
         $soap_fault->fault_string($info->error->localizedMessage);
         die $soap_fault;
      }
      sleep 2;
      $task_view->update_view_data();
   }
}

1;
##################################################################################


##################################################################################
package EntityViewBase;
our @ISA = qw(ViewBase);

sub get_search_filter_spec {   
   my ($class, $moref, $property_spec) = @_;
   my $resourcePoolTraversalSpec =
      TraversalSpec->new(name => 'resourcePoolTraversalSpec',
                         type => 'ResourcePool',
                         path => 'resourcePool',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => 'resourcePoolTraversalSpec'),
                                       SelectionSpec->new(name => 'resourcePoolVmTraversalSpec')]);      

   my $resourcePoolVmTraversalSpec =
      TraversalSpec->new(name => 'resourcePoolVmTraversalSpec',
                         type => 'ResourcePool',
                         path => 'vm',
                         skip => 0);   

   my $computeResourceRpTraversalSpec =
      TraversalSpec->new(name => 'computeResourceRpTraversalSpec',
                         type => 'ComputeResource',
                         path => 'resourcePool',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => 'resourcePoolTraversalSpec'),
                                       SelectionSpec->new(name => 'resourcePoolVmTraversalSpec')]);      
      
   
   my $computeResourceHostTraversalSpec =
      TraversalSpec->new(name => 'computeResourceHostTraversalSpec',
                         type => 'ComputeResource',
                         path => 'host',
                         skip => 0);
         
   my $datacenterHostTraversalSpec =
      TraversalSpec->new(name => 'datacenterHostTraversalSpec',
                         type => 'Datacenter',
                         path => 'hostFolder',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => "folderTraversalSpec")]);
   
   my $datacenterVmTraversalSpec =
      TraversalSpec->new(name => 'datacenterVmTraversalSpec',
                         type => 'Datacenter',
                         path => 'vmFolder',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => "folderTraversalSpec")]);

   my $hostVmTraversalSpec =
      TraversalSpec->new(name => 'hostVmTraversalSpec',
                         type => 'HostSystem',
                         path => 'vm',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => "folderTraversalSpec")]);
      
   my $folderTraversalSpec =
      TraversalSpec->new(name => 'folderTraversalSpec',
                         type => 'Folder',
                         path => 'childEntity',
                         skip => 0,
                         selectSet => [SelectionSpec->new(name => 'folderTraversalSpec'),
                                       SelectionSpec->new(name => 'datacenterHostTraversalSpec'),
                                       SelectionSpec->new(name => 'datacenterVmTraversalSpec',),
                                       SelectionSpec->new(name => 'computeResourceRpTraversalSpec'),
                                       SelectionSpec->new(name => 'computeResourceHostTraversalSpec'),
                                       SelectionSpec->new(name => 'hostVmTraversalSpec'),
                                       SelectionSpec->new(name => 'resourcePoolVmTraversalSpec'),
                                       ]);
   
   my $obj_spec = ObjectSpec->new(obj => $moref,
                                  skip => 0,
                                  selectSet => [$folderTraversalSpec,
                                                $datacenterVmTraversalSpec,
                                                $datacenterHostTraversalSpec,
                                                $computeResourceHostTraversalSpec,
                                                $computeResourceRpTraversalSpec,
                                                $resourcePoolTraversalSpec,
                                                $hostVmTraversalSpec,
                                                $resourcePoolVmTraversalSpec]);
   
   return PropertyFilterSpec->new(propSet => $property_spec,
                                  objectSet => [$obj_spec]);
}

sub get_task_collector_view {
   my ($self, $recursion_option, %args) = @_;
   my $task_filter_spec = TaskFilterSpec->new;
   if (exists $args{filter}) {
      $task_filter_spec = $args{task_filter_spec};
   }
   $task_filter_spec->entity(
      TaskFilterSpecByEntity->new(entity => $self->{mo_ref},
                                  recursion => TaskFilterSpecRecursionOption->new($recursion_option)));
   my $task_mgr_view = $self->{vim}->get_view(mo_ref => $self->{vim}->get_service_content()->taskManager);
   my $task_collector = $task_mgr_view->CreateCollectorForTasks(filter => $task_filter_spec);
   return $self->{vim}->get_view(mo_ref => $task_collector);   
}

sub get_entity_only_tasks_collector_view {
   my ($self, %args) = @_;
   return $self->get_task_collector_view('self', %args);
}

sub get_all_tasks_view {
   my ($self, %args) = @_;
   return $self->get_task_collector_view('all', %args);   
}

sub get_event_collector_view {
   my ($self, $recursion_option, %args) = @_;
   my $event_filter_spec = EventFilterSpec->new;
   if (exists $args{filter}) {
      $event_filter_spec = $args{filter};
   }
   $event_filter_spec->entity(
      EventFilterSpecByEntity->new(entity => $self->{mo_ref},
                                   recursion => EventFilterSpecRecursionOption->new($recursion_option)));
   my $event_mgr_view = $self->{vim}->get_view(mo_ref => $self->{vim}->get_service_content()->eventManager);
   my $event_collector = $event_mgr_view->CreateCollectorForEvents(filter => $event_filter_spec);
   return $self->{vim}->get_view(mo_ref => $event_collector);
}

sub get_entity_only_events_view {
   my ($self, %args) = @_;
   $self->get_event_collector_view('self', %args);
}

sub get_all_events_view {
   my ($self, %args) = @_;
   $self->get_event_collector_view('all', %args);
}


1;
##################################################################################



##################################################################################
package HostMemorySystem;
our @ISA = qw(ViewBase HostMemorySystemOperations);
use Class::MethodMaker  [ scalar => [qw(consoleReservationInfo)] ];


1;
##################################################################################

##################################################################################
package Datacenter;
our @ISA = qw(ManagedEntity DatacenterOperations);
use Class::MethodMaker  [ scalar => [qw(vmFolder hostFolder datastore network)] ];


1;
##################################################################################

##################################################################################
package Folder;
our @ISA = qw(ManagedEntity FolderOperations);
use Class::MethodMaker  [ scalar => [qw(childType childEntity)] ];


1;
##################################################################################

##################################################################################
package CustomFieldsManager;
our @ISA = qw(ViewBase CustomFieldsManagerOperations);
use Class::MethodMaker  [ scalar => [qw(field)] ];


1;
##################################################################################

##################################################################################
package DiagnosticManager;
our @ISA = qw(ViewBase DiagnosticManagerOperations);

1;
##################################################################################

##################################################################################
package HostDatastoreBrowser;
our @ISA = qw(ViewBase HostDatastoreBrowserOperations);
use Class::MethodMaker  [ scalar => [qw(datastore supportedType)] ];


1;
##################################################################################

##################################################################################
package Task;
our @ISA = qw(ViewBase TaskOperations);
use Class::MethodMaker  [ scalar => [qw(info)] ];


1;
##################################################################################

##################################################################################
package VirtualMachineSnapshot;
our @ISA = qw(ViewBase VirtualMachineSnapshotOperations);
use Class::MethodMaker  [ scalar => [qw(config)] ];


1;
##################################################################################

##################################################################################
package HostSnmpSystem;
our @ISA = qw(ViewBase HostSnmpSystemOperations);
use Class::MethodMaker  [ scalar => [qw(snmpConfig)] ];


1;
##################################################################################

##################################################################################
package HostSystem;
our @ISA = qw(ManagedEntity HostSystemOperations);
use Class::MethodMaker  [ scalar => [qw(runtime summary hardware capability configManager config vm datastore network datastoreBrowser systemResources)] ];


1;
##################################################################################

##################################################################################
package HostVMotionSystem;
our @ISA = qw(ViewBase HostVMotionSystemOperations);
use Class::MethodMaker  [ scalar => [qw(netConfig ipConfig)] ];


1;
##################################################################################

##################################################################################
package ScheduledTask;
our @ISA = qw(ViewBase ScheduledTaskOperations);
use Class::MethodMaker  [ scalar => [qw(info)] ];


1;
##################################################################################

##################################################################################
package PropertyCollector;
our @ISA = qw(ViewBase PropertyCollectorOperations);
use Class::MethodMaker  [ scalar => [qw(filter)] ];


1;
##################################################################################

##################################################################################
package HostServiceSystem;
our @ISA = qw(ViewBase HostServiceSystemOperations);
use Class::MethodMaker  [ scalar => [qw(serviceInfo)] ];


1;
##################################################################################

##################################################################################
package LicenseManager;
our @ISA = qw(ViewBase LicenseManagerOperations);
use Class::MethodMaker  [ scalar => [qw(source sourceAvailable featureInfo)] ];


1;
##################################################################################

##################################################################################
package Datastore;
our @ISA = qw(ViewBase DatastoreOperations);
use Class::MethodMaker  [ scalar => [qw(info summary host vm browser capability)] ];


1;
##################################################################################

##################################################################################
package HostAutoStartManager;
our @ISA = qw(ViewBase HostAutoStartManagerOperations);
use Class::MethodMaker  [ scalar => [qw(config)] ];


1;
##################################################################################

##################################################################################
package VirtualMachine;
our @ISA = qw(ManagedEntity VirtualMachineOperations);
use Class::MethodMaker  [ scalar => [qw(capability config layout environmentBrowser resourcePool resourceConfig runtime guest summary datastore network snapshot guestHeartbeatStatus)] ];


1;
##################################################################################

##################################################################################
package HostStorageSystem;
our @ISA = qw(ViewBase HostStorageSystemOperations);
use Class::MethodMaker  [ scalar => [qw(storageDeviceInfo fileSystemVolumeInfo)] ];


1;
##################################################################################

##################################################################################
package EnvironmentBrowser;
our @ISA = qw(ViewBase EnvironmentBrowserOperations);
use Class::MethodMaker  [ scalar => [qw(datastoreBrowser)] ];


1;
##################################################################################

##################################################################################
package EventManager;
our @ISA = qw(ViewBase EventManagerOperations);
use Class::MethodMaker  [ scalar => [qw(description latestEvent maxCollector)] ];


1;
##################################################################################

##################################################################################
package ScheduledTaskManager;
our @ISA = qw(ViewBase ScheduledTaskManagerOperations);
use Class::MethodMaker  [ scalar => [qw(scheduledTask description)] ];


1;
##################################################################################

##################################################################################
package ClusterComputeResource;
our @ISA = qw(ComputeResource ClusterComputeResourceOperations);
use Class::MethodMaker  [ scalar => [qw(configuration drsRecommendation migrationHistory)] ];


1;
##################################################################################

##################################################################################
package HostCpuSchedulerSystem;
our @ISA = qw(ViewBase HostCpuSchedulerSystemOperations);
use Class::MethodMaker  [ scalar => [qw(hyperthreadInfo)] ];


1;
##################################################################################

##################################################################################
package ResourcePool;
our @ISA = qw(ManagedEntity ResourcePoolOperations);
use Class::MethodMaker  [ scalar => [qw(summary runtime owner resourcePool vm config childConfiguration)] ];


1;
##################################################################################

##################################################################################
package HostDiskManagerLease;
our @ISA = qw(ViewBase HostDiskManagerLeaseOperations);

1;
##################################################################################

##################################################################################
package TaskHistoryCollector;
our @ISA = qw(HistoryCollector TaskHistoryCollectorOperations);
use Class::MethodMaker  [ scalar => [qw(latestPage)] ];


1;
##################################################################################

##################################################################################
package ServiceInstance;
our @ISA = qw(ViewBase ServiceInstanceOperations);
use Class::MethodMaker  [ scalar => [qw(serverClock capability content)] ];


1;
##################################################################################

##################################################################################
package PerformanceManager;
our @ISA = qw(ViewBase PerformanceManagerOperations);
use Class::MethodMaker  [ scalar => [qw(description historicalInterval perfCounter)] ];


1;
##################################################################################

##################################################################################
package EventHistoryCollector;
our @ISA = qw(HistoryCollector EventHistoryCollectorOperations);
use Class::MethodMaker  [ scalar => [qw(latestPage)] ];


1;
##################################################################################

##################################################################################
package PropertyFilter;
our @ISA = qw(ViewBase PropertyFilterOperations);
use Class::MethodMaker  [ scalar => [qw(spec partialUpdates)] ];


1;
##################################################################################

##################################################################################
package HostFirewallSystem;
our @ISA = qw(ViewBase HostFirewallSystemOperations);
use Class::MethodMaker  [ scalar => [qw(firewallInfo)] ];


1;
##################################################################################

##################################################################################
package HostDiagnosticSystem;
our @ISA = qw(ViewBase HostDiagnosticSystemOperations);
use Class::MethodMaker  [ scalar => [qw(activePartition)] ];


1;
##################################################################################

##################################################################################
package CustomizationSpecManager;
our @ISA = qw(ViewBase CustomizationSpecManagerOperations);
use Class::MethodMaker  [ scalar => [qw(info encryptionKey)] ];


1;
##################################################################################

##################################################################################
package ComputeResource;
our @ISA = qw(ManagedEntity ComputeResourceOperations);
use Class::MethodMaker  [ scalar => [qw(resourcePool host datastore network summary environmentBrowser)] ];


1;
##################################################################################

##################################################################################
package UserDirectory;
our @ISA = qw(ViewBase UserDirectoryOperations);
use Class::MethodMaker  [ scalar => [qw(domainList)] ];


1;
##################################################################################

##################################################################################
package HostNetworkSystem;
our @ISA = qw(ViewBase HostNetworkSystemOperations);
use Class::MethodMaker  [ scalar => [qw(capabilities networkInfo offloadCapabilities networkConfig dnsConfig ipRouteConfig consoleIpRouteConfig)] ];


1;
##################################################################################

##################################################################################
package Network;
our @ISA = qw(ViewBase NetworkOperations);
use Class::MethodMaker  [ scalar => [qw(name summary host vm)] ];


1;
##################################################################################

##################################################################################
package AlarmManager;
our @ISA = qw(ViewBase AlarmManagerOperations);
use Class::MethodMaker  [ scalar => [qw(defaultExpression description)] ];


1;
##################################################################################

##################################################################################
package Alarm;
our @ISA = qw(ViewBase AlarmOperations);
use Class::MethodMaker  [ scalar => [qw(info)] ];


1;
##################################################################################

##################################################################################
package HistoryCollector;
our @ISA = qw(ViewBase HistoryCollectorOperations);
use Class::MethodMaker  [ scalar => [qw(filter)] ];


1;
##################################################################################

##################################################################################
package OptionManager;
our @ISA = qw(ViewBase OptionManagerOperations);
use Class::MethodMaker  [ scalar => [qw(supportedOption setting)] ];


1;
##################################################################################

##################################################################################
package TaskManager;
our @ISA = qw(ViewBase TaskManagerOperations);
use Class::MethodMaker  [ scalar => [qw(recentTask description maxCollector)] ];


1;
##################################################################################

##################################################################################
package AuthorizationManager;
our @ISA = qw(ViewBase AuthorizationManagerOperations);
use Class::MethodMaker  [ scalar => [qw(privilegeList roleList description)] ];


1;
##################################################################################

##################################################################################
package HostDatastoreSystem;
our @ISA = qw(ViewBase HostDatastoreSystemOperations);
use Class::MethodMaker  [ scalar => [qw(datastore)] ];


1;
##################################################################################

##################################################################################
package HostLocalAccountManager;
our @ISA = qw(ViewBase HostLocalAccountManagerOperations);

1;
##################################################################################

##################################################################################
package SessionManager;
our @ISA = qw(ViewBase SessionManagerOperations);
use Class::MethodMaker  [ scalar => [qw(sessionList currentSession message messageLocaleList supportedLocaleList defaultLocale)] ];


1;
##################################################################################

##################################################################################
package SearchIndex;
our @ISA = qw(ViewBase SearchIndexOperations);

1;
##################################################################################

##################################################################################
package ManagedEntity;
our @ISA = qw(EntityViewBase);
use Class::MethodMaker  [ scalar => [qw(parent customValue overallStatus configStatus configIssue effectiveRole permission name disabledMethod recentTask declaredAlarmState triggeredAlarmState)] ];


1;
##################################################################################

##################################################################################
package HostMemorySystemOperations;
sub ReconfigureServiceConsoleReservation {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureServiceConsoleReservation', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package DatacenterOperations;
our @ISA = qw(ManagedEntityOperations);
sub QueryConnectionInfo {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryConnectionInfo', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package FolderOperations;
our @ISA = qw(ManagedEntityOperations);
sub CreateFolder {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateFolder', %args));
   return $response
}

sub MoveIntoFolder_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MoveIntoFolder_Task', %args));
   return $response
}

sub MoveIntoFolder {
   my ($self, %args) = @_;
   return $self->waitForTask($self->MoveIntoFolder_Task(%args));
}

sub CreateVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateVM_Task', %args));
   return $response
}

sub CreateVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->CreateVM_Task(%args));
}

sub RegisterVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RegisterVM_Task', %args));
   return $response
}

sub RegisterVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RegisterVM_Task(%args));
}

sub CreateCluster {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateCluster', %args));
   return $response
}

sub AddStandaloneHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddStandaloneHost_Task', %args));
   return $response
}

sub AddStandaloneHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->AddStandaloneHost_Task(%args));
}

sub CreateDatacenter {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateDatacenter', %args));
   return $response
}

sub UnregisterAndDestroy_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UnregisterAndDestroy_Task', %args));
   return $response
}

sub UnregisterAndDestroy {
   my ($self, %args) = @_;
   return $self->waitForTask($self->UnregisterAndDestroy_Task(%args));
}


1;
##################################################################################

##################################################################################
package CustomFieldsManagerOperations;
sub AddCustomFieldDef {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddCustomFieldDef', %args));
   return $response
}

sub RemoveCustomFieldDef {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveCustomFieldDef', %args));
   return $response
}

sub RenameCustomFieldDef {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RenameCustomFieldDef', %args));
   return $response
}

sub SetField {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetField', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package DiagnosticManagerOperations;
sub QueryDescriptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryDescriptions', %args));
   return $response
}

sub BrowseDiagnosticLog {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('BrowseDiagnosticLog', %args));
   return $response
}

sub GenerateLogBundles_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('GenerateLogBundles_Task', %args));
   return $response
}

sub GenerateLogBundles {
   my ($self, %args) = @_;
   return $self->waitForTask($self->GenerateLogBundles_Task(%args));
}


1;
##################################################################################

##################################################################################
package HostDatastoreBrowserOperations;
sub SearchDatastore_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SearchDatastore_Task', %args));
   return $response
}

sub SearchDatastore {
   my ($self, %args) = @_;
   return $self->waitForTask($self->SearchDatastore_Task(%args));
}

sub SearchDatastoreSubFolders_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SearchDatastoreSubFolders_Task', %args));
   return $response
}

sub SearchDatastoreSubFolders {
   my ($self, %args) = @_;
   return $self->waitForTask($self->SearchDatastoreSubFolders_Task(%args));
}

sub DeleteFile {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DeleteFile', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package TaskOperations;
sub CancelTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CancelTask', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package VirtualMachineSnapshotOperations;
sub RevertToSnapshot_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RevertToSnapshot_Task', %args));
   return $response
}

sub RevertToSnapshot {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RevertToSnapshot_Task(%args));
}

sub RemoveSnapshot_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveSnapshot_Task', %args));
   return $response
}

sub RemoveSnapshot {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RemoveSnapshot_Task(%args));
}

sub RenameSnapshot {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RenameSnapshot', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostSnmpSystemOperations;
sub CheckIfMasterSnmpAgentRunning {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CheckIfMasterSnmpAgentRunning', %args));
   return $response
}

sub UpdateSnmpConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateSnmpConfig', %args));
   return $response
}

sub RestartMasterSnmpAgent {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RestartMasterSnmpAgent', %args));
   return $response
}

sub StopMasterSnmpAgent {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('StopMasterSnmpAgent', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostSystemOperations;
our @ISA = qw(ManagedEntityOperations);
sub QueryHostConnectionInfo {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryHostConnectionInfo', %args));
   return $response
}

sub UpdateSystemResources {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateSystemResources', %args));
   return $response
}

sub ReconnectHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconnectHost_Task', %args));
   return $response
}

sub ReconnectHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ReconnectHost_Task(%args));
}

sub DisconnectHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DisconnectHost_Task', %args));
   return $response
}

sub DisconnectHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->DisconnectHost_Task(%args));
}

sub EnterMaintenanceMode_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('EnterMaintenanceMode_Task', %args));
   return $response
}

sub EnterMaintenanceMode {
   my ($self, %args) = @_;
   return $self->waitForTask($self->EnterMaintenanceMode_Task(%args));
}

sub ExitMaintenanceMode_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ExitMaintenanceMode_Task', %args));
   return $response
}

sub ExitMaintenanceMode {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ExitMaintenanceMode_Task(%args));
}

sub RebootHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RebootHost_Task', %args));
   return $response
}

sub RebootHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RebootHost_Task(%args));
}

sub ShutdownHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ShutdownHost_Task', %args));
   return $response
}

sub ShutdownHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ShutdownHost_Task(%args));
}

sub QueryMemoryOverhead {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryMemoryOverhead', %args));
   return $response
}

sub ReconfigureHostForDAS_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureHostForDAS_Task', %args));
   return $response
}

sub ReconfigureHostForDAS {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ReconfigureHostForDAS_Task(%args));
}


1;
##################################################################################

##################################################################################
package HostVMotionSystemOperations;
sub UpdateIpConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateIpConfig', %args));
   return $response
}

sub SelectVnic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SelectVnic', %args));
   return $response
}

sub DeselectVnic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DeselectVnic', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ScheduledTaskOperations;
sub RemoveScheduledTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveScheduledTask', %args));
   return $response
}

sub ReconfigureScheduledTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureScheduledTask', %args));
   return $response
}

sub RunScheduledTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RunScheduledTask', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package PropertyCollectorOperations;
sub CreateFilter {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateFilter', %args));
   return $response
}

sub RetrieveProperties {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveProperties', %args));
   return $response
}

sub CheckForUpdates {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CheckForUpdates', %args));
   return $response
}

sub WaitForUpdates {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('WaitForUpdates', %args));
   return $response
}

sub CancelWaitForUpdates {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CancelWaitForUpdates', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostServiceSystemOperations;
sub UpdateServicePolicy {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateServicePolicy', %args));
   return $response
}

sub StartService {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('StartService', %args));
   return $response
}

sub StopService {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('StopService', %args));
   return $response
}

sub RestartService {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RestartService', %args));
   return $response
}

sub UninstallService {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UninstallService', %args));
   return $response
}

sub RefreshServices {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RefreshServices', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package LicenseManagerOperations;
sub QueryLicenseSourceAvailability {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryLicenseSourceAvailability', %args));
   return $response
}

sub QueryLicenseUsage {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryLicenseUsage', %args));
   return $response
}

sub SetLicenseEdition {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetLicenseEdition', %args));
   return $response
}

sub CheckLicenseFeature {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CheckLicenseFeature', %args));
   return $response
}

sub EnableFeature {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('EnableFeature', %args));
   return $response
}

sub DisableFeature {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DisableFeature', %args));
   return $response
}

sub ConfigureLicenseSource {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ConfigureLicenseSource', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package DatastoreOperations;
sub RenameDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RenameDatastore', %args));
   return $response
}

sub RefreshDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RefreshDatastore', %args));
   return $response
}

sub DestroyDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DestroyDatastore', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostAutoStartManagerOperations;
sub ReconfigureAutostart {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureAutostart', %args));
   return $response
}

sub AutoStartPowerOn {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AutoStartPowerOn', %args));
   return $response
}

sub AutoStartPowerOff {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AutoStartPowerOff', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package VirtualMachineOperations;
our @ISA = qw(ManagedEntityOperations);
sub CreateSnapshot_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateSnapshot_Task', %args));
   return $response
}

sub CreateSnapshot {
   my ($self, %args) = @_;
   return $self->waitForTask($self->CreateSnapshot_Task(%args));
}

sub RevertToCurrentSnapshot_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RevertToCurrentSnapshot_Task', %args));
   return $response
}

sub RevertToCurrentSnapshot {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RevertToCurrentSnapshot_Task(%args));
}

sub RemoveAllSnapshots_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveAllSnapshots_Task', %args));
   return $response
}

sub RemoveAllSnapshots {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RemoveAllSnapshots_Task(%args));
}

sub ReconfigVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigVM_Task', %args));
   return $response
}

sub ReconfigVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ReconfigVM_Task(%args));
}

sub UpgradeVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpgradeVM_Task', %args));
   return $response
}

sub UpgradeVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->UpgradeVM_Task(%args));
}

sub PowerOnVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('PowerOnVM_Task', %args));
   return $response
}

sub PowerOnVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->PowerOnVM_Task(%args));
}

sub PowerOffVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('PowerOffVM_Task', %args));
   return $response
}

sub PowerOffVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->PowerOffVM_Task(%args));
}

sub SuspendVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SuspendVM_Task', %args));
   return $response
}

sub SuspendVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->SuspendVM_Task(%args));
}

sub ResetVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ResetVM_Task', %args));
   return $response
}

sub ResetVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ResetVM_Task(%args));
}

sub ShutdownGuest {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ShutdownGuest', %args));
   return $response
}

sub RebootGuest {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RebootGuest', %args));
   return $response
}

sub StandbyGuest {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('StandbyGuest', %args));
   return $response
}

sub AnswerVM {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AnswerVM', %args));
   return $response
}

sub CustomizeVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CustomizeVM_Task', %args));
   return $response
}

sub CustomizeVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->CustomizeVM_Task(%args));
}

sub CheckCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CheckCustomizationSpec', %args));
   return $response
}

sub MigrateVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MigrateVM_Task', %args));
   return $response
}

sub MigrateVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->MigrateVM_Task(%args));
}

sub RelocateVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RelocateVM_Task', %args));
   return $response
}

sub RelocateVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->RelocateVM_Task(%args));
}

sub CloneVM_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CloneVM_Task', %args));
   return $response
}

sub CloneVM {
   my ($self, %args) = @_;
   return $self->waitForTask($self->CloneVM_Task(%args));
}

sub MarkAsTemplate {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MarkAsTemplate', %args));
   return $response
}

sub MarkAsVirtualMachine {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MarkAsVirtualMachine', %args));
   return $response
}

sub UnregisterVM {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UnregisterVM', %args));
   return $response
}

sub ResetGuestInformation {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ResetGuestInformation', %args));
   return $response
}

sub MountToolsInstaller {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MountToolsInstaller', %args));
   return $response
}

sub UnmountToolsInstaller {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UnmountToolsInstaller', %args));
   return $response
}

sub UpgradeTools_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpgradeTools_Task', %args));
   return $response
}

sub UpgradeTools {
   my ($self, %args) = @_;
   return $self->waitForTask($self->UpgradeTools_Task(%args));
}

sub AcquireMksTicket {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AcquireMksTicket', %args));
   return $response
}

sub SetScreenResolution {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetScreenResolution', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostStorageSystemOperations;
sub RetrieveDiskPartitionInfo {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveDiskPartitionInfo', %args));
   return $response
}

sub ComputeDiskPartitionInfo {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ComputeDiskPartitionInfo', %args));
   return $response
}

sub UpdateDiskPartitions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateDiskPartitions', %args));
   return $response
}

sub FormatVmfs {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FormatVmfs', %args));
   return $response
}

sub RescanVmfs {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RescanVmfs', %args));
   return $response
}

sub AttachVmfsExtent {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AttachVmfsExtent', %args));
   return $response
}

sub UpgradeVmfs {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpgradeVmfs', %args));
   return $response
}

sub UpgradeVmLayout {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpgradeVmLayout', %args));
   return $response
}

sub RescanHba {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RescanHba', %args));
   return $response
}

sub RescanAllHba {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RescanAllHba', %args));
   return $response
}

sub UpdateSoftwareInternetScsiEnabled {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateSoftwareInternetScsiEnabled', %args));
   return $response
}

sub UpdateInternetScsiDiscoveryProperties {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateInternetScsiDiscoveryProperties', %args));
   return $response
}

sub UpdateInternetScsiAuthenticationProperties {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateInternetScsiAuthenticationProperties', %args));
   return $response
}

sub UpdateInternetScsiIPProperties {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateInternetScsiIPProperties', %args));
   return $response
}

sub UpdateInternetScsiName {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateInternetScsiName', %args));
   return $response
}

sub UpdateInternetScsiAlias {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateInternetScsiAlias', %args));
   return $response
}

sub AddInternetScsiSendTargets {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddInternetScsiSendTargets', %args));
   return $response
}

sub RemoveInternetScsiSendTargets {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveInternetScsiSendTargets', %args));
   return $response
}

sub AddInternetScsiStaticTargets {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddInternetScsiStaticTargets', %args));
   return $response
}

sub RemoveInternetScsiStaticTargets {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveInternetScsiStaticTargets', %args));
   return $response
}

sub EnableMultipathPath {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('EnableMultipathPath', %args));
   return $response
}

sub DisableMultipathPath {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DisableMultipathPath', %args));
   return $response
}

sub SetMultipathLunPolicy {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetMultipathLunPolicy', %args));
   return $response
}

sub RefreshStorageSystem {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RefreshStorageSystem', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package EnvironmentBrowserOperations;
sub QueryConfigOptionDescriptor {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryConfigOptionDescriptor', %args));
   return $response
}

sub QueryConfigOption {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryConfigOption', %args));
   return $response
}

sub QueryConfigTarget {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryConfigTarget', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package EventManagerOperations;
sub CreateCollectorForEvents {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateCollectorForEvents', %args));
   return $response
}

sub LogUserEvent {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('LogUserEvent', %args));
   return $response
}

sub QueryEvents {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryEvents', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ScheduledTaskManagerOperations;
sub CreateScheduledTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateScheduledTask', %args));
   return $response
}

sub RetrieveEntityScheduledTask {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveEntityScheduledTask', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ClusterComputeResourceOperations;
our @ISA = qw(ComputeResourceOperations);
sub ReconfigureCluster_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureCluster_Task', %args));
   return $response
}

sub ReconfigureCluster {
   my ($self, %args) = @_;
   return $self->waitForTask($self->ReconfigureCluster_Task(%args));
}

sub ApplyRecommendation {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ApplyRecommendation', %args));
   return $response
}

sub RecommendHostsForVm {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RecommendHostsForVm', %args));
   return $response
}

sub AddHost_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddHost_Task', %args));
   return $response
}

sub AddHost {
   my ($self, %args) = @_;
   return $self->waitForTask($self->AddHost_Task(%args));
}

sub MoveInto_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MoveInto_Task', %args));
   return $response
}

sub MoveInto {
   my ($self, %args) = @_;
   return $self->waitForTask($self->MoveInto_Task(%args));
}

sub MoveHostInto_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MoveHostInto_Task', %args));
   return $response
}

sub MoveHostInto {
   my ($self, %args) = @_;
   return $self->waitForTask($self->MoveHostInto_Task(%args));
}


1;
##################################################################################

##################################################################################
package HostCpuSchedulerSystemOperations;
sub EnableHyperThreading {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('EnableHyperThreading', %args));
   return $response
}

sub DisableHyperThreading {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DisableHyperThreading', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ResourcePoolOperations;
our @ISA = qw(ManagedEntityOperations);
sub UpdateConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateConfig', %args));
   return $response
}

sub MoveIntoResourcePool {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MoveIntoResourcePool', %args));
   return $response
}

sub UpdateChildResourceConfiguration {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateChildResourceConfiguration', %args));
   return $response
}

sub CreateResourcePool {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateResourcePool', %args));
   return $response
}

sub DestroyChildren {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DestroyChildren', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostDiskManagerLeaseOperations;
sub RenewLease {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RenewLease', %args));
   return $response
}

sub ReleaseLease {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReleaseLease', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package TaskHistoryCollectorOperations;
our @ISA = qw(HistoryCollectorOperations);
sub ReadNextTasks {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReadNextTasks', %args));
   return $response
}

sub ReadPreviousTasks {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReadPreviousTasks', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ServiceInstanceOperations;
sub CurrentTime {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CurrentTime', %args));
   return $response
}

sub RetrieveServiceContent {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveServiceContent', %args));
   return $response
}

sub ValidateMigration {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ValidateMigration', %args));
   return $response
}

sub QueryVMotionCompatibility {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryVMotionCompatibility', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package PerformanceManagerOperations;
sub QueryPerfProviderSummary {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPerfProviderSummary', %args));
   return $response
}

sub QueryAvailablePerfMetric {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryAvailablePerfMetric', %args));
   return $response
}

sub QueryPerfCounter {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPerfCounter', %args));
   return $response
}

sub QueryPerf {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPerf', %args));
   return $response
}

sub QueryPerfComposite {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPerfComposite', %args));
   return $response
}

sub CreatePerfInterval {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreatePerfInterval', %args));
   return $response
}

sub RemovePerfInterval {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemovePerfInterval', %args));
   return $response
}

sub UpdatePerfInterval {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdatePerfInterval', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package EventHistoryCollectorOperations;
our @ISA = qw(HistoryCollectorOperations);
sub ReadNextEvents {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReadNextEvents', %args));
   return $response
}

sub ReadPreviousEvents {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReadPreviousEvents', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package PropertyFilterOperations;
sub DestroyPropertyFilter {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DestroyPropertyFilter', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostFirewallSystemOperations;
sub UpdateDefaultPolicy {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateDefaultPolicy', %args));
   return $response
}

sub EnableRuleset {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('EnableRuleset', %args));
   return $response
}

sub DisableRuleset {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DisableRuleset', %args));
   return $response
}

sub RefreshFirewall {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RefreshFirewall', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostDiagnosticSystemOperations;
sub QueryAvailablePartition {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryAvailablePartition', %args));
   return $response
}

sub SelectActivePartition {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SelectActivePartition', %args));
   return $response
}

sub QueryPartitionCreateOptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPartitionCreateOptions', %args));
   return $response
}

sub QueryPartitionCreateDesc {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryPartitionCreateDesc', %args));
   return $response
}

sub CreateDiagnosticPartition {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateDiagnosticPartition', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package CustomizationSpecManagerOperations;
sub DoesCustomizationSpecExist {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DoesCustomizationSpecExist', %args));
   return $response
}

sub GetCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('GetCustomizationSpec', %args));
   return $response
}

sub CreateCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateCustomizationSpec', %args));
   return $response
}

sub OverwriteCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('OverwriteCustomizationSpec', %args));
   return $response
}

sub DeleteCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DeleteCustomizationSpec', %args));
   return $response
}

sub DuplicateCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DuplicateCustomizationSpec', %args));
   return $response
}

sub RenameCustomizationSpec {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RenameCustomizationSpec', %args));
   return $response
}

sub CustomizationSpecItemToXml {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CustomizationSpecItemToXml', %args));
   return $response
}

sub XmlToCustomizationSpecItem {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('XmlToCustomizationSpecItem', %args));
   return $response
}

sub CheckCustomizationResources {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CheckCustomizationResources', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ComputeResourceOperations;
our @ISA = qw(ManagedEntityOperations);

1;
##################################################################################

##################################################################################
package UserDirectoryOperations;
sub RetrieveUserGroups {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveUserGroups', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostNetworkSystemOperations;
sub UpdateNetworkConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateNetworkConfig', %args));
   return $response
}

sub UpdateDnsConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateDnsConfig', %args));
   return $response
}

sub UpdateIpRouteConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateIpRouteConfig', %args));
   return $response
}

sub UpdateConsoleIpRouteConfig {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateConsoleIpRouteConfig', %args));
   return $response
}

sub AddVirtualSwitch {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddVirtualSwitch', %args));
   return $response
}

sub RemoveVirtualSwitch {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveVirtualSwitch', %args));
   return $response
}

sub UpdateVirtualSwitch {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateVirtualSwitch', %args));
   return $response
}

sub AddPortGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddPortGroup', %args));
   return $response
}

sub RemovePortGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemovePortGroup', %args));
   return $response
}

sub UpdatePortGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdatePortGroup', %args));
   return $response
}

sub UpdatePhysicalNicLinkSpeed {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdatePhysicalNicLinkSpeed', %args));
   return $response
}

sub QueryNetworkHint {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryNetworkHint', %args));
   return $response
}

sub AddVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddVirtualNic', %args));
   return $response
}

sub RemoveVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveVirtualNic', %args));
   return $response
}

sub UpdateVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateVirtualNic', %args));
   return $response
}

sub AddServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddServiceConsoleVirtualNic', %args));
   return $response
}

sub RemoveServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveServiceConsoleVirtualNic', %args));
   return $response
}

sub UpdateServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateServiceConsoleVirtualNic', %args));
   return $response
}

sub RestartServiceConsoleVirtualNic {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RestartServiceConsoleVirtualNic', %args));
   return $response
}

sub RefreshNetworkSystem {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RefreshNetworkSystem', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package NetworkOperations;
sub DestroyNetwork {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DestroyNetwork', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package AlarmManagerOperations;
sub CreateAlarm {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateAlarm', %args));
   return $response
}

sub GetAlarm {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('GetAlarm', %args));
   return $response
}

sub GetAlarmState {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('GetAlarmState', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package AlarmOperations;
sub RemoveAlarm {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveAlarm', %args));
   return $response
}

sub ReconfigureAlarm {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ReconfigureAlarm', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HistoryCollectorOperations;
sub SetCollectorPageSize {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetCollectorPageSize', %args));
   return $response
}

sub RewindCollector {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RewindCollector', %args));
   return $response
}

sub ResetCollector {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ResetCollector', %args));
   return $response
}

sub DestroyCollector {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('DestroyCollector', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package OptionManagerOperations;
sub QueryOptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryOptions', %args));
   return $response
}

sub UpdateOptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateOptions', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package TaskManagerOperations;
sub CreateCollectorForTasks {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateCollectorForTasks', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package AuthorizationManagerOperations;
sub AddAuthorizationRole {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AddAuthorizationRole', %args));
   return $response
}

sub RemoveAuthorizationRole {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveAuthorizationRole', %args));
   return $response
}

sub UpdateAuthorizationRole {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateAuthorizationRole', %args));
   return $response
}

sub MergePermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('MergePermissions', %args));
   return $response
}

sub RetrieveRolePermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveRolePermissions', %args));
   return $response
}

sub RetrieveEntityPermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveEntityPermissions', %args));
   return $response
}

sub RetrieveAllPermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RetrieveAllPermissions', %args));
   return $response
}

sub SetEntityPermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetEntityPermissions', %args));
   return $response
}

sub ResetEntityPermissions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ResetEntityPermissions', %args));
   return $response
}

sub RemoveEntityPermission {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveEntityPermission', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostDatastoreSystemOperations;
sub QueryAvailableDisksForVmfs {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryAvailableDisksForVmfs', %args));
   return $response
}

sub QueryVmfsDatastoreCreateOptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryVmfsDatastoreCreateOptions', %args));
   return $response
}

sub CreateVmfsDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateVmfsDatastore', %args));
   return $response
}

sub QueryVmfsDatastoreExtendOptions {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('QueryVmfsDatastoreExtendOptions', %args));
   return $response
}

sub ExtendVmfsDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ExtendVmfsDatastore', %args));
   return $response
}

sub CreateNasDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateNasDatastore', %args));
   return $response
}

sub CreateLocalDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateLocalDatastore', %args));
   return $response
}

sub RemoveDatastore {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveDatastore', %args));
   return $response
}

sub ConfigureDatastorePrincipal {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('ConfigureDatastorePrincipal', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package HostLocalAccountManagerOperations;
sub CreateUser {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateUser', %args));
   return $response
}

sub UpdateUser {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateUser', %args));
   return $response
}

sub CreateGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('CreateGroup', %args));
   return $response
}

sub RemoveUser {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveUser', %args));
   return $response
}

sub RemoveGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('RemoveGroup', %args));
   return $response
}

sub AssignUserToGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AssignUserToGroup', %args));
   return $response
}

sub UnassignUserFromGroup {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UnassignUserFromGroup', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package SessionManagerOperations;
sub UpdateServiceMessage {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('UpdateServiceMessage', %args));
   return $response
}

sub Login {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('Login', %args));
   return $response
}

sub Logout {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('Logout', %args));
   return $response
}

sub AcquireLocalTicket {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('AcquireLocalTicket', %args));
   return $response
}

sub TerminateSession {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('TerminateSession', %args));
   return $response
}

sub SetLocale {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('SetLocale', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package SearchIndexOperations;
sub FindByUuid {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindByUuid', %args));
   return $response
}

sub FindByDatastorePath {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindByDatastorePath', %args));
   return $response
}

sub FindByDnsName {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindByDnsName', %args));
   return $response
}

sub FindByIp {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindByIp', %args));
   return $response
}

sub FindByInventoryPath {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindByInventoryPath', %args));
   return $response
}

sub FindChild {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('FindChild', %args));
   return $response
}


1;
##################################################################################

##################################################################################
package ManagedEntityOperations;
sub Reload {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('Reload', %args));
   return $response
}

sub Rename_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('Rename_Task', %args));
   return $response
}

sub Rename {
   my ($self, %args) = @_;
   return $self->waitForTask($self->Rename_Task(%args));
}

sub Destroy_Task {
   my ($self, %args) = @_;
   my $response = Util::check_fault($self->invoke('Destroy_Task', %args));
   return $response
}

sub Destroy {
   my ($self, %args) = @_;
   return $self->waitForTask($self->Destroy_Task(%args));
}


1;
##################################################################################

__END__
=head1 NAME

VMware::VIRuntime - VI Perl Toolkit runtime module

=head1 SYNOPSIS

   use strict;
   use VMware::VIRuntime;

   # login
   Vim::login(service_url => 'https://localhost/sdk/vimService',
              user_name => 'Administrator',
              password => 'mypassword');

   # get 'VirtualMachineView' for all VM's that are poweredOn and is running a Windows guest
   my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                         filter => { 'guest.guestFullName' => '.*Windows.*',
                                                     'runtime.powerState' => 'poweredOn' });

   # snapshot all running / powered on Windows vm's
   foreach (@$vm_views) {
      $_->CreateSnapshot(name => 'nightly backup',
                         description => 'Nightly backup of Windows machines',
                         memory => 0,
                         quiesce => 1);
   }

   # logout
   Vim::logout();
  
=head1 DESCRIPTION

VMware::VIRuntime module provides an interface to discover and interact with
managed objects as specified by VMware Infrastructure API.  The module provides
views that correspond to managed objec type definitions detailed in reference guide
(available for download with SDK package at http://www.vmware.com/download/sdk/).
Managed object views in this runtime module provides access to methods
and properties.

Object discovery is provided through Vim::find_entity_view subroutine
which allows for constraint based search/filtering of inventory objects
based on filter parameter.

This modules also provides synchronous version of methods that return
Task object (methods with '_Task' appended to their names). For example,
PowerOnVM_Task method for VirtualMachine view provides PowerOnVM operation
that blocks until task completion.  

The module is built(depends) on Perl binding for VI API (VMware::VIStub)

=head1 SEE ALSO

VI Perl Toolkit Guide is available at ./doc/guide.html in module package.

VI API Programming guide and reference guide is available for download at
<http://www.vmware.com/download/sdk/>


=head1 COPYRIGHT AND LICENSE

The Original Software is licensed under the CDDL v. 1.0 only and cannot 
be distributed or otherwise made available under any subsequent version 
of the license.  This License hall be governed by and construed in 
accordance with the laws of the State of California, excluding its 
conflict-of-law provisions.  Any litigation relating to this License 
will be brought solely in the federal court in the Northern District 
of California or the state court in the County of Santa Clara.  

A copy of the CDDL license is included in this distribution.


Copyright (c) 2006, VMware, Inc.  All rights not expressly granted herein 
are reserved. 

=cut

