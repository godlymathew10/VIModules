#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use 5.006001;
use strict;
use warnings;
use File::Basename;
use VMware::VIRuntime;


##################################################################################
package Util;
our $tracelevel = 0;
our $script_version;

sub trace {
   my ($level, $text) = @_;
   if ($level <= $tracelevel) {
      print $text;
   }
}

sub connect {
   my $url = Opts::get_option('url');
   if (Opts::option_is_set('sessionfile')) {
      my $sessionfile = Opts::get_option('sessionfile');
      Vim::load_session(service_url => $url, session_file => $sessionfile);
   } elsif (Opts::option_is_set('username') && Opts::option_is_set('password')) {
      my $username = Opts::get_option('username');
      my $password = Opts::get_option('password');
      eval {
         Vim::login(service_url => $url, user_name => $username, password => $password);
        };
      if ($@) {
         my $error = "Error connecting to server at '$url'";
         if ($@ =~ /Connection refused/) {
            die "$error: Connection refused\n";
         } elsif ($@ =~ /Bad hostname/) {
            die "$error: Bad hostname\n";
         } else {
            die "$error:\n$@\n";
         }
      }
   } else {
      print "No session or username/password provided\n";
      return;
   }
}

sub disconnect {
   # Only logout if we established the session
   if (!Opts::option_is_set('sessionfile')) {
      Vim::logout();
   }
}

sub create_entity_info {
   my $objectContent = shift;
   my $propSet = $objectContent->propSet;
   my $name;
   my $parent;
   foreach (@$propSet) {
      if ($_->name eq "name") {
         $name = $_->val;
      } elsif ($_->name eq "parent") {
         $parent = $_->val;
      }
   }
   return { name => $name, parent => $parent };
}

sub get_inventory_path {
   my $entity = shift;
   my $propertyCollector = Vim::get_service_content()->propertyCollector;

   # Retrieve the "name" and "parent" properties for all the managed entities
   # reachable by following "parent" properties starting from $entity.
   my $objectContents = Util::check_fault(
      Vim::get_vim_service()->RetrieveProperties(
	 _this => $propertyCollector,
	 specSet => [
	    PropertyFilterSpec->new(
	       propSet => [
		  PropertySpec->new(
		     type => "ManagedEntity",
		     pathSet => [ "name", "parent" ]
		  )
	       ],
	       objectSet => [
		  ObjectSpec->new(
		     obj => $entity->{mo_ref},
		     selectSet => [
			TraversalSpec->new(
			   name => "ParentTraversalSpec",
			   type => "ManagedEntity",
			   path => "parent",
			   selectSet => [
			      SelectionSpec->new(name => "ParentTraversalSpec") 
			   ]
			)
		     ]
		  )
	       ]
	    )
	 ]
      )
   );

   # Create a hash containing an entry for each manaaged entity retrieved by
   # the RetrieveProperties call above.
   my %entityMap;
   foreach (@$objectContents) {
      my $objectContent = $_;
      if (defined $objectContent->missingSet) {
         die $objectContent->misingSet;
      }
      $entityMap{$objectContent->obj->value} = create_entity_info($objectContent);
   }

   # Use entityMap to walk the "parent" properties of the managed entities,
   # starting with managedEntity, computing the inventory path (from end to
   # beginning) along the way.
   my $current = $entityMap{$entity->{mo_ref}->value};
   my $parent = $current->{parent};
   if (! defined $parent) {
      return "";
   }
   my @path;
   while (1) {
      unshift(@path, $current->{name});
      $current = $entityMap{$parent->value};
      $parent = $current->{parent};
      if (! defined $parent) {
	 last;
      }
   }
   return join "/", @path
}

1;
##################################################################################
package Opts;
use Getopt::Long;

our %options = (
   config => {
      type => "=s",
      variable => "VI_CONFIG",
      help => "Location of the VI Perl configuration file",
      func => \&get_default_config,
   },
   protocol => {
      type => "=s",
      variable => "VI_PROTOCOL",
      help => "Protocol used to connect to server",
      default => "https",
   },
   server => {
      type => "=s",
      variable => "VI_SERVER",
      help => "VI server to connect to",
      default => "localhost",
   },
   portnumber => {
      type => "=s",
      variable => "VI_PORTNUMBER",
      help => "Port used to connect to server",
   },
   servicepath => {
      type => "=s",
      variable => "VI_SERVICEPATH",
      help => "Service path used to connect to server",
      default => "/sdk/webService"
   },
   url => {
      type => "=s",
      variable => "VI_URL",
      help => "VI SDK URL to connect to",
      func => \&get_url,
   },
   # sessionid isn't supported yet because the back-end can't do it             
   #sessionid => {
   #   type => "=s",
   #   variable => "VI_SESSIONID",
   #   help => "Existing session ID/cookie to utilize",
   #},
   sessionfile => {
      type => "=s",
      variable => "VI_SESSIONFILE",
      help => "File containing session ID/cookie to utilize",
   },
   username => {
      type => "=s",
      variable => "VI_USERNAME",
      help => "Username",
   },
   password => {
      type => "=s",
      variable => "VI_PASSWORD",
      help => "Password",
   },
   verbose => {
      type => ":s",
      variable => "VI_VERBOSE",
      help => "Display additional debugging information",
   },
   help => {
      type => "",
      help => "Display usage information for the script",
   },
   version => {
      type => "",
      help => "Display version information for the script",
   },
);

our @builtin_options = keys %options;
our @user_options;

sub add_options {
   my %opts = @_;
   foreach my $key (keys %opts) {
      if (!exists($options{$key})) {
         $options{$key} = $opts{$key};
         push @user_options, $key;
      }
   }
}

sub get_option {
   my ($key) = @_;
   Util::trace(2, "get_option $key\n");
   my $opt = $options{$key};
   if (!defined($opt)) {
      Util::trace(2, "  => unknown option\n");
      return undef;
   } elsif (defined($opt->{value})) {
      Util::trace(2, "  => value = $opt->{value}\n");
      return $opt->{value};
   } elsif (defined($opt->{func})) {
      my $val = $opt->{func}->();
      Util::trace(2, "  => func = " . (defined($val) ? $val : "<undef>") . "\n");
      return $val;
   } elsif (defined($opt->{default})) {
      Util::trace(2, "  => default = $opt->{default}\n");
      return $opt->{default};
   } else {
      Util::trace(2, "  => <undef>\n");
      return undef;
   }
}

sub option_is_set {
   my ($key) = @_;
   Util::trace(2, "option_is_set $key\n");
   my $opt = $options{$key};
   if (!defined($opt)) {
      Util::trace(2, "  => unknown option\n");
      return undef;
   } else {
      Util::trace(2, "  => " . defined($opt->{value}) . "\n");
      return defined($opt->{value});
   }   
}

sub get_url {
   my $protocol = get_option('protocol');
   my $server = get_option('server');
   my $port = get_option('portnumber');
   $port = defined($port) ? ":$port" : "";
   my $path = get_option('servicepath');
   return "${protocol}://${server}${port}${path}";
}

sub get_default_config {
  # XXX Needs more work for non linux platforms...
   if ($^O =~ /Win/) {
      my $home = $ENV{HOME} or $ENV{LOGDIR} or return;
      return $home . "/visdk.rc";
   } else {
      my $home = $ENV{HOME} or $ENV{LOGDIR} or (getpwuid($<))[7] or return;
      return $home . "/.visdkrc";
   }
}

sub print_option {
   my ($key) = @_;
   my $opt = $options{$key};
   my $var = $opt->{variable};
   my $default = $opt->{default};
   my $required = $opt->{required};

   # XXX align columns
   print "   --$key";
   my @info = ();
   if ($required) {
      push @info, "required";
   }
   if (defined($var)) {
      push @info, "variable $var";
   }
   if (defined($default)) {
      push @info, "default '$default'";
   }
   if (@info) {
      print " (" . join(", ", @info) . ")";
   }
   print "\n";
   if (defined($opt->{alias})) {
      my @aliases = split(/\|/, $opt->{alias});
      foreach my $alias (@aliases) {
         print "   --$alias\n";
      }
   }
   print "      $opt->{help}\n";
}

sub usage {
   print "\n";

   if (defined($options{_default_})) {
      my $default = $options{_default_};
      my $default_str = defined($default->{argval}) ? $default->{argval} : "argval";
      if (defined($default->{required}) && $default->{required}) {
         $default_str = "<$default_str>";
      } else {
         $default_str = "[<$default_str>]";
      }
      print "Synopsis:\n\n" . $0 . " OPTIONS " .  $default_str;
      print "\n\n";
   }

   print "Common VI options: \n";
   foreach my $key (sort @builtin_options) {
      print_option($key);
   }
   if (@user_options) {
      print "\n";
      print "Command-specific options:\n";
      foreach my $key (sort @user_options) {
         print_option($key) unless $key eq "_default_";
      }
   }
   exit 1;
}

sub parse_cmdline {
   Util::trace(1, "parse_cmdline\n");
   my %vals;

   my @spec = 
      map { (defined($options{$_}{alias}) ? "$_|$options{$_}{alias}" : $_) . 
            $options{$_}{type} } keys %options;

   Getopt::Long::Configure('no_ignore_case', 'no_pass_through', 'no_auto_abbrev');
   GetOptions(\%vals, @spec) or usage();
   foreach my $key (keys %vals) {
      my $opt = $options{$key};
      Util::trace(2, "  => $key = $vals{$key}\n");
      if (!defined($opt->{value})) {
         $opt->{value} = $vals{$key};
      } else {
         Util::trace(2, "     $key already set to $opt->{value}\n");
      }
   }

   # Final default "flagless" argument handling if applies.
   if (defined($options{_default_}) && $#ARGV == 0) {
      $options{_default_}->{value} = shift(@ARGV);
   }
}

sub parse_environment {
   Util::trace(1, "parse_environment\n");
   foreach my $opt (values %options) {
      if (defined($opt->{variable}) && !defined($opt->{value})) {
         if (defined($ENV{$opt->{variable}})) {
            Util::trace(2, "  => $opt->{variable} = $ENV{$opt->{variable}}\n");
            $opt->{value} = $ENV{$opt->{variable}};
         }
      }
   }
}

sub parse_config {
   my $cfgfile = get_option('config');
   return if (!defined($cfgfile));
   Util::trace(1, "parse_config $cfgfile\n");
   local *CFGFILE;
   open(CFGFILE, $cfgfile) or return;
   Util::trace(1, "file opened; reading...\n");
   while (<CFGFILE>) {
      chomp;
      my ($var, $val) = split(/\s*=\s*/);
      next if !defined($var);
      foreach my $opt (values %options) {
         if (defined($opt->{variable}) && ($var eq $opt->{variable})) {
            Util::trace(2, "  => $var = $val\n");
            if (!defined($opt->{value})) {
               $opt->{value} = $val;
            } else {
               Util::trace(2, "     $var already set to $opt->{value}\n");
            }
            last;
         }
      }
   }
   Util::trace(1, "...done\n");
   close(CFGFILE);
}

sub parse_stdin {
   if (option_is_set('sessionfile')) {
      return;
   }
   if (!option_is_set('username')) {
      print "Enter username:\n";
      my $username = <STDIN>;
      chomp $username;
      $options{username}{value} = $username;
   }
   if (!option_is_set('password')) {
      # XXX Turn off echo
      print "Enter password:\n";
      my $password = <STDIN>;
      chomp $password;
      $options{password}{value} = $password;
   }
}

sub parse {
   parse_cmdline;
   parse_environment;
   parse_config;
   # Disable stdin for now since it's got some issues
   # parse_stdin;
}

sub validate {
   my @validators = @_;

   if (option_is_set('help')) {
      usage();
   }
   if (option_is_set('version')) {
      print "VI Perl Toolkit version: $VMware::VIRuntime::VERSION\n";
      if (defined($Util::script_version)) {
         my $basename = File::Basename::basename($0);
         print "Script '$basename' version: $Util::script_version\n";
      }
      exit 1;
   }
   if (option_is_set('verbose')) {
      my $level = get_option('verbose');
      $level = 1 if ($level eq "");
      $Util::tracelevel = $level;
   }
   my $valid = 1;
   foreach my $key (sort @builtin_options) {
      my $opt = $options{$key};
      if (defined($opt->{required}) && $opt->{required} && !option_is_set($key)) {
         print "Required VI option '$key' not specified\n";
         $valid = 0;
      }
   }
   foreach my $key (sort @user_options) {
      my $opt = $options{$key};
      if (defined($opt->{required}) && $opt->{required} && !option_is_set($key)) {
         print "Required command option '$key' not specified\n";
         $valid = 0;
      }
   }

   # one of sessionfile or (username, password) must be present. if not print usage
   if (!option_is_set('sessionfile') && 
       !(option_is_set('username') && option_is_set('password'))) {
      print "Must have one of command options 'sessionfile' or " .
            "a 'username' and 'password' pair\n";
      $valid = 0;
   }

   foreach my $validator (@validators) {
      if (!&$validator()) {
         $valid = 0;
      }
   }

   if (!$valid) {
      usage();
   }
}

sub assert_usage {
   my ($cond, $string) = @_;
   unless ($cond) {
      print "$string\n";
      usage();
   }
}

1;
##################################################################################
