/* Copyright (C) 2017 Graham Ollis */
#ifndef LIBPALINDROME_H
#define LIBPALINDROME_H 1

int is_palindrome(const char *);

#endif
